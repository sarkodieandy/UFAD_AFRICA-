import 'package:flutter/material.dart';

class AppColors {
  // Primary Teals
  static const teal700 = Color(0xFF004D40);
  static const teal600 = Color(0xFF00695C);
  static const teal500 = Color(0xFF00796B);
  static const teal400 = Color(0xFF00897B);
  static const teal300 = Color(0xFF26A69A);
  static const teal200 = Color(0xFF4DB6AC);
  static const teal100 = Color(0xFF80CBC4);
  static const teal50 = Color(0xFFB2DFDB);

  // Blues (for info, secondary, etc)
  static const blue600 = Color(0xFF0288D1);
  static const blue500 = Color(0xFF039BE5);
  static const blue400 = Color(0xFF29B6F6);
  static const blue300 = Color(0xFF4FC3F7);

  // Grays (backgrounds, text, surfaces)
  static const gray800 = Color(0xFF424242);
  static const gray700 = Color(0xFF616161);
  static const gray600 = Color(0xFF757575);
  static const gray500 = Color(0xFF9E9E9E);
  static const gray300 = Color(0xFFE0E0E0);
  static const gray200 = Color(0xFFEEEEEE);
  static const gray100 = Color(0xFFF5F5F5);
  static const gray50  = Color(0xFFFAFAFA);

  static const white = Colors.white;
  static const surface = Color(0xFFF9FAFB); // Modern soft card background

  // Status, alerts, accents
  static const amber600 = Color(0xFFFFA000);
  static const amber200 = Color(0xFFFFE082);
  static const green50  = Color(0xFFE8F5E9);
  static const green100 = Color(0xFFDCEDC8);

  static const successGreen = Color(0xFF43A047);
  static const errorRed = Color(0xFFD32F2F);
  static const infoBlue = Color(0xFF1976D2);
  static const warningRed = Colors.red;

  // Black/Alpha
  static const black    = Colors.black;
  static const black87  = Colors.black87;
  static const black54  = Colors.black54;
  static const shadow   = Color(0x11000000); // Soft shadow color (for boxShadow)
}
