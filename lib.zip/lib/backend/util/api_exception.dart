/// Exception class for API-related errors with type annotation.
class ApiException implements Exception {
  /// Description of the error (user or developer-friendly).
  final String message;

  /// The error type: one of 'bad_request', 'unauthorized', etc.
  final String type;

  ApiException(this.message, this.type);

  factory ApiException.badRequest(String message) =>
      ApiException(message, 'bad_request');
  factory ApiException.unauthorized(String message) =>
      ApiException(message, 'unauthorized');
  factory ApiException.serverError(String message) =>
      ApiException(message, 'server_error');
  factory ApiException.network(String message) =>
      ApiException(message, 'network');
  factory ApiException.unknown(String message) =>
      ApiException(message, 'unknown');

  @override
  String toString() => 'ApiException: $message ($type)';
}
