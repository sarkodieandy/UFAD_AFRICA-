import 'package:ufad/backend/util/api_exception.dart';

class InputValidator {
  static void validateSignupData(Map<String, dynamic> data) {
    if (data['first_name'] == null || data['first_name'].isEmpty) {
      throw ApiException.badRequest('First name is required');
    }
    if (data['last_name'] == null || data['last_name'].isEmpty) {
      throw ApiException.badRequest('Last name is required');
    }
    if (data['mobile_number'] == null || data['mobile_number'].isEmpty) {
      throw ApiException.badRequest('Mobile number is required');
    }
    if (data['email'] == null || data['email'].isEmpty) {
      throw ApiException.badRequest('Email is required');
    }
    if (data['business_name'] == null || data['business_name'].isEmpty) {
      throw ApiException.badRequest('Business name is required');
    }
    if (data['password'] == null || data['password'].isEmpty) {
      throw ApiException.badRequest('Password is required');
    }
  }

  static void validateLogin(String login, String password) {
    if (login.isEmpty) {
      throw ApiException.badRequest('Login is required');
    }
    if (password.isEmpty) {
      throw ApiException.badRequest('Password is required');
    }
  }
}
