class PosSale {
  final int? id;
  final String customer;
  final double total;
  final double paid;
  final double balance;
  final String status;
  final DateTime dueDate;
  final DateTime saleDate;
  final double percent;

  PosSale({
    this.id,
    required this.customer,
    required this.total,
    required this.paid,
    required this.balance,
    required this.status,
    required this.dueDate,
    required this.saleDate,
    required this.percent,
  });

  factory PosSale.fromJson(Map<String, dynamic> json) {
    double parseDouble(dynamic value, [double fallback = 0.0]) {
      if (value == null) return fallback;
      if (value is num) return value.toDouble();
      return double.tryParse(value.toString()) ?? fallback;
    }

    return PosSale(
      id: json['id'] is int
          ? json['id']
          : (json['id'] != null ? int.tryParse(json['id'].toString()) : null),
      customer: json['customer']?.toString() ?? '',
      total: parseDouble(json['total']),
      paid: parseDouble(json['paid']),
      balance: parseDouble(json['balance']),
      status: json['status']?.toString() ?? 'Unpaid',
      dueDate: DateTime.tryParse(json['due_date']?.toString() ?? '') ?? DateTime.now(),
      saleDate: DateTime.tryParse(json['sale_date']?.toString() ?? '') ?? DateTime.now(),
      percent: parseDouble(json['percent']),
    );
  }

  /// For filtering by date in provider/screens
  DateTime get date => saleDate;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'customer': customer,
      'total': total,
      'paid': paid,
      'balance': balance,
      'status': status,
      'due_date': dueDate.toIso8601String(),
      'sale_date': saleDate.toIso8601String(),
      'percent': percent,
    };
  }

  PosSale copyWith({
    int? id,
    String? customer,
    double? total,
    double? paid,
    double? balance,
    String? status,
    DateTime? dueDate,
    DateTime? saleDate,
    double? percent,
  }) {
    return PosSale(
      id: id ?? this.id,
      customer: customer ?? this.customer,
      total: total ?? this.total,
      paid: paid ?? this.paid,
      balance: balance ?? this.balance,
      status: status ?? this.status,
      dueDate: dueDate ?? this.dueDate,
      saleDate: saleDate ?? this.saleDate,
      percent: percent ?? this.percent,
    );
  }
}
