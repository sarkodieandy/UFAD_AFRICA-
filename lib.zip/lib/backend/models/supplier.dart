class Supplier {
  final int? id;
  final String name;
  final String type;
  final String business;
  final String category;
  final String phone;
  final String mobile;
  final String location;

  Supplier({
    this.id,
    required this.name,
    required this.type,
    required this.business,
    required this.category,
    required this.phone,
    required this.mobile,
    required this.location,
  });

  factory Supplier.fromJson(Map<String, dynamic> json) {
    return Supplier(
      id: json['id'] as int?,
      name: json['name'] as String,
      type: json['type'] as String,
      business: json['business'] as String,
      category: json['category'] as String,
      phone: json['phone'] as String,
      mobile: json['mobile'] as String,
      location: json['location'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'business': business,
      'category': category,
      'phone': phone,
      'mobile': mobile,
      'location': location,
    };
  }
}
