class Activity {
  final String username;
  final String action;
  final DateTime date;

  Activity({
    required this.username,
    required this.action,
    required this.date,
  });

  String get formattedDate =>
      "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";

  factory Activity.fromJson(Map<String, dynamic> json) {
    return Activity(
      username: json['username'] ?? '',
      action: json['action'] ?? '',
      date: DateTime.tryParse(json['date'] ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'action': action,
      'date': date.toIso8601String(),
    };
  }
}
