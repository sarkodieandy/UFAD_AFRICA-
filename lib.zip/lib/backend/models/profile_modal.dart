import 'package:flutter/material.dart';
import 'package:ufad/backend/util/app_colors.dart';
import '../models/business_profile.dart';

class ProfileModal extends StatelessWidget {
  final BusinessProfile profile;

  const ProfileModal({super.key, required this.profile});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(
        profile.name,
        style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.teal600),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Phone: ${profile.phone}', style: TextStyle(color: AppColors.gray600)),
          Text('Location: ${profile.location}', style: TextStyle(color: AppColors.gray600)),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Close', style: TextStyle(color: AppColors.teal600)),
        ),
      ],
    );
  }
}