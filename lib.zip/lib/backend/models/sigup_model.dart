class SignupResponse {
  final int status;
  final String message;
  final SignupData data;

  SignupResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory SignupResponse.fromJson(Map<String, dynamic> json) {
    return SignupResponse(
      status: json['status'] as int,
      message: json['message'] as String,
      data: SignupData.fromJson(json['data'] as Map<String, dynamic>),
    );
  }
}

class SignupData {
  final int userId;
  final String token;

  SignupData({
    required this.userId,
    required this.token,
  });

  factory SignupData.fromJson(Map<String, dynamic> json) {
    return SignupData(
      userId: json['user_id'] as int,
      token: json['token'] as String,
    );
  }
}