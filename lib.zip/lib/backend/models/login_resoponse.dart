import 'package:ufad/backend/models/business_registration.dart';
import 'package:ufad/backend/models/user_model.dart';

class LoginResponse {
  final int status;
  final String message;
  final LoginData data;

  LoginResponse({
    required this.status,
    required this.message,
    required this.data,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    return LoginResponse(
      status: json['status'] as int,
      message: json['message'] as String,
      data: LoginData.fromJson(json['data'] as Map<String, dynamic>),
    );
  }
}

class LoginData {
  final User user;
  final List<BusinessRegistration> businessRegistrations;
  final List<int> supportNeeds;

  LoginData({
    required this.user,
    required this.businessRegistrations,
    required this.supportNeeds,
  });

  factory LoginData.fromJson(Map<String, dynamic> json) {
    return LoginData(
      user: User.fromJson(json['user'] as Map<String, dynamic>),
      businessRegistrations: (json['business_registrations'] as List<dynamic>? ?? [])
          .map((e) => BusinessRegistration.fromJson(e as Map<String, dynamic>))
          .toList(),
      supportNeeds: (json['support_needs'] as List<dynamic>? ?? []).map((e) => e as int).toList(),
    );
  }
}
