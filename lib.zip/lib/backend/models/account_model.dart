class Account {
  final String id;
  final String name;
  final String type; // e.g. 'bank', 'mobile_money', etc.
  double balance;
  final String? description; // Nullable for API flexibility

  Account({
    required this.id,
    required this.name,
    required this.type,
    required this.balance,
    this.description,
  });

  factory Account.fromJson(Map<String, dynamic> json) {
    // Null and type safety for name/type
    final name = json['name'];
    final type = json['type'];
    return Account(
      id: json['id'].toString(),
      name: (name is String && name.isNotEmpty) ? name : 'Unknown',
      type: (type is String && type.isNotEmpty) ? type : 'unknown',
      balance: (json['balance'] is String)
          ? double.tryParse(json['balance']) ?? 0.0
          : (json['balance'] as num?)?.toDouble() ?? 0.0,
      description: json['description'] as String?,
    );
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{
      'id': id,
      'name': name,
      'type': type,
      'balance': balance,
    };
    if (description != null && description!.isNotEmpty) {
      map['description'] = description;
    }
    return map;
  }
}
