import 'package:flutter/material.dart';

class Metric {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  Metric(this.title, this.value, this.icon, this.color);

  factory Metric.fromJson(Map<String, dynamic> json) {
    return Metric(
      json['title'] as String,
      json['value'] as String,
      IconData(json['icon_code'] as int, fontFamily: 'MaterialIcons'),
      Color(int.parse(json['color'] as String)),
    );
  }
}