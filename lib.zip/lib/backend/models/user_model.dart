class User {
  final int userId;
  final String username;
  final String email;
  final String userType;
  final String firstName;
  final String lastName;
  final String mobileNumber;
  final String token;
  final int? regionId;
  final int? districtId;
  final int? townId;
  final String? status;
  final int? creditScore;
  final String? creditRating;
  final String? creditTier;
  final String? createdAt;
  final String? updatedAt;
  final String? lastScoreUpdated;
  final String? businessName;  // Add if you use this in UserProvider
  final String? location;      // Add if you use this in UserProvider

  User({
    required this.userId,
    required this.username,
    required this.email,
    required this.userType,
    required this.firstName,
    required this.lastName,
    required this.mobileNumber,
    required this.token,
    this.regionId,
    this.districtId,
    this.townId,
    this.status,
    this.creditScore,
    this.creditRating,
    this.creditTier,
    this.createdAt,
    this.updatedAt,
    this.lastScoreUpdated,
    this.businessName,
    this.location,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    int? parseInt(dynamic value) {
      if (value == null) return null;
      if (value is int) return value;
      if (value is String) return int.tryParse(value);
      return null;
    }

    return User(
      userId: parseInt(json['user_id']) ?? 0,
      username: json['username']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      userType: json['user_type']?.toString() ?? '',
      firstName: json['first_name']?.toString() ?? '',
      lastName: json['last_name']?.toString() ?? '',
      mobileNumber: json['mobile_number']?.toString() ?? '',
      token: json['token']?.toString() ?? '',
      regionId: parseInt(json['region_id']),
      districtId: parseInt(json['district_id']),
      townId: parseInt(json['town_id']),
      status: json['status']?.toString(),
      creditScore: parseInt(json['credit_score']),
      creditRating: json['credit_rating']?.toString(),
      creditTier: json['credit_tier']?.toString(),
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      lastScoreUpdated: json['last_score_updated']?.toString(),
      businessName: json['business_name']?.toString(),
      location: json['location']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'username': username,
      'email': email,
      'user_type': userType,
      'first_name': firstName,
      'last_name': lastName,
      'mobile_number': mobileNumber,
      'token': token,
      'region_id': regionId,
      'district_id': districtId,
      'town_id': townId,
      'status': status,
      'credit_score': creditScore,
      'credit_rating': creditRating,
      'credit_tier': creditTier,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'last_score_updated': lastScoreUpdated,
      'business_name': businessName,
      'location': location,
    };
  }
}
