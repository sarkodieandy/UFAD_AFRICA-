class BusinessProfile {
  final String name;
  final String phone;
  final String location;
  final String? profileImageUrl;      // For network image
  final String? profileImageBase64;   // For base64 image

  BusinessProfile({
    required this.name,
    required this.phone,
    required this.location,
    this.profileImageUrl,
    this.profileImageBase64,
  });

  factory BusinessProfile.fromJson(Map<String, dynamic> json) {
    return BusinessProfile(
      name: json['name'] ?? '',
      phone: json['phone'] ?? '',
      location: json['location'] ?? '',
      profileImageUrl: json['profile_image_url'],
      profileImageBase64: json['profile_image_base64'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'phone': phone,
      'location': location,
      'profile_image_url': profileImageUrl,
      'profile_image_base64': profileImageBase64,
    };
  }
}
