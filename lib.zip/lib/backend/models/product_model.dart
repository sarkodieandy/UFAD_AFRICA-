import 'package:ufad/backend/models/product_category.dart';


class Product {
  final int? id;
  final String name;
  final String description;
  final double costPrice;
  final double sellingPrice;
  final ProductCategory category;

  Product({
    this.id,
    required this.name,
    required this.description,
    required this.costPrice,
    required this.sellingPrice,
    required this.category,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] as int?,
      name: json['name'] as String,
      description: json['description'] as String,
      costPrice: (json['cost_price'] ?? json['costPrice'] ?? 0).toDouble(),
      sellingPrice: (json['selling_price'] ?? json['sellingPrice'] ?? json['price'] ?? 0).toDouble(),
      category: ProductCategory.fromJson(json['category'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'description': description,
    'cost_price': costPrice,
    'selling_price': sellingPrice,
    'category': category.toJson(),
  };
}
