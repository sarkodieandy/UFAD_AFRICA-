import 'package:ufad/backend/models/category_model.dart';


import 'stock_product.dart';
import 'supplier.dart';

class Purchase {
  final int? id;
  final Product product;
  final Supplier supplier;
  final Category category;
  final double unitCost;
  final double sellingPrice;
  final double profitMargin;
  final int quantity;
  final double totalCost;
  final String paymentStatus;
  final DateTime date;

  Purchase({
    this.id,
    required this.product,
    required this.supplier,
    required this.category,
    required this.unitCost,
    required this.sellingPrice,
    required this.profitMargin,
    required this.quantity,
    required this.totalCost,
    required this.paymentStatus,
    required this.date,
  });

  factory Purchase.fromJson(Map<String, dynamic> json) {
    return Purchase(
      id: json['id'] as int?,
      product: Product.fromJson(json['product'] as Map<String, dynamic>),
      supplier: Supplier.fromJson(json['supplier'] as Map<String, dynamic>),
      category: Category.fromJson(json['category'] as Map<String, dynamic>),
      unitCost: (json['unit_cost'] as num).toDouble(),
      sellingPrice: (json['selling_price'] as num).toDouble(),
      profitMargin: (json['profit_margin'] as num).toDouble(),
      quantity: json['quantity'] as int,
      totalCost: (json['total_cost'] as num).toDouble(),
      paymentStatus: json['payment_status'] as String,
      date: DateTime.parse(json['date'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'product': product.toJson(),
      'supplier': supplier.toJson(),
      'category': category.toJson(),
      'unit_cost': unitCost,
      'selling_price': sellingPrice,
      'profit_margin': profitMargin,
      'quantity': quantity,
      'total_cost': totalCost,
      'payment_status': paymentStatus,
      'date': date.toIso8601String(),
    };
  }
}