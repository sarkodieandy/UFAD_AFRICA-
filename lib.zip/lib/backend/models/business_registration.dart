class BusinessRegistration {
  final int staffId;
  final String fullName;
  final String mobileNumber;
  final String gender;
  final String ageGroup;
  final String nationalIdType;
  final String? nationalIdImage;
  final int regionId;
  final int districtId;
  final int townId;
  final String businessName;
  final String businessType;
  final String businessRegistered;
  final String? registrationDocument;
  final String businessSector;
  final String mainProductService;
  final int businessStartYear;
  final String businessLocation;
  final String? gpsAddress;
  final String businessPhone;
  final String estimatedWeeklySales;
  final String numberOfWorkers;
  final String recordKeepingMethod;
  final String? mobileMoneyNumber;
  final String hasInsurance;
  final String pensionScheme;
  final String bankLoan;
  final String termsAgreed;
  final String receiveUpdates;
  final List<int> supportNeeds;
  final String email;
  final String password;
  final String firstName;
  final String lastName;
  final String userType;
  final String? profileImageBase64;
  final String username;

  // Remove phoneNumber, businessAddress from required unless you use them elsewhere
  BusinessRegistration({
    required this.staffId,
    required this.fullName,
    required this.mobileNumber,
    required this.gender,
    required this.ageGroup,
    required this.nationalIdType,
    this.nationalIdImage,
    required this.regionId,
    required this.districtId,
    required this.townId,
    required this.businessName,
    required this.businessType,
    required this.businessRegistered,
    this.registrationDocument,
    required this.businessSector,
    required this.mainProductService,
    required this.businessStartYear,
    required this.businessLocation,
    this.gpsAddress,
    required this.businessPhone,
    required this.estimatedWeeklySales,
    required this.numberOfWorkers,
    required this.recordKeepingMethod,
    this.mobileMoneyNumber,
    required this.hasInsurance,
    required this.pensionScheme,
    required this.bankLoan,
    required this.termsAgreed,
    required this.receiveUpdates,
    required this.supportNeeds,
    required this.email,
    required this.password,
    required this.firstName,
    required this.lastName,
    required this.userType,
    this.profileImageBase64,
    required this.username,
    // Not needed: required String phoneNumber, required String businessAddress,
  });

  static int parseInt(dynamic value, {int defaultValue = 0}) {
    if (value == null) return defaultValue;
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? defaultValue;
    return defaultValue;
  }

  factory BusinessRegistration.fromJson(Map<String, dynamic> json) {
    List<int> parseSupportNeeds(dynamic needs) {
      if (needs is List) {
        return needs.map((e) => parseInt(e)).toList();
      }
      return [];
    }

    return BusinessRegistration(
      staffId: parseInt(json['staff_id']),
      fullName: json['full_name'] ?? '',
      mobileNumber: json['mobile_number'] ?? '',
      gender: json['gender'] ?? '',
      ageGroup: json['age_group'] ?? '',
      nationalIdType: json['national_id_type'] ?? '',
      nationalIdImage: json['national_id_image'],
      regionId: parseInt(json['region_id']),
      districtId: parseInt(json['district_id']),
      townId: parseInt(json['town_id']),
      businessName: json['business_name'] ?? '',
      businessType: json['business_type'] ?? '',
      businessRegistered: json['business_registered'] ?? '',
      registrationDocument: json['registration_document'],
      businessSector: json['business_sector'] ?? '',
      mainProductService: json['main_product_service'] ?? '',
      businessStartYear: parseInt(json['business_start_year'], defaultValue: DateTime.now().year),
      businessLocation: json['business_location'] ?? '',
      gpsAddress: json['gps_address'],
      businessPhone: json['business_phone'] ?? '',
      estimatedWeeklySales: json['estimated_weekly_sales'] ?? '',
      numberOfWorkers: json['number_of_workers'] ?? '',
      recordKeepingMethod: json['record_keeping_method'] ?? '',
      mobileMoneyNumber: json['mobile_money_number'],
      hasInsurance: json['has_insurance'] ?? '',
      pensionScheme: json['pension_scheme'] ?? '',
      bankLoan: json['bank_loan'] ?? '',
      termsAgreed: json['terms_agreed'] ?? '',
      receiveUpdates: json['receive_updates'] ?? '',
      supportNeeds: parseSupportNeeds(json['support_needs']),
      email: json['email'] ?? '',
      password: json['password'] ?? '',
      firstName: json['first_name'] ?? '',
      lastName: json['last_name'] ?? '',
      userType: json['user_type'] ?? '',
      profileImageBase64: json['profile_image'],
      username: json['username'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'email': email,
      'password': password,
      'first_name': firstName,
      'last_name': lastName,
      'mobile_number': mobileNumber,
      'region_id': regionId,
      'district_id': districtId,
      'town_id': townId,
      if (profileImageBase64 != null && profileImageBase64!.isNotEmpty) 'profile_image': profileImageBase64,
      'full_name': fullName,
      'gender': gender,
      'age_group': ageGroup,
      'national_id_type': nationalIdType,
      'business_name': businessName,
      'business_type': businessType,
      'business_registered': businessRegistered,
      'business_sector': businessSector,
      'main_product_service': mainProductService,
      'business_start_year': businessStartYear,
      'business_location': businessLocation,
      if (gpsAddress != null && gpsAddress!.isNotEmpty) 'gps_address': gpsAddress,
      'business_phone': businessPhone,
      'estimated_weekly_sales': estimatedWeeklySales,
      'number_of_workers': numberOfWorkers,
      'record_keeping_method': recordKeepingMethod,
      if (mobileMoneyNumber != null && mobileMoneyNumber!.isNotEmpty) 'mobile_money_number': mobileMoneyNumber,
      'has_insurance': hasInsurance,
      'pension_scheme': pensionScheme,
      'bank_loan': bankLoan,
      'terms_agreed': termsAgreed,
      'receive_updates': receiveUpdates,
      'support_needs': supportNeeds,
    };
  }

  BusinessRegistration copyWith({
    int? staffId,
    String? fullName,
    String? mobileNumber,
    String? gender,
    String? ageGroup,
    String? nationalIdType,
    String? nationalIdImage,
    int? regionId,
    int? districtId,
    int? townId,
    String? businessName,
    String? businessType,
    String? businessRegistered,
    String? registrationDocument,
    String? businessSector,
    String? mainProductService,
    int? businessStartYear,
    String? businessLocation,
    String? gpsAddress,
    String? businessPhone,
    String? estimatedWeeklySales,
    String? numberOfWorkers,
    String? recordKeepingMethod,
    String? mobileMoneyNumber,
    String? hasInsurance,
    String? pensionScheme,
    String? bankLoan,
    String? termsAgreed,
    String? receiveUpdates,
    List<int>? supportNeeds,
    String? email,
    String? password,
    String? firstName,
    String? lastName,
    String? userType,
    String? profileImageBase64,
    String? username,
  }) {
    return BusinessRegistration(
      staffId: staffId ?? this.staffId,
      fullName: fullName ?? this.fullName,
      mobileNumber: mobileNumber ?? this.mobileNumber,
      gender: gender ?? this.gender,
      ageGroup: ageGroup ?? this.ageGroup,
      nationalIdType: nationalIdType ?? this.nationalIdType,
      nationalIdImage: nationalIdImage ?? this.nationalIdImage,
      regionId: regionId ?? this.regionId,
      districtId: districtId ?? this.districtId,
      townId: townId ?? this.townId,
      businessName: businessName ?? this.businessName,
      businessType: businessType ?? this.businessType,
      businessRegistered: businessRegistered ?? this.businessRegistered,
      registrationDocument: registrationDocument ?? this.registrationDocument,
      businessSector: businessSector ?? this.businessSector,
      mainProductService: mainProductService ?? this.mainProductService,
      businessStartYear: businessStartYear ?? this.businessStartYear,
      businessLocation: businessLocation ?? this.businessLocation,
      gpsAddress: gpsAddress ?? this.gpsAddress,
      businessPhone: businessPhone ?? this.businessPhone,
      estimatedWeeklySales: estimatedWeeklySales ?? this.estimatedWeeklySales,
      numberOfWorkers: numberOfWorkers ?? this.numberOfWorkers,
      recordKeepingMethod: recordKeepingMethod ?? this.recordKeepingMethod,
      mobileMoneyNumber: mobileMoneyNumber ?? this.mobileMoneyNumber,
      hasInsurance: hasInsurance ?? this.hasInsurance,
      pensionScheme: pensionScheme ?? this.pensionScheme,
      bankLoan: bankLoan ?? this.bankLoan,
      termsAgreed: termsAgreed ?? this.termsAgreed,
      receiveUpdates: receiveUpdates ?? this.receiveUpdates,
      supportNeeds: supportNeeds ?? this.supportNeeds,
      email: email ?? this.email,
      password: password ?? this.password,
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      userType: userType ?? this.userType,
      profileImageBase64: profileImageBase64 ?? this.profileImageBase64,
      username: username ?? this.username,
    );
  }
}
