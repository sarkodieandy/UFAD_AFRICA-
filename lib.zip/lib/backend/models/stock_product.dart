class Product {
  final int id;
  final String name;
  final int categoryId;
  final double costPrice;
  final double sellingPrice;

  Product({
    required this.id,
    required this.name,
    required this.categoryId,
    required this.costPrice,
    required this.sellingPrice,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'] as int,
      name: json['name'] as String,
      categoryId: json['category_id'] as int,
      costPrice: (json['cost_price'] as num).toDouble(),
      sellingPrice: (json['selling_price'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'category_id': categoryId,
      'cost_price': costPrice,
      'selling_price': sellingPrice,
    };
  }
}
