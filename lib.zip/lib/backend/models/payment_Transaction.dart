class PaymentTransaction {
  final String id;
  final String type;
  final String account;
  final String? secondaryAccount;
  final String? supplier;
  final String? purchase;
  final double amount;
  final String description;
  final DateTime date;

  PaymentTransaction({
    required this.id,
    required this.type,
    required this.account,
    this.secondaryAccount,
    this.supplier,
    this.purchase,
    required this.amount,
    required this.description,
    required this.date,
  });

  factory PaymentTransaction.fromJson(Map<String, dynamic> json) {
    return PaymentTransaction(
      id: json['id'] as String,
      type: json['type'] as String,
      account: json['account'] as String,
      secondaryAccount: json['secondary_account'] as String?,
      supplier: json['supplier'] as String?,
      purchase: json['purchase'] as String?,
      amount: (json['amount'] as num).toDouble(),
      description: json['description'] as String,
      date: DateTime.parse(json['date'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'account': account,
      'secondary_account': secondaryAccount,
      'supplier': supplier,
      'purchase': purchase,
      'amount': amount,
      'description': description,
      'date': date.toIso8601String(),
    };
  }
}