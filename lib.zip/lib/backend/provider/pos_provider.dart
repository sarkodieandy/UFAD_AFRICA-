import 'package:flutter/material.dart';
import 'package:ufad/backend/models/pos_model.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';

class PosProvider with ChangeNotifier {
  final ApiService _apiService;
  List<PosSale> _sales = [];
  bool _isLoading = false;
  String? _error;
  int? _userId;

  String? _customerFilter;
  String? _statusFilter;
  DateTime? _startDateFilter;
  DateTime? _endDateFilter;

  PosProvider({ApiService? apiService}) : _apiService = apiService ?? ApiService();

  List<PosSale> get sales => List.unmodifiable(_sales);
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;

  double get totalSales => _sales.fold(0.0, (sum, sale) => sum + sale.total);
  double get totalPaid => _sales.fold(0.0, (sum, sale) => sum + sale.paid);
  double get totalBalance => _sales.fold(0.0, (sum, sale) => sum + sale.balance);
  int get totalDebtors => _sales.where((s) => s.balance > 0).length;

  List<PosSale> get filteredSales {
    return _sales.where((sale) {
      bool matches = true;
      if (_customerFilter != null && _customerFilter!.isNotEmpty) {
        matches &= sale.customer.toLowerCase().contains(_customerFilter!.toLowerCase());
      }
      if (_statusFilter != null) {
        if (_statusFilter == 'debt') {
          matches &= sale.balance > 0;
        } else if (_statusFilter == 'paid') {
          matches &= sale.balance <= 0;
        }
      }
      if (_startDateFilter != null) {
        matches &= sale.date.isAfter(_startDateFilter!.subtract(const Duration(days: 1)));
      }
      if (_endDateFilter != null) {
        matches &= sale.date.isBefore(_endDateFilter!.add(const Duration(days: 1)));
      }
      return matches;
    }).toList();
  }

  void setFilters({
    String? customer,
    String? status,
    DateTime? startDate,
    DateTime? endDate,
  }) {
    _customerFilter = customer;
    _statusFilter = status;
    _startDateFilter = startDate;
    _endDateFilter = endDate;
    notifyListeners();
  }

  void setUserId(int userId) {
    _userId = userId;
    fetchSales();
  }

  Future<void> fetchSales() async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _sales = await _apiService.fetchPosSales(userId: _userId!);
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addSale(PosSale sale) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.addPosSale(sale, userId: _userId!);
      await fetchSales();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> updateSale(PosSale sale) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.updatePosSale(sale, userId: _userId!);
      await fetchSales();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deleteSale(int id) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.deletePosSale(id, userId: _userId!);
      await fetchSales();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> payDebt({required String customer, required double amount}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      final idx = _sales.indexWhere((s) => s.customer == customer && s.balance > 0);
      if (idx == -1) {
        _error = 'No outstanding debt for $customer';
        notifyListeners();
        return;
      }
      final sale = _sales[idx];
      final newPaid = (sale.paid + amount).clamp(0, sale.total);
      final updated = sale.copyWith(
        paid: newPaid.toDouble(),
        balance: (sale.total - newPaid).clamp(0, sale.total).toDouble(),
      );
      await updateSale(updated);
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void clearAll() {
    _userId = null;
    _sales.clear();
    _isLoading = false;
    _error = null;
    _customerFilter = null;
    _statusFilter = null;
    _startDateFilter = null;
    _endDateFilter = null;
    notifyListeners();
  }
}
