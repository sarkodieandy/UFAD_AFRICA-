import 'package:flutter/material.dart';
import 'package:ufad/backend/models/category_model.dart';
import 'package:ufad/backend/models/product_model.dart';
import 'package:ufad/backend/models/purchase_model.dart';
import 'package:ufad/backend/models/supplier.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'dashboard_provider.dart';

class StockProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Purchase> _purchases = [];
  List<Category> _categories = [];
  List<Product> _products = [];
  List<Supplier> _suppliers = [];
  bool _isLoading = false;
  String? _error;
  int? _userId;
  int? _categoryFilter;
  String? _statusFilter;
  int? _supplierFilter;

  StockProvider({ApiService? apiService})
    : _apiService = apiService ?? ApiService();

  // Getters for UI
  List<Purchase> get purchases => List.unmodifiable(_applyFilters(_purchases));
  List<Category> get categories => List.unmodifiable(_categories);
  List<Product> get products => List.unmodifiable(_products);
  List<Supplier> get suppliers => List.unmodifiable(_suppliers);
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;
  int? get categoryFilter => _categoryFilter;
  String? get statusFilter => _statusFilter;
  int? get supplierFilter => _supplierFilter;

  // Quick summaries for UI
  double get totalPaid => _purchases
      .where((p) => p.paymentStatus.toLowerCase() == 'paid')
      .fold(0.0, (sum, p) => sum + p.totalCost);

  double get totalUnpaid => _purchases
      .where((p) => p.paymentStatus.toLowerCase() == 'unpaid')
      .fold(0.0, (sum, p) => sum + p.amountDue);

  double get currentStockValue =>
      _purchases.fold(0.0, (sum, p) => sum + (p.unitCost * p.quantity));

  // FILTERS
  void setCategoryFilter(int? id) {
    _categoryFilter = id;
    notifyListeners();
  }

  void setStatusFilter(String? status) {
    _statusFilter = status;
    notifyListeners();
  }

  void setSupplierFilter(int? id) {
    _supplierFilter = id;
    notifyListeners();
  }

  void clearFilters() {
    _categoryFilter = null;
    _statusFilter = null;
    _supplierFilter = null;
    notifyListeners();
  }

  // Internal filter logic
  List<Purchase> _applyFilters(List<Purchase> data) {
    return data.where((p) {
      final matchCategory =
          _categoryFilter == null || p.category.id == _categoryFilter;
      final matchSupplier =
          _supplierFilter == null || p.supplier.id == _supplierFilter;
      final matchStatus =
          _statusFilter == null ||
          p.paymentStatus.toLowerCase() == _statusFilter!.toLowerCase();
      return matchCategory && matchSupplier && matchStatus;
    }).toList();
  }

  // Set and fetch
  void setUserId(int userId) {
    _userId = userId;
    fetchStockData();
  }

  // Load all stock-related data in one call
  Future<void> fetchStockData() async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final purchases = await _apiService.fetchStockPurchases(userId: _userId!);
      final categories = await _apiService.fetchCategories(userId: _userId!);
      final products = await _apiService.fetchProducts(userId: _userId!);
      final suppliers = await _apiService.fetchSuppliers(userId: _userId!);

      _purchases = purchases;
      _categories = categories;
      _products = products;
      _suppliers = suppliers;
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addPurchase(
    Purchase purchase, {
    DashboardProvider? dashboardProvider,
  }) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.addStockPurchase(purchase, userId: _userId!);
      await fetchStockData();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> editPurchase(
    Purchase purchase, {
    DashboardProvider? dashboardProvider,
  }) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.updateStockPurchase(purchase, userId: _userId!);
      await fetchStockData();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deletePurchase(
    int id, {
    DashboardProvider? dashboardProvider,
  }) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.deleteStockPurchase(id, userId: _userId!);
      await fetchStockData();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
  Future<void> fetchPurchasesOnly() async {
  if (_userId == null) {
    _error = 'No user logged in';
    notifyListeners();
    return;
  }
  _isLoading = true;
  _error = null;
  notifyListeners();
  try {
    _purchases = await _apiService.fetchStockPurchases(userId: _userId!);
    _error = null;
  } on ApiException catch (e) {
    _error = e.message;
  } finally {
    _isLoading = false;
    notifyListeners();
  }
}


  /// Call this on logout/session clear
  void clear() {
    _userId = null;
    _purchases.clear();
    _categories.clear();
    _products.clear();
    _suppliers.clear();
    _isLoading = false;
    _error = null;
    _categoryFilter = null;
    _statusFilter = null;
    _supplierFilter = null;
    notifyListeners();
  }
}
