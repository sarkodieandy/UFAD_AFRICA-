import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:ufad/backend/models/user_model.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'package:ufad/backend/models/business_registration.dart';

// Main Providers
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/provider/customer_provider.dart';
import 'package:ufad/backend/provider/stock_provider.dart';
import 'package:ufad/backend/provider/supplier_provider.dart';
import 'package:ufad/backend/provider/user_provider.dart';

class RegistrationProvider with ChangeNotifier {
  final ApiService _apiService;

  BusinessRegistration? _registration;
  int? _userId;
  String? _token;
  bool _isLoading = false;
  String? _error;

  // Dashboard quick state
  Map<String, dynamic>? dashboardMetrics;
  Map<String, dynamic>? dashboardBusinessProfile;
  Map<String, dynamic>? dashboardSalesTrend;
  bool dashboardLoading = false;
  String? dashboardError;

  RegistrationProvider({ApiService? apiService})
      : _apiService = apiService ?? ApiService();

  BusinessRegistration? get registration => _registration;
  int? get userId => _userId;
  String? get token => _token;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// --- Used by Business Info, Activity, Support, Consent screens ---
  void setRegistration(BusinessRegistration registration) {
    _registration = registration;
    notifyListeners();
  }

  /// --- For PATCH-LIKE field updates on staged object (not for first screen!) ---
  void updateRegistrationFields({
    String? email,
    String? password,
    String? firstName,
    String? lastName,
    String? userType,
    String? mobileNumber,
    String? gender,
    String? ageGroup,
    String? nationalIdType,
    int? regionId,
    int? districtId,
    int? townId,
    String? profileImageBase64,
    String? businessName,
    String? businessType,
    String? businessRegistered,
    String? businessSector,
    String? mainProductService,
    int? businessStartYear,
    String? businessLocation,
    String? gpsAddress,
    String? businessPhone,
    String? estimatedWeeklySales,
    String? numberOfWorkers,
    String? recordKeepingMethod,
    String? mobileMoneyNumber,
    String? hasInsurance,
    String? pensionScheme,
    String? bankLoan,
    String? termsAgreed,
    String? receiveUpdates,
    List<int>? supportNeeds,
    String? username,
    String? fullName,
    String? nationalIdImage,
  }) {
    if (_registration == null) {
      throw ApiException.badRequest('Registration object not staged yet.');
    }
    _registration = _registration!.copyWith(
      email: email,
      password: password,
      firstName: firstName,
      lastName: lastName,
      userType: userType,
      mobileNumber: mobileNumber,
      gender: gender,
      ageGroup: ageGroup,
      nationalIdType: nationalIdType,
      regionId: regionId,
      districtId: districtId,
      townId: townId,
      profileImageBase64: profileImageBase64,
      businessName: businessName,
      businessType: businessType,
      businessRegistered: businessRegistered,
      businessSector: businessSector,
      mainProductService: mainProductService,
      businessStartYear: businessStartYear,
      businessLocation: businessLocation,
      gpsAddress: gpsAddress,
      businessPhone: businessPhone,
      estimatedWeeklySales: estimatedWeeklySales,
      numberOfWorkers: numberOfWorkers,
      recordKeepingMethod: recordKeepingMethod,
      mobileMoneyNumber: mobileMoneyNumber,
      hasInsurance: hasInsurance,
      pensionScheme: pensionScheme,
      bankLoan: bankLoan,
      termsAgreed: termsAgreed,
      receiveUpdates: receiveUpdates,
      supportNeeds: supportNeeds,
      username: username,
      fullName: fullName,
      nationalIdImage: nationalIdImage,
    );
    notifyListeners();
  }

  /// --- FIRST SCREEN: This is called ONCE to create initial object ---
  Future<void> registerUserAndCustomer({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String userType,
    required String mobileNumber,
    required String gender,
    required String ageGroup,
    required String nationalIdType,
    required int regionId,
    required int districtId,
    required int townId,
    String? profileImageBase64,
    String? businessName,
    String? businessType,
    String? businessRegistered,
    String? businessSector,
    String? mainProductService,
    int? businessStartYear,
    String? businessLocation,
    String? gpsAddress,
    String? businessPhone,
    String? estimatedWeeklySales,
    String? numberOfWorkers,
    String? recordKeepingMethod,
    String? mobileMoneyNumber,
    String? hasInsurance,
    String? pensionScheme,
    String? bankLoan,
    String? termsAgreed,
    String? receiveUpdates,
    List<int>? supportNeeds,
    String? username,
    String? fullName,
    String? nationalIdImage,
  }) async {
    // Strong validation
    if (firstName.trim().isEmpty) throw ApiException.badRequest('First name is required');
    if (lastName.trim().isEmpty) throw ApiException.badRequest('Last name is required');
    if (email.trim().isEmpty) throw ApiException.badRequest('Email is required');
    if (mobileNumber.trim().isEmpty) throw ApiException.badRequest('Mobile number is required');
    if (businessName == null || businessName.trim().isEmpty) throw ApiException.badRequest('Business name is required');

    _registration = BusinessRegistration(
      staffId: 0,
      fullName: fullName ?? '$firstName $lastName',
      username: username ?? (email.contains('@') ? email.split('@')[0] : '$firstName$lastName'),
      email: email,
      password: password,
      firstName: firstName,
      lastName: lastName,
      userType: userType,
      mobileNumber: mobileNumber,
      gender: gender,
      ageGroup: ageGroup,
      nationalIdType: nationalIdType,
      nationalIdImage: nationalIdImage,
      regionId: regionId,
      districtId: districtId,
      townId: townId,
      profileImageBase64: profileImageBase64,
      businessName: businessName,
      businessType: businessType ?? '',
      businessRegistered: businessRegistered ?? '',
      businessSector: businessSector ?? '',
      mainProductService: mainProductService ?? '',
      businessStartYear: businessStartYear ?? DateTime.now().year,
      businessLocation: businessLocation ?? '',
      gpsAddress: gpsAddress,
      businessPhone: businessPhone ?? '',
      estimatedWeeklySales: estimatedWeeklySales ?? '',
      numberOfWorkers: numberOfWorkers ?? '',
      recordKeepingMethod: recordKeepingMethod ?? '',
      mobileMoneyNumber: mobileMoneyNumber,
      hasInsurance: hasInsurance ?? '',
      pensionScheme: pensionScheme ?? '',
      bankLoan: bankLoan ?? '',
      termsAgreed: termsAgreed ?? 'yes',
      receiveUpdates: receiveUpdates ?? 'yes',
      supportNeeds: supportNeeds ?? [],
    );
    notifyListeners();
  }

  /// --- FINAL SUBMIT: Call API, propagate userId to all providers, etc ---
  Future<void> submitRegistration(BuildContext context) async {
    if (_registration == null) throw ApiException.badRequest('Registration data not set.');
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final r = _registration!;
      final data = r.toJson();
      final result = await _apiService.signup(data);
      final userIdRaw = result['data']['user_id'];
      _userId = userIdRaw is int ? userIdRaw : int.tryParse(userIdRaw?.toString() ?? '');
      _token = result['data']['token'] as String?;
      _error = null;

      if (_userId != null) {
        // Propagate to all other providers
        Provider.of<UserProvider>(context, listen: false).setUser(
          User(
            userId: _userId!,
            username: r.username,
            email: r.email,
            userType: r.userType,
            firstName: r.firstName,
            lastName: r.lastName,
            mobileNumber: r.mobileNumber,
            businessName: r.businessName,
            token: _token ?? '',
          ),
        );
        Provider.of<PaymentProvider>(context, listen: false).setUserId(_userId!);
        Provider.of<CustomerProvider>(context, listen: false).setUserId(_userId!);
        Provider.of<StockProvider>(context, listen: false).setUserId(_userId!);
        Provider.of<SupplierProvider>(context, listen: false).setUserId(_userId!);
      }
    } on ApiException catch (e) {
      _error = e.message;
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// --- LOGIN: fetch, set userId everywhere needed ---
  Future<Map<String, dynamic>> login(BuildContext context, String loginValue, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final data = await _apiService.login(loginValue, password);
      final userIdRaw = data['data']['user']['user_id'];
      _userId = userIdRaw is int ? userIdRaw : int.tryParse(userIdRaw?.toString() ?? '');
      _token = data['data']['user']['token'] as String?;
      final regs = data['data']['business_registrations'] as List?;
      if (regs != null && regs.isNotEmpty) {
        _registration = BusinessRegistration.fromJson(regs.first);
      }
      _error = null;

      if (_userId != null && _registration != null) {
        final reg = _registration!;
        // ignore: use_build_context_synchronously
        Provider.of<UserProvider>(context, listen: false).setUser(
          User(
            userId: _userId!,
            username: reg.username,
            email: reg.email,
            userType: reg.userType,
            firstName: reg.firstName,
            lastName: reg.lastName,
            mobileNumber: reg.mobileNumber,
            businessName: reg.businessName,
            token: _token ?? '',
          ),
        );
        Provider.of<PaymentProvider>(context, listen: false).setUserId(_userId!);
        Provider.of<CustomerProvider>(context, listen: false).setUserId(_userId!);
        Provider.of<StockProvider>(context, listen: false).setUserId(_userId!);
        Provider.of<SupplierProvider>(context, listen: false).setUserId(_userId!);
      }

      return data['data']['user'];
    } on ApiException catch (e) {
      _error = e.message;
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// --- DASHBOARD LOADING ---
  Future<void> loadDashboard({String? period, int? categoryId}) async {
    if (_userId == null) {
      dashboardError = 'No user logged in';
      notifyListeners();
      return;
    }
    dashboardLoading = true;
    dashboardError = null;
    notifyListeners();
    try {
      final data = await _apiService.fetchDashboard(
        userId: _userId!,
        period: period,
        categoryId: categoryId,
      );
      dashboardMetrics = data['data']['metrics'] as Map<String, dynamic>?;
      dashboardBusinessProfile = data['data']['business_profile'] as Map<String, dynamic>?;
      dashboardSalesTrend = data['data']['sales_trend'] as Map<String, dynamic>?;
    } on ApiException catch (e) {
      dashboardError = e.message;
    } finally {
      dashboardLoading = false;
      notifyListeners();
    }
  }

  /// --- ERROR CLEARING ---
  void clearError() {
    _error = null;
    dashboardError = null;
    notifyListeners();
  }

  /// --- LOGOUT: Clear All Providers (Call on logout) ---
  void clearAllProviders(BuildContext context) {
    _userId = null;
    _token = null;
    _registration = null;
    _error = null;
    dashboardError = null;
    dashboardMetrics = null;
    dashboardBusinessProfile = null;
    dashboardSalesTrend = null;
    Provider.of<UserProvider>(context, listen: false).logout();
    Provider.of<PaymentProvider>(context, listen: false).clear();
    Provider.of<CustomerProvider>(context, listen: false).clear();
    Provider.of<StockProvider>(context, listen: false).clear();
    Provider.of<SupplierProvider>(context, listen: false).clear();
    notifyListeners();
  }
}
