import 'package:flutter/material.dart';
import 'package:ufad/backend/models/customer_model.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'dashboard_provider.dart';

class CustomerProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Customer> _customers = [];
  bool _isLoading = false;
  String? _error;
  int? _userId;
  String _searchQuery = '';

  // Added for filtering by dropdown
  String? _categoryFilter;
  String? _accountTypeFilter;

  CustomerProvider({ApiService? apiService}) : _apiService = apiService ?? ApiService();

  List<Customer> get customers => _customers;
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;

  List<Customer> get filteredCustomers {
    var list = _customers;
    if (_categoryFilter != null && _categoryFilter!.isNotEmpty) {
      list = list.where((c) => c.category == _categoryFilter).toList();
    }
    if (_accountTypeFilter != null && _accountTypeFilter!.isNotEmpty) {
      list = list.where((c) => c.accountType == _accountTypeFilter).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list.where((c) =>
        c.name.toLowerCase().contains(q) ||
        c.email.toLowerCase().contains(q) ||
        c.phone.toLowerCase().contains(q)
      ).toList();
    }
    return list;
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }

  void setFilters({String? category, String? accountType}) {
    _categoryFilter = category;
    _accountTypeFilter = accountType;
    notifyListeners();
  }

  void clearFilters() {
    _categoryFilter = null;
    _accountTypeFilter = null;
    notifyListeners();
  }

  void setUserId(int userId) {
    _userId = userId;
    loadCustomers();
  }

  Future<void> loadCustomers() async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _customers = await _apiService.fetchCustomers(userId: _userId!);
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addCustomer(Customer customer, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.addCustomer(customer, userId: _userId!);
      await loadCustomers();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
      notifyListeners();
    }
  }

  Future<void> updateCustomer(Customer customer, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.updateCustomer(customer, userId: _userId!);
      await loadCustomers();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
      notifyListeners();
    }
  }

  Future<void> deleteCustomer(int id, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.deleteCustomer(id, userId: _userId!);
      await loadCustomers();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void clear() {
    _customers = [];
    _error = null;
    _isLoading = false;
    _userId = null;
    _searchQuery = '';
    _categoryFilter = null;
    _accountTypeFilter = null;
    notifyListeners();
  }
}
