import 'package:flutter/material.dart';
import 'package:ufad/backend/models/user_model.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'dashboard_provider.dart';

class UserProvider with ChangeNotifier {
  final ApiService _apiService;
  User? _user;
  String _businessName = '';
  String _phone = '';
  String _location = '';
  bool _isLoading = false;
  String? _error;

  UserProvider({ApiService? apiService}) : _apiService = apiService ?? ApiService();

  User? get user => _user;
  int? get userId => _user?.userId;
  String get username => _user?.username ?? '';
  String get businessName => _businessName.isNotEmpty ? _businessName : (_user?.businessName ?? '');
  String get phone => _phone.isNotEmpty ? _phone : (_user?.mobileNumber ?? '');
  String get location => _location.isNotEmpty ? _location : '';
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Set the user (typically after login or profile fetch)
  void setUser(User user, {String? businessName, String? phone, String? location}) {
    _user = user;
    _businessName = businessName ?? user.businessName ?? '';
    _phone = phone ?? user.mobileNumber;
    _location = location ?? '';
    notifyListeners();
  }

  /// Update user profile info in backend (call this from your edit profile UI)
  Future<void> updateProfile(
    String businessName,
    String phone,
    String location, {
    DashboardProvider? dashboardProvider,
  }) async {
    if (_user == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final response = await _apiService.updateUserProfile(
        userId: _user!.userId,
        businessName: businessName,
        phone: phone,
        location: location,
        name: '', // Add user full name if you support editing
      );
      _businessName = businessName;
      _phone = phone;
      _location = location;
      if (response['data']?['user'] != null) {
        _user = User.fromJson(response['data']['user']);
      }
      _error = null;
      if (dashboardProvider != null) {
        await dashboardProvider.fetchDashboard();
      }
    } on ApiException catch (e) {
      _error = e.message;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Logout: clear local user info and notify listeners
  Future<void> logout() async {
    try {
      await _apiService.logout();
      _user = null;
      _businessName = '';
      _phone = '';
      _location = '';
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// Call on logout to fully clear provider state (for stateless session)
  void clear() {
    _user = null;
    _businessName = '';
    _phone = '';
    _location = '';
    _isLoading = false;
    _error = null;
    notifyListeners();
  }
}
