import 'package:flutter/foundation.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'package:ufad/backend/models/account_model.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';
import 'package:ufad/backend/models/purchase_model.dart';

class PaymentProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Account> _accounts = [];
  List<Purchase> _purchases = [];
  List<PaymentTransaction> _transactions = [];
  final Map<String, List<String>> _transactionComments = {};
  bool _isLoading = false;
  String? _error;
  int? _userId;

  String? _filterType;
  String? _filterAccountId;
  DateTime? _filterStartDate;
  DateTime? _filterEndDate;

  PaymentProvider({ApiService? apiService}) : _apiService = apiService ?? ApiService();

  List<Account> get accounts => List.unmodifiable(_accounts);
  List<Purchase> get purchases => List.unmodifiable(_purchases);
  List<PaymentTransaction> get transactions => List.unmodifiable(_transactions);
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;

  double get totalBalance => _accounts.fold(0.0, (sum, a) => sum + a.balance);

  List<PaymentTransaction> get filteredTransactions {
    return _transactions.where((tx) {
      final matchType = _filterType == null || _filterType!.isEmpty || tx.type.toLowerCase() == _filterType!.toLowerCase();
      final matchAccount = _filterAccountId == null || _filterAccountId!.isEmpty || tx.account == _filterAccountId;
      final matchStart = _filterStartDate == null || !tx.date.isBefore(_filterStartDate!);
      final matchEnd = _filterEndDate == null || !tx.date.isAfter(_filterEndDate!);
      return matchType && matchAccount && matchStart && matchEnd;
    }).toList();
  }

  void setFilters({
    String? type,
    String? accountId,
    DateTime? startDate,
    DateTime? endDate,
  }) {
    _filterType = type;
    _filterAccountId = accountId;
    _filterStartDate = startDate;
    _filterEndDate = endDate;
    notifyListeners();
  }

  void clearFilters() {
    setFilters(type: null, accountId: null, startDate: null, endDate: null);
  }

  /// Set user id (after login/register); triggers full reload if changed.
  void setUserId(int userId) {
    if (_userId != userId) {
      _userId = userId;
      fetchAll();
    }
  }

  /// Fetch all payment/account-related data for this user (batch load).
  Future<void> fetchAll() async {
    await Future.wait([
      fetchAccounts(batch: true),
      fetchPurchases(batch: true),
      fetchTransactions(batch: true),
    ]);
    notifyListeners();
  }

  Future<void> fetchAccounts({bool batch = false}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      if (!batch) notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    if (!batch) notifyListeners();
    try {
      _accounts = await _apiService.fetchAccounts(userId: _userId!);
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      if (!batch) notifyListeners();
    }
  }

  Future<void> addAccount(Account account) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.addAccount(account, userId: _userId!);
      await fetchAccounts();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> updateAccount(Account account) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.updateAccount(account, userId: _userId!);
      await fetchAccounts();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deleteAccount(int accountId) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.deleteAccount(accountId, userId: _userId!);
      await fetchAccounts();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> fetchPurchases({bool batch = false}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      if (!batch) notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    if (!batch) notifyListeners();
    try {
      _purchases = await _apiService.fetchPurchases(userId: _userId!);
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      if (!batch) notifyListeners();
    }
  }

  Future<void> addPurchase(Purchase purchase) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.addPurchase(purchase, userId: _userId!);
      await fetchPurchases();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> updatePurchase(Purchase purchase) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.updatePurchase(purchase, userId: _userId!);
      await fetchPurchases();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deletePurchase(int purchaseId) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.deletePurchase(purchaseId, userId: _userId!);
      await fetchPurchases();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> fetchTransactions({bool batch = false}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      if (!batch) notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    if (!batch) notifyListeners();
    try {
      _transactions = await _apiService.fetchPaymentTransactions(userId: _userId!);
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      if (!batch) notifyListeners();
    }
  }

  Future<void> addTransaction(PaymentTransaction tx) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.addPaymentTransaction(tx, userId: _userId!);
      await fetchTransactions();
      await fetchAccounts();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> updateTransaction(PaymentTransaction tx) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.updatePaymentTransaction(tx, userId: _userId!);
      await fetchTransactions();
      await fetchAccounts();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deleteTransaction(int txId) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.deletePaymentTransaction(txId, userId: _userId!);
      await fetchTransactions();
      await fetchAccounts();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  void addComment(String transactionId, String comment) {
    if (comment.isEmpty) {
      _error = 'Comment cannot be empty';
      notifyListeners();
      return;
    }
    final comments = _transactionComments.putIfAbsent(transactionId, () => []);
    comments.add(comment);
    notifyListeners();
  }

  List<String> getComments(String transactionId) {
    return List.unmodifiable(_transactionComments[transactionId] ?? []);
  }

  void deleteComment(String transactionId, int index) {
    final comments = _transactionComments[transactionId];
    if (comments != null && index >= 0 && index < comments.length) {
      comments.removeAt(index);
      notifyListeners();
    }
  }

  void clear() {
    _userId = null;
    _accounts.clear();
    _purchases.clear();
    _transactions.clear();
    _transactionComments.clear();
    _isLoading = false;
    _error = null;
    clearFilters();
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
