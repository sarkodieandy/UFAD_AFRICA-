import 'package:flutter/material.dart';
import 'package:ufad/backend/models/product_model.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'dashboard_provider.dart';

class ProductProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Product> _products = [];
  int? _categoryFilter;
  String _priceSort = '';
  bool _isLoading = false;
  String? _error;
  int? _userId;

  ProductProvider({ApiService? apiService})
      : _apiService = apiService ?? ApiService();

  List<Product> get products {
    var filtered = [..._products];
    if (_categoryFilter != null) {
      filtered = filtered.where((p) => p.category.id == _categoryFilter).toList();
    }
    if (_priceSort == 'asc') {
      filtered.sort((a, b) => a.sellingPrice.compareTo(b.sellingPrice));
    } else if (_priceSort == 'desc') {
      filtered.sort((a, b) => b.sellingPrice.compareTo(a.sellingPrice));
    }
    return filtered;
  }

  int? get categoryFilter => _categoryFilter;
  String get priceSort => _priceSort;
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;

  void setUserId(int userId) {
    _userId = userId;
    fetchProducts();
  }

  Future<void> fetchProducts({bool batch = false}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      if (!batch) notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    if (!batch) notifyListeners();
    try {
      _products = await _apiService.fetchProducts(userId: _userId!);
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      if (!batch) notifyListeners();
    }
  }

  void setCategoryFilter(int? categoryId) {
    _categoryFilter = categoryId;
    notifyListeners();
  }

  void setPriceSort(String sort) {
    _priceSort = sort;
    notifyListeners();
  }

  void clearFilters() {
    _categoryFilter = null;
    _priceSort = '';
    notifyListeners();
  }

  Future<void> addProduct(Product product, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.addProduct(product, userId: _userId!);
      await fetchProducts();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> updateProduct(Product product, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.updateProduct(product, userId: _userId!);
      await fetchProducts();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deleteProduct(int id, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.deleteProduct(id, userId: _userId!);
      await fetchProducts();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
