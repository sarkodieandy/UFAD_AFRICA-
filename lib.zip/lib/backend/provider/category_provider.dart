import 'package:flutter/material.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/models/category_model.dart';
import 'package:ufad/backend/util/api_exception.dart';

class CategoryProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Category> _categories = [];
  bool _isLoading = false;
  String? _error;
  int? _userId;

  CategoryProvider({ApiService? apiService}) : _apiService = apiService ?? ApiService();

  List<Category> get categories => List.unmodifiable(_categories);
  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;

  void setUserId(int userId) {
    _userId = userId;
    fetchCategories();
  }

  Future<void> fetchCategories() async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _categories = await _apiService.fetchCategories(userId: _userId!);
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addCategory(Category category) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.addCategory(category, userId: _userId!);
      await fetchCategories();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> updateCategory(Category category) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.updateCategory(category, userId: _userId!);
      await fetchCategories();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  Future<void> deleteCategory(int id) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    try {
      await _apiService.deleteCategory(id, userId: _userId!);
      await fetchCategories();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
