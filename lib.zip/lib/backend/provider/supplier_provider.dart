import 'package:flutter/material.dart';
import 'package:ufad/backend/models/supplier.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'dashboard_provider.dart';

class SupplierProvider with ChangeNotifier {
  final ApiService _apiService;
  List<Supplier> _suppliers = [];
  bool _isLoading = false;
  String? _error;
  int? _userId;
  String? _categoryFilter;
  String? _typeFilter;

  SupplierProvider({ApiService? apiService}) : _apiService = apiService ?? ApiService();

  // Filtered supplier list for UI
  List<Supplier> get suppliers {
    var filtered = _suppliers;
    if (_categoryFilter != null && _categoryFilter!.isNotEmpty) {
      filtered = filtered.where((s) => s.category == _categoryFilter).toList();
    }
    if (_typeFilter != null && _typeFilter!.isNotEmpty) {
      filtered = filtered.where((s) => s.type == _typeFilter).toList();
    }
    return filtered;
  }

  bool get isLoading => _isLoading;
  String? get error => _error;
  int? get userId => _userId;
  String? get categoryFilter => _categoryFilter;
  String? get typeFilter => _typeFilter;

  /// Sets the current user ID and triggers fetch for user-specific suppliers
  void setUserId(int userId) {
    _userId = userId;
    fetchSuppliers();
  }

  /// Loads all suppliers for the logged-in user
  Future<void> fetchSuppliers() async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      _suppliers = await _apiService.fetchSuppliers(userId: _userId!);
      _error = null;
    } on ApiException catch (e) {
      _error = e.message;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Adds a supplier and reloads supplier list (optionally refresh dashboard)
  Future<void> addSupplier(Supplier supplier, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.addSupplier(supplier, userId: _userId!);
      await fetchSuppliers();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  /// Edits a supplier and reloads supplier list (optionally refresh dashboard)
  Future<void> editSupplier(Supplier supplier, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    if (supplier.id == null) {
      _error = 'Supplier ID is missing';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.updateSupplier(supplier, userId: _userId!);
      await fetchSuppliers();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  /// Deletes a supplier and reloads supplier list (optionally refresh dashboard)
  Future<void> deleteSupplier(int id, {DashboardProvider? dashboardProvider}) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _error = null;
    try {
      await _apiService.deleteSupplier(id, userId: _userId!);
      await fetchSuppliers();
      if (dashboardProvider != null) await dashboardProvider.fetchDashboard();
    } on ApiException catch (e) {
      _error = e.message;
    }
    notifyListeners();
  }

  // Filter setters
  void setCategoryFilter(String? cat) {
    _categoryFilter = cat;
    notifyListeners();
  }
  void setTypeFilter(String? type) {
    _typeFilter = type;
    notifyListeners();
  }
  void clearFilters() {
    _categoryFilter = null;
    _typeFilter = null;
    notifyListeners();
  }
  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// Call this on logout/session clear
  void clear() {
    _userId = null;
    _suppliers.clear();
    _isLoading = false;
    _error = null;
    _categoryFilter = null;
    _typeFilter = null;
    notifyListeners();
  }
}
