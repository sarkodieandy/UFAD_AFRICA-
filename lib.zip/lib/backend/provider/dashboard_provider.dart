import 'package:flutter/material.dart';
import 'package:ufad/backend/services/api_services.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'package:ufad/backend/models/business_profile.dart';
import 'package:ufad/backend/models/transaction_model.dart';

class DashboardProvider with ChangeNotifier {
  final ApiService _apiService;

  int? _userId;
  bool isLoading = false;
  String? error;

  Map<String, dynamic> _metrics = {};
  BusinessProfile? businessProfile;
  List<String> salesTrendLabels = [];
  List<double> salesTrendValues = [];
  List<Transaction> _transactions = [];

  String periodFilter = 'day';
  int? categoryIdFilter;
  String sectorFilter = '';
  DateTime? lastUpdated;

  DashboardProvider({ApiService? apiService})
      : _apiService = apiService ?? ApiService();

  // Getters for UI
  Map<String, dynamic> get metrics => _metrics;
  BusinessProfile get profile => businessProfile ?? BusinessProfile(name: "Business", phone: "No Phone", location: "No Location");
  List<String> get salesLabels => salesTrendLabels;
  List<double> get salesValues => salesTrendValues;
  List<Transaction> get transactions => _transactions;
  int? get userId => _userId;

  // Set user id and fetch dashboard after login
  void setUserId(int userId) {
    _userId = userId;
    fetchDashboard();
  }

  // Main dashboard fetcher
  Future<void> fetchDashboard() async {
    if (_userId == null) return;
    isLoading = true;
    error = null;
    notifyListeners();
    try {
      final response = await _apiService.fetchDashboard(
        userId: _userId!,
        period: periodFilter,
        categoryId: categoryIdFilter,
      );
      final data = response['data'] ?? {};

      _metrics = Map<String, dynamic>.from(data['metrics'] ?? {});
      businessProfile = data['business_profile'] != null
          ? BusinessProfile.fromJson(data['business_profile'])
          : null;

      // Sales trend
      final salesTrend = data['sales_trend'] ?? {};
      salesTrendLabels = (salesTrend['labels'] as List? ?? []).map((e) => e.toString()).toList();
      salesTrendValues = (salesTrend['values'] as List? ?? []).map((e) => (e is num) ? e.toDouble() : double.tryParse(e.toString()) ?? 0.0).toList();

      // Transactions
      _transactions = (data['transactions'] as List? ?? [])
          .map((e) => Transaction.fromJson(e as Map<String, dynamic>)).toList();

      error = null;
      lastUpdated = DateTime.now();
    } on ApiException catch (e) {
      error = e.message;
    } catch (e) {
      error = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // Set period/category filters and refresh
  void setPeriodFilter(String period) {
    if (periodFilter != period) {
      periodFilter = period;
      fetchDashboard();
    }
  }
  void setCategoryFilter(int? categoryId) {
    if (categoryIdFilter != categoryId) {
      categoryIdFilter = categoryId;
      fetchDashboard();
    }
  }
  void setSectorFilter(String sector) {
    sectorFilter = sector;
    fetchDashboard();
  }
  void resetFilters() {
    periodFilter = 'day';
    categoryIdFilter = null;
    fetchDashboard();
  }

  // Clear on logout
  void clearUser() {
    _userId = null;
    _metrics = {};
    businessProfile = null;
    salesTrendLabels = [];
    salesTrendValues = [];
    _transactions = [];
    error = null;
    notifyListeners();
  }

  // Manual refresh
  Future<void> refresh() async => fetchDashboard();
}
