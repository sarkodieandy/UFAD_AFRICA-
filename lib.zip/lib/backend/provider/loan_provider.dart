import 'package:flutter/foundation.dart';
import 'package:ufad/backend/services/api_services.dart';

class LoanProvider with ChangeNotifier {
  List<Map<String, dynamic>> _myLoans = [];
  bool _hasOffers = false;
  double _totalDebt = 0.0;
  double _paid = 0.0;
  double _balance = 0.0;
  String _deadline = 'N/A';
  List<Map<String, dynamic>> _paymentHistory = [];
  bool _isLoading = false;
  String? _error;
  int? _userId;

  List<Map<String, dynamic>> get myLoans => _myLoans;
  bool get hasOffers => _hasOffers;
  double get totalDebt => _totalDebt;
  double get paid => _paid;
  double get balance => _balance;
  String get deadline => _deadline;
  List<Map<String, dynamic>> get paymentHistory => _paymentHistory;
  bool get isLoading => _isLoading;
  String? get error => _error;

  final ApiService _apiService = ApiService();

  void setUserId(int userId) {
    _userId = userId;
    notifyListeners();
  }

  Future<void> applyLoan({
    required String product,
    required double amount,
    required String tenure,
  }) async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await _apiService.applyLoan(
        userId: _userId!,
        product: product,
        amount: amount,
        tenure: tenure,
      );
      await fetchRepayments();
      _error = null;
    } catch (e) {
      _error = e.toString();
      if (kDebugMode) print('Apply loan failed: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> fetchRepayments() async {
    if (_userId == null) {
      _error = 'No user logged in';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final List<Map<String, dynamic>> data =
          await _apiService.fetchLoanRepayments(userId: _userId!);

      // These keys may be in any entry (or only one!)
      _totalDebt = 0.0;
      _paid = 0.0;
      _balance = 0.0;
      _deadline = 'N/A';
      _myLoans = [];
      _paymentHistory = [];
      _hasOffers = false;

      for (final entry in data) {
        // If this entry is a loan
        if (entry.containsKey('loan_id')) {
          _myLoans.add(Map<String, dynamic>.from(entry));
        }
        // If this entry is a payment
        if (entry.containsKey('payment_id')) {
          _paymentHistory.add(Map<String, dynamic>.from(entry));
        }
        // These can exist on any entry, so check and set:
        if (entry.containsKey('total_debt')) {
          _totalDebt = _asDouble(entry['total_debt']);
        }
        if (entry.containsKey('paid')) {
          _paid = _asDouble(entry['paid']);
        }
        if (entry.containsKey('balance')) {
          _balance = _asDouble(entry['balance']);
        }
        if (entry.containsKey('deadline')) {
          _deadline = entry['deadline']?.toString() ?? 'N/A';
        }
        if (entry.containsKey('has_offers')) {
          _hasOffers = entry['has_offers'] == true || entry['has_offers'] == 1 || entry['has_offers'] == "true";
        }
      }

      _error = null;
    } catch (e) {
      _error = e.toString();
      if (kDebugMode) print('Fetch repayments failed: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  double _asDouble(dynamic val) {
    if (val is double) return val;
    if (val is int) return val.toDouble();
    if (val is String) return double.tryParse(val) ?? 0.0;
    return 0.0;
  }

  void reset() {
    _userId = null;
    _myLoans = [];
    _hasOffers = false;
    _totalDebt = 0.0;
    _paid = 0.0;
    _balance = 0.0;
    _deadline = 'N/A';
    _paymentHistory = [];
    _isLoading = false;
    _error = null;
    notifyListeners();
  }
}
