import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:ufad/backend/models/account_model.dart';
import 'package:ufad/backend/models/category_model.dart';
import 'package:ufad/backend/models/customer_model.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';
import 'package:ufad/backend/models/pos_model.dart';
import 'package:ufad/backend/models/product_model.dart';
import 'package:ufad/backend/models/purchase_model.dart';
import 'package:ufad/backend/models/supplier.dart';
import 'package:ufad/backend/util/api_exception.dart';
import 'package:ufad/backend/util/input_validator.dart';

class ApiService {
  static const String _baseUrl = 'https://ufad.ufadafrica.com/api/index.php';
  static const String _basicAuth = 'Basic YWRtaW46MTIzNDU2Nzg=';
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    'Authorization': _basicAuth,
  };

  Future<void> _storeToken(String token) async {
    await _storage.write(key: 'auth_token', value: token);
  }

  Future<void> _clearToken() async {
    await _storage.delete(key: 'auth_token');
  }

  void _handleResponse(http.Response response, {bool isPost = false, bool isDelete = false}) {
    final expectedStatus = isDelete ? 204 : (isPost ? 201 : 200);
    if (response.statusCode == expectedStatus) return;
    final data = response.statusCode != 204 ? jsonDecode(response.body) : {};
    final message = data['message'] ?? 'Unknown error';
    switch (response.statusCode) {
      case 400: throw ApiException.badRequest(message);
      case 401: throw ApiException.unauthorized(message);
      case 404: throw ApiException.badRequest('Not Found: $message');
      case 500: throw ApiException.serverError(message);
      default: throw ApiException.unknown('Unexpected error: ${response.statusCode} - $message');
    }
  }

  Future<Map<String, dynamic>> signup(Map<String, dynamic> data) async {
    InputValidator.validateSignupData(data);
    final payload = <String, dynamic>{
      "username": data["username"] ?? "",
      "email": data["email"] ?? "",
      "password": data["password"] ?? "",
      "first_name": data["first_name"] ?? "",
      "last_name": data["last_name"] ?? "",
      "mobile_number": data["mobile_number"] ?? "",
      "region_id": data["region_id"] ?? 1,
      "district_id": data["district_id"] ?? 1,
      "town_id": data["town_id"] ?? 1,
      if (data["profile_image"] != null && data["profile_image"].toString().isNotEmpty)
        "profile_image": data["profile_image"],
      if (data["full_name"] != null && data["full_name"].toString().isNotEmpty)
        "full_name": data["full_name"],
      "gender": data["gender"] ?? "",
      "age_group": data["age_group"] ?? "",
      "national_id_type": data["national_id_type"] ?? "",
      "business_name": data["business_name"] ?? "",
      "business_type": data["business_type"] ?? "",
      "business_registered": data["business_registered"] ?? "",
      "business_sector": data["business_sector"] ?? "",
      "main_product_service": data["main_product_service"] ?? "",
      "business_start_year": data["business_start_year"] ?? DateTime.now().year,
      "business_location": data["business_location"] ?? "",
      if (data["gps_address"] != null && data["gps_address"].toString().isNotEmpty)
        "gps_address": data["gps_address"],
      "business_phone": data["business_phone"] ?? "",
      "estimated_weekly_sales": data["estimated_weekly_sales"] ?? "",
      "number_of_workers": data["number_of_workers"] ?? "",
      "record_keeping_method": data["record_keeping_method"] ?? "",
      if (data["mobile_money_number"] != null && data["mobile_money_number"].toString().isNotEmpty)
        "mobile_money_number": data["mobile_money_number"],
      "has_insurance": data["has_insurance"] ?? "",
      "pension_scheme": data["pension_scheme"] ?? "",
      "bank_loan": data["bank_loan"] ?? "",
      "terms_agreed": data["terms_agreed"] ?? "yes",
      "receive_updates": data["receive_updates"] ?? "yes",
      "support_needs": data["support_needs"] ?? [],
    };
    final response = await http.post(
      Uri.parse('$_baseUrl/signup'),
      headers: _headers,
      body: jsonEncode(payload),
    );
    _handleResponse(response, isPost: true);
    final result = jsonDecode(response.body);
    final token = result['data']?['token']?.toString();
    if (token != null) await _storeToken(token);
    return result;
  }

  Future<Map<String, dynamic>> login(String login, String password) async {
    InputValidator.validateLogin(login, password);
    final uri = Uri.parse('$_baseUrl/login').replace(queryParameters: {'login': login, 'password': password});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final result = jsonDecode(response.body);
    final token = result['data']['user']['token']?.toString();
    if (token != null) await _storeToken(token);
    return result;
  }

  Future<void> logout() async {
    await _clearToken();
  }

  Future<Map<String, dynamic>> fetchDashboard({required int userId, String? period, int? categoryId}) async {
    final uri = Uri.parse('$_baseUrl/dashboard').replace(queryParameters: {
      'user_id': userId.toString(),
      if (period != null) 'period': period,
      if (categoryId != null) 'category_id': categoryId.toString(),
    });
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    return jsonDecode(response.body);
  }

  Future<List<Customer>> fetchCustomers({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/customers').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Customer.fromJson(e)).toList();
  }

  Future<void> addCustomer(Customer customer, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/customers').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(customer.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<void> updateCustomer(Customer customer, {required int userId}) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/customers/${customer.id}').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(customer.toJson()),
    );
    _handleResponse(response);
  }

  Future<void> deleteCustomer(int id, {required int userId}) async {
    final response = await http.delete(
      Uri.parse('$_baseUrl/customers/$id').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
    );
    _handleResponse(response, isDelete: true);
  }

  Future<List<Product>> fetchProducts({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/products').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Product.fromJson(e)).toList();
  }

  Future<void> addProduct(Product product, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/products').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(product.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<void> updateProduct(Product product, {required int userId}) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/products/${product.id}').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(product.toJson()),
    );
    _handleResponse(response);
  }

  Future<void> deleteProduct(int id, {required int userId}) async {
    final response = await http.delete(
      Uri.parse('$_baseUrl/products/$id').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
    );
    _handleResponse(response, isDelete: true);
  }

  Future<List<PosSale>> fetchPosSales({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/pos-sales').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => PosSale.fromJson(e)).toList();
  }

  Future<void> addPosSale(PosSale sale, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/pos-sales').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(sale.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<void> updatePosSale(PosSale sale, {required int userId}) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/pos-sales/${sale.id}').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(sale.toJson()),
    );
    _handleResponse(response);
  }

  Future<void> deletePosSale(int id, {required int userId}) async {
    final response = await http.delete(
      Uri.parse('$_baseUrl/pos-sales/$id').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
    );
    _handleResponse(response, isDelete: true);
  }

  Future<List<Account>> fetchAccounts({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/accounts').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Account.fromJson(e)).toList();
  }

  Future<void> addAccount(Account account, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/accounts').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(account.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<List<Purchase>> fetchPurchases({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/purchases').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Purchase.fromJson(e)).toList();
  }

  Future<void> addPurchase(Purchase purchase, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/purchases').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(purchase.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<List<Purchase>> fetchStockPurchases({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/stock-purchases').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Purchase.fromJson(e)).toList();
  }

  Future<void> addStockPurchase(Purchase purchase, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/stock-purchases').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(purchase.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<void> updateStockPurchase(Purchase purchase, {required int userId}) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/stock-purchases/${purchase.id}').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(purchase.toJson()),
    );
    _handleResponse(response);
  }

  Future<void> deleteStockPurchase(int id, {required int userId}) async {
    final response = await http.delete(
      Uri.parse('$_baseUrl/stock-purchases/$id').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
    );
    _handleResponse(response, isDelete: true);
  }

  Future<List<Category>> fetchCategories({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/categories').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Category.fromJson(e)).toList();
  }

  Future<List<Supplier>> fetchSuppliers({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/suppliers').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return data.map((e) => Supplier.fromJson(e)).toList();
  }

  Future<void> addSupplier(Supplier supplier, {required int userId}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/suppliers').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(supplier.toJson()),
    );
    _handleResponse(response, isPost: true);
  }

  Future<void> updateSupplier(Supplier supplier, {required int userId}) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/suppliers/${supplier.id}').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode(supplier.toJson()),
    );
    _handleResponse(response);
  }

  Future<void> deleteSupplier(int id, {required int userId}) async {
    final response = await http.delete(
      Uri.parse('$_baseUrl/suppliers/$id').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
    );
    _handleResponse(response, isDelete: true);
  }
Future<List<PaymentTransaction>> fetchPaymentTransactions({required int userId}) async {
  final uri = Uri.parse('$_baseUrl/payment-transactions').replace(queryParameters: {'user_id': userId.toString()});
  final response = await http.get(uri, headers: _headers);
  _handleResponse(response);
  final data = jsonDecode(response.body)['data'] as List;
  return data.map((e) => PaymentTransaction.fromJson(e)).toList();
}

Future<void> addPaymentTransaction(PaymentTransaction tx, {required int userId}) async {
  final response = await http.post(
    Uri.parse('$_baseUrl/payment-transactions').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
    body: jsonEncode(tx.toJson()),
  );
  _handleResponse(response, isPost: true);
}

Future<void> updatePaymentTransaction(PaymentTransaction tx, {required int userId}) async {
  final response = await http.put(
    Uri.parse('$_baseUrl/payment-transactions/${tx.id}').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
    body: jsonEncode(tx.toJson()),
  );
  _handleResponse(response);
}

Future<void> deletePaymentTransaction(int id, {required int userId}) async {
  final response = await http.delete(
    Uri.parse('$_baseUrl/payment-transactions/$id').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
  );
  _handleResponse(response, isDelete: true);
}



  Future<void> applyLoan({required int userId, required String product, required double amount, required String tenure}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/loans').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode({"product": product, "amount": amount, "tenure": tenure}),
    );
    _handleResponse(response, isPost: true);
  }

  Future<List<Map<String, dynamic>>> fetchLoanRepayments({required int userId}) async {
    final uri = Uri.parse('$_baseUrl/loan-repayments').replace(queryParameters: {'user_id': userId.toString()});
    final response = await http.get(uri, headers: _headers);
    _handleResponse(response);
    final data = jsonDecode(response.body)['data'] as List;
    return List<Map<String, dynamic>>.from(data);
  }Future<void> updateAccount(Account account, {required int userId}) async {
  final response = await http.put(
    Uri.parse('$_baseUrl/accounts/${account.id}').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
    body: jsonEncode(account.toJson()),
  );
  _handleResponse(response);
}

Future<void> deleteAccount(int accountId, {required int userId}) async {
  final response = await http.delete(
    Uri.parse('$_baseUrl/accounts/$accountId').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
  );
  _handleResponse(response, isDelete: true);
}

Future<void> updatePurchase(Purchase purchase, {required int userId}) async {
  final response = await http.put(
    Uri.parse('$_baseUrl/purchases/${purchase.id}').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
    body: jsonEncode(purchase.toJson()),
  );
  _handleResponse(response);
}

Future<void> deletePurchase(int purchaseId, {required int userId}) async {
  final response = await http.delete(
    Uri.parse('$_baseUrl/purchases/$purchaseId').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
  );
  _handleResponse(response, isDelete: true);
}
Future<void> addCategory(Category category, {required int userId}) async {
  final response = await http.post(
    Uri.parse('$_baseUrl/categories').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
    body: jsonEncode(category.toJson()),
  );
  _handleResponse(response, isPost: true);
}

Future<void> updateCategory(Category category, {required int userId}) async {
  final response = await http.put(
    Uri.parse('$_baseUrl/categories/${category.id}').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
    body: jsonEncode(category.toJson()),
  );
  _handleResponse(response);
}

Future<void> deleteCategory(int id, {required int userId}) async {
  final response = await http.delete(
    Uri.parse('$_baseUrl/categories/$id').replace(queryParameters: {'user_id': userId.toString()}),
    headers: _headers,
  );
  _handleResponse(response, isDelete: true);
}



  Future<Map<String, dynamic>> updateUserProfile({required int userId, required String name, required String phone, required String location, required String businessName}) async {
    final response = await http.put(
      Uri.parse('$_baseUrl/profile').replace(queryParameters: {'user_id': userId.toString()}),
      headers: _headers,
      body: jsonEncode({
        "name": name,
        "phone": phone,
        "location": location,
        "business_name": businessName,
      }),
    );
    _handleResponse(response);
    return jsonDecode(response.body);
  }
}
