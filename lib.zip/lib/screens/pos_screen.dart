import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:ufad/backend/provider/pos_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/add_Sale_dialogue.dart';
import 'package:ufad/widgets/filter_bar.dart';
import 'package:ufad/widgets/metricGrid.dart';
import 'package:ufad/widgets/pay_debit.dart';
import 'package:ufad/widgets/posSale_table.dart';
import 'package:ufad/widgets/pos_header_widget.dart';

class PosScreen extends StatelessWidget {
  const PosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final posProvider = Provider.of<PosProvider>(context);

    return Scaffold(
      backgroundColor: AppColors.gray50,
      body: SafeArea(
        child: posProvider.isLoading
            ? const Center(child: CircularProgressIndicator())
            : posProvider.error != null
                ? Center(child: Text('Error: ${posProvider.error}'))
                : LayoutBuilder(
                    builder: (context, constraints) {
                      final isMobile = constraints.maxWidth < 500;
                      return ListView(
                        padding: EdgeInsets.fromLTRB(
                          12,
                          10,
                          12,
                          12 + MediaQuery.of(context).viewInsets.bottom,
                        ),
                        children: [
                          Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.arrow_back_ios_new, color: AppColors.teal600),
                                tooltip: "Back to Dashboard",
                                onPressed: () => Navigator.of(context).pop(),
                              ),
                              const Expanded(child: PosHeader()),
                            ],
                          ),
                          const SizedBox(height: 18),
                          const MetricsGrid(),
                          const SizedBox(height: 28),
                          // --- FILTER BAR ---
                          FilterBar(
                            onFilter: ({
                              String? dateRange,
                              DateTime? startDate,
                              DateTime? endDate,
                              String? debtor,
                              bool? debtorsOnly,
                            }) {
                              posProvider.setFilters(
                                customer: debtor,
                                // Status: 'paid', 'debt', or null
                                status: debtorsOnly == true
                                    ? 'debt'
                                    : null,
                                startDate: startDate,
                                endDate: endDate,
                              );
                            },
                          ),
                          const SizedBox(height: 20),
                          isMobile
                              ? Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      "Sales",
                                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                                    ),
                                    const SizedBox(height: 12),
                                    Row(
                                      children: [
                                        ElevatedButton.icon(
                                          icon: const Icon(Icons.add),
                                          label: const Text("New Sale"),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: AppColors.teal600,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                          ),
                                          onPressed: () => showDialog(
                                            context: context,
                                            builder: (_) => const AddSaleDialog(),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        ElevatedButton.icon(
                                          icon: const Icon(Icons.money),
                                          label: const Text("Pay Debt"),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: AppColors.teal600,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                          ),
                                          onPressed: () => showDialog(
                                            context: context,
                                            builder: (_) => const PayDebtDialog(customer: ''),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      "Sales",
                                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                                    ),
                                    Row(
                                      children: [
                                        ElevatedButton.icon(
                                          icon: const Icon(Icons.add),
                                          label: const Text("New Sale"),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: AppColors.teal600,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                          ),
                                          onPressed: () => showDialog(
                                            context: context,
                                            builder: (_) => const AddSaleDialog(),
                                          ),
                                        ),
                                        const SizedBox(width: 10),
                                        ElevatedButton.icon(
                                          icon: const Icon(Icons.money),
                                          label: const Text("Pay Debt"),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: AppColors.teal600,
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                          ),
                                          onPressed: () => showDialog(
                                            context: context,
                                            builder: (_) => const PayDebtDialog(customer: ''),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                          const SizedBox(height: 14),
                          // --- SALES TABLE (filteredSales not sales) ---
                          PosSaleTable(sales: posProvider.filteredSales),
                        ],
                      );
                    },
                  ),
      ),
    );
  }
}
