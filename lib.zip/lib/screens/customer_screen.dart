import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/customer_model.dart';
import 'package:ufad/backend/provider/customer_provider.dart';
import 'package:ufad/backend/provider/dashboard_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/add_customerSheet.dart';
import 'package:ufad/widgets/custom_filterbar.dart';
import 'package:ufad/widgets/custom_table.dart';

class CustomerScreen extends StatelessWidget {
  const CustomerScreen({super.key});

  void _showAddCustomerModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddCustomerSheet(
        onSave: (customer) async {
          final customerProvider = Provider.of<CustomerProvider>(context, listen: false);
          final dashboardProvider = Provider.of<DashboardProvider>(context, listen: false);
          await customerProvider.addCustomer(customer, dashboardProvider: dashboardProvider);
          if (customerProvider.error == null) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Customer added and dashboard updated!')),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error: ${customerProvider.error}')),
            );
          }
          Navigator.pop(context);
        },
      ),
    );
  }

  void _showEditCustomerModal(BuildContext context, Customer customer) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddCustomerSheet(
        customer: customer,
        onSave: (updatedCustomer) async {
          final customerProvider = Provider.of<CustomerProvider>(context, listen: false);
          final dashboardProvider = Provider.of<DashboardProvider>(context, listen: false);
          await customerProvider.updateCustomer(updatedCustomer, dashboardProvider: dashboardProvider);
          if (customerProvider.error == null) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Customer updated and dashboard refreshed!')),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error: ${customerProvider.error}')),
            );
          }
          Navigator.pop(context);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canPop = Navigator.of(context).canPop();
    final provider = Provider.of<CustomerProvider>(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        backgroundColor: Colors.white.withOpacity(0.95),
        elevation: 0,
        automaticallyImplyLeading: canPop,
        leading: canPop
            ? IconButton(
                icon: const Icon(Icons.arrow_back_ios_new, color: AppColors.teal600),
                onPressed: () => Navigator.of(context).maybePop(),
                tooltip: 'Back',
              )
            : null,
        title: Row(
          children: [
            ShaderMask(
              shaderCallback: (bounds) => LinearGradient(
                colors: [AppColors.teal600, AppColors.teal400],
              ).createShader(bounds),
              child: const Icon(Icons.people_alt, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 10),
            const Text(
              "Customer Management",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColors.teal600,
                fontSize: 18,
                letterSpacing: 0.1,
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: CircleAvatar(
              backgroundColor: AppColors.teal500,
              child: IconButton(
                icon: const Icon(Icons.account_circle, color: AppColors.teal600, size: 26),
                onPressed: () => Navigator.pushNamed(context, '/profile'),
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.teal500, Colors.white],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          if (provider.isLoading)
            const Center(child: CircularProgressIndicator())
          else if (provider.error != null)
            Center(
              child: Text(
                provider.error == 'No user logged in'
                    ? 'Please log in to manage customers.'
                    : 'Error: ${provider.error}',
                style: const TextStyle(color: Colors.redAccent, fontSize: 16),
                textAlign: TextAlign.center,
              ),
            )
          else
            ListView(
              padding: const EdgeInsets.fromLTRB(18, 70, 18, 16),
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Customers",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.add, size: 20),
                      label: const Text("Add", style: TextStyle(fontSize: 13)),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        backgroundColor: AppColors.teal400,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                        elevation: 2,
                        minimumSize: const Size(10, 38),
                      ),
                      onPressed: () => _showAddCustomerModal(context),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        // ignore: deprecated_member_use
                        color: AppColors.teal600.withOpacity(0.06),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: const CustomerFilterBar(),
                ),
                const SizedBox(height: 12),
                if (provider.filteredCustomers.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 30),
                    child: Center(
                      child: Text(
                        'No customers found. Tap "Add" to create one!',
                        style: TextStyle(color: Colors.grey, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                else
                  CustomerTable(
                    customers: provider.filteredCustomers,
                    onEdit: (customer) => _showEditCustomerModal(context, customer),
                    onDelete: (customer) async {
                      final customerProvider = Provider.of<CustomerProvider>(context, listen: false);
                      final dashboardProvider = Provider.of<DashboardProvider>(context, listen: false);
                      await customerProvider.deleteCustomer(customer.id!, dashboardProvider: dashboardProvider);
                      if (customerProvider.error == null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Customer deleted and dashboard updated!')),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Error: ${customerProvider.error}')),
                        );
                      }
                    },
                  ),
                const SizedBox(height: 40),
              ],
            ),
        ],
      ),
    );
  }
}
