import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:ufad/backend/provider/registration_provider.dart';

class BusinessInfoScreen extends StatefulWidget {
  const BusinessInfoScreen({super.key});
  @override
  State<BusinessInfoScreen> createState() => _BusinessInfoScreenState();
}

class _BusinessInfoScreenState extends State<BusinessInfoScreen> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final productController = TextEditingController();
  final locationController = TextEditingController();
  final gpsController = TextEditingController();
  final phoneController = TextEditingController();
  String? businessType;
  String? registrationStatus;
  String? selectedSector;
  int? selectedYear;
  File? registrationFile;
  bool _isLoading = false;

  final businessTypes = ['informal', 'sole_proprietor', 'partnership', 'other'];
  final sectors = [
    'retail',
    'agriculture',
    'food',
    'transport',
    'services',
    'other',
  ];
  final years = [for (int i = DateTime.now().year; i >= 2000; i--) i];

  @override
  void initState() {
    super.initState();
    final reg = Provider.of<RegistrationProvider>(context, listen: false).registration;
    if (reg != null) {
      nameController.text = reg.businessName;
      productController.text = reg.mainProductService;
      locationController.text = reg.businessLocation;
      gpsController.text = reg.gpsAddress ?? '';
      phoneController.text = reg.businessPhone;
      businessType = reg.businessType.isNotEmpty ? reg.businessType : null;
      registrationStatus = reg.businessRegistered.isNotEmpty ? reg.businessRegistered : null;
      selectedSector = reg.businessSector.isNotEmpty ? reg.businessSector : null;
      selectedYear = reg.businessStartYear != 0 ? reg.businessStartYear : null;
      registrationFile = reg.registrationDocument != null && reg.registrationDocument!.isNotEmpty
          ? File(reg.registrationDocument!)
          : null;
    }
  }

  Future<void> _pickRegistrationFile() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null && mounted) {
      setState(() => registrationFile = File(picked.path));
    }
  }

  Future<void> _onNext() async {
    if (!_formKey.currentState!.validate() ||
        businessType == null ||
        registrationStatus == null ||
        selectedSector == null ||
        selectedYear == null ||
        (registrationStatus == 'yes' && registrationFile == null)) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            registrationStatus == 'yes' && registrationFile == null
                ? 'Please attach a registration document.'
                : 'Please fill all required fields',
          ),
        ),
      );
      return;
    }
    setState(() => _isLoading = true);
    final provider = Provider.of<RegistrationProvider>(context, listen: false);
    final reg = provider.registration;
    if (reg == null) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Missing owner data')),
      );
      return;
    }

    String? registrationDocumentBase64;
    if (registrationFile != null) {
      final bytes = await registrationFile!.readAsBytes();
      registrationDocumentBase64 = base64Encode(bytes);
    }

    provider.setRegistration(
      reg.copyWith(
        businessName: nameController.text,
        businessType: businessType!,
        businessRegistered: registrationStatus!.toLowerCase(),
        registrationDocument: registrationDocumentBase64,
        businessSector: selectedSector!,
        mainProductService: productController.text,
        businessStartYear: selectedYear!,
        businessLocation: locationController.text,
        gpsAddress: gpsController.text.isEmpty ? null : gpsController.text,
        businessPhone: phoneController.text,
      ),
    );

    setState(() => _isLoading = false);
    if (mounted) Navigator.pushNamed(context, '/business-activity');
  }

  @override
  void dispose() {
    nameController.dispose();
    productController.dispose();
    locationController.dispose();
    gpsController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Business Info'),
        backgroundColor: const Color(0xFF1BAEA6),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Business Name'),
              const SizedBox(height: 6),
              TextFormField(
                controller: nameController,
                validator: (val) => val == null || val.isEmpty ? 'Required' : null,
                decoration: const InputDecoration(hintText: 'Enter your business name'),
              ).animate().fadeIn(),
              const SizedBox(height: 16),
              const Text('Type of Business'),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: businessType,
                decoration: const InputDecoration(hintText: 'Select type'),
                items: businessTypes
                    .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.replaceAll('_', ' ').toUpperCase()),
                        ))
                    .toList(),
                onChanged: _isLoading ? null : (val) => setState(() => businessType = val),
                validator: (val) => val == null ? 'Required' : null,
              ).animate().fadeIn(delay: 100.ms),
              const SizedBox(height: 16),
              const Text('Business Registration'),
              Row(
                children: [
                  Expanded(
                    child: RadioListTile<String>(
                      title: const Text('Yes'),
                      value: 'yes',
                      groupValue: registrationStatus,
                      onChanged: _isLoading
                          ? null
                          : (val) => setState(() => registrationStatus = val),
                    ),
                  ),
                  Expanded(
                    child: RadioListTile<String>(
                      title: const Text('No'),
                      value: 'no',
                      groupValue: registrationStatus,
                      onChanged: _isLoading
                          ? null
                          : (val) => setState(() {
                              registrationStatus = val;
                              if (registrationStatus != 'yes') registrationFile = null;
                            }),
                    ),
                  ),
                ],
              ).animate().fadeIn(delay: 200.ms),
              if (registrationStatus == 'yes') ...[
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _pickRegistrationFile,
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Attach Registration Document'),
                ).animate().fadeIn(delay: 300.ms),
                if (registrationFile != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'File selected: ${registrationFile!.path.split('/').last}',
                      style: const TextStyle(color: Colors.black54),
                    ),
                  ).animate().fadeIn(delay: 400.ms),
              ],
              const SizedBox(height: 16),
              const Text('Business Sector'),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: selectedSector,
                decoration: const InputDecoration(hintText: 'Select sector'),
                items: sectors
                    .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.toUpperCase()),
                        ))
                    .toList(),
                onChanged: _isLoading ? null : (val) => setState(() => selectedSector = val),
                validator: (val) => val == null ? 'Required' : null,
              ).animate().fadeIn(delay: 500.ms),
              const SizedBox(height: 16),
              const Text('Main Product or Service Offered'),
              const SizedBox(height: 6),
              TextFormField(
                controller: productController,
                validator: (val) => val == null || val.isEmpty ? 'Required' : null,
                decoration: const InputDecoration(hintText: 'Enter product/service'),
              ).animate().fadeIn(delay: 600.ms),
              const SizedBox(height: 16),
              const Text('Business Start Year'),
              const SizedBox(height: 6),
              DropdownButtonFormField<int>(
                value: selectedYear,
                decoration: const InputDecoration(hintText: 'Select year'),
                items: years
                    .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.toString()),
                        ))
                    .toList(),
                onChanged: _isLoading ? null : (val) => setState(() => selectedYear = val),
                validator: (val) => val == null ? 'Required' : null,
              ).animate().fadeIn(delay: 700.ms),
              const SizedBox(height: 16),
              const Text('Business Location (Town / Area)'),
              const SizedBox(height: 6),
              TextFormField(
                controller: locationController,
                validator: (val) => val == null || val.isEmpty ? 'Required' : null,
                decoration: const InputDecoration(hintText: 'Enter location'),
              ).animate().fadeIn(delay: 800.ms),
              const SizedBox(height: 16),
              const Text('GPS Address'),
              const SizedBox(height: 6),
              TextFormField(
                controller: gpsController,
                decoration: const InputDecoration(hintText: 'Enter GPS address'),
              ).animate().fadeIn(delay: 900.ms),
              const SizedBox(height: 16),
              const Text('Business Phone'),
              const SizedBox(height: 6),
              TextFormField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                validator: (val) => val == null || !RegExp(r'^\+\d{10,15}$').hasMatch(val)
                    ? 'Enter valid phone'
                    : null,
                decoration: const InputDecoration(hintText: 'Enter phone number'),
              ).animate().fadeIn(delay: 1000.ms),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _onNext,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1BAEA6),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Next', style: TextStyle(fontSize: 16)),
                ),
              ).animate().fadeIn(delay: 1100.ms),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
