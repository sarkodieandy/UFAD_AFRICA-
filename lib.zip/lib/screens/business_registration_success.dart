import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class BusinessRegistrationSuccessScreen extends StatefulWidget {
  const BusinessRegistrationSuccessScreen({super.key});

  @override
  State<BusinessRegistrationSuccessScreen> createState() =>
      _BusinessRegistrationSuccessScreenState();
}

class _BusinessRegistrationSuccessScreenState
    extends State<BusinessRegistrationSuccessScreen> {
  @override
  void initState() {
    super.initState();
    // Auto-navigate after a short delay (2 seconds)
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/dashboard', (_) => false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28.0, vertical: 24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Green check with scale and fade animation
              Container(
                padding: const EdgeInsets.all(26),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.09),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_circle_rounded,
                  color: Colors.green,
                  size: 90,
                )
                  .animate()
                  .scaleXY(begin: 0.5, end: 1, duration: 600.ms)
                  .fadeIn(duration: 600.ms),
              ),
              const SizedBox(height: 28),
              // "Success!" headline
              Text(
                'Success!',
                style: theme.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.green[800],
                  letterSpacing: 0.5,
                ),
                textAlign: TextAlign.center,
              ).animate().fadeIn(delay: 100.ms),
              const SizedBox(height: 16),
              // Subtext
              Text(
                'Your registration was completed.\nRedirecting to dashboard...',
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: Colors.black54,
                  height: 1.45,
                ),
                textAlign: TextAlign.center,
              ).animate().fadeIn(delay: 250.ms),
              const SizedBox(height: 34),
              // Progress bar animation
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.0, end: 1.0),
                duration: 2.seconds,
                builder: (context, value, _) => LinearProgressIndicator(
                  value: value,
                  minHeight: 5,
                  // ignore: deprecated_member_use
                  backgroundColor: Colors.green.withOpacity(0.13),
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                  borderRadius: BorderRadius.circular(8),
                ),
              ).animate().fadeIn(delay: 400.ms),
            ],
          ),
        ),
      ),
    );
  }
}
