import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/stock_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/add_purchase_sheet.dart';
import 'package:ufad/widgets/custom_drawer.dart';
import 'package:ufad/widgets/stock_table.dart';
import '../widgets/stock_metric_card.dart';
import '../widgets/stock_filter_bar.dart';


class StockScreen extends StatelessWidget {
  const StockScreen({super.key});

  void _showAddPurchaseModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => const AddPurchaseSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StockProvider>(context);
    final canPop = Navigator.of(context).canPop();

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        // ignore: deprecated_member_use
        backgroundColor: Colors.white.withOpacity(0.95),
        elevation: 0,
        automaticallyImplyLeading: canPop,
        leading: canPop
            ? IconButton(
                icon: const Icon(Icons.arrow_back_ios_new, color: AppColors.teal600),
                onPressed: () => Navigator.of(context).maybePop(),
                tooltip: 'Back',
              )
            : null,
        title: Row(
          children: [
            ShaderMask(
              shaderCallback: (Rect bounds) {
                return LinearGradient(
                  colors: [AppColors.teal600, AppColors.teal400],
                ).createShader(bounds);
              },
              child: const Icon(Icons.warehouse, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 10),
            const Text(
              "Stock Management",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColors.teal600,
                fontSize: 18,
                letterSpacing: 0.1,
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: CircleAvatar(
              backgroundColor: AppColors.teal500,
              child: IconButton(
                icon: const Icon(Icons.account_circle, color: AppColors.teal600, size: 26),
                onPressed: () => Navigator.pushNamed(context, '/profile'),
              ),
            ),
          ),
        ],
      ),
      drawer: const CustomDrawer(),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.teal500, Colors.white],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          provider.isLoading
              ? const Center(child: CircularProgressIndicator())
              : provider.error != null
                  ? Center(child: Text('Error: ${provider.error}'))
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(18, 70, 18, 16),
                      children: [
                        SizedBox(
                          height: 90,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              StockMetricCard(
                                label: "Total Paid",
                                index: 0,
                              ),
                              StockMetricCard(
                                label: "Total Unpaid",
                                index: 1,
                              ),
                              StockMetricCard(
                                label: "Balance to be Paid",
                                index: 2,
                              ),
                              StockMetricCard(
                                label: "Current Stock Value",
                                index: 3,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Stock Purchases",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            ElevatedButton.icon(
                              icon: const Icon(Icons.add, size: 20),
                              label: const Text("Add", style: TextStyle(fontSize: 13)),
                              style: ElevatedButton.styleFrom(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                backgroundColor: AppColors.teal400,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                                elevation: 2,
                                minimumSize: const Size(10, 38),
                              ),
                              onPressed: () => _showAddPurchaseModal(context),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Container(
                          decoration: BoxDecoration(
                            // ignore: deprecated_member_use
                            color: Colors.white.withOpacity(0.92),
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: [
                              BoxShadow(
                                // ignore: deprecated_member_use
                                color: AppColors.teal600.withOpacity(0.06),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                          child: const StockFilterBar(),
                        ),
                        const SizedBox(height: 14),
                        const StockTable(),
                        const SizedBox(height: 40),
                      ],
                    ),
        ],
      ),
    );
  }
}