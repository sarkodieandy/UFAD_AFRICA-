import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/account_Card.dart';
import 'package:ufad/widgets/account_metrics.dart';
import 'package:ufad/widgets/add_deposite_dialogue.dart';
import 'package:ufad/widgets/expense_dialogue.dart';
import 'package:ufad/widgets/pay_supplier_dialogue.dart';
import 'package:ufad/widgets/payment_filter_bar.dart';
import 'package:ufad/widgets/transaction_table.dart';
import 'package:ufad/widgets/transfer_dialogue.dart';
import 'package:ufad/widgets/account_dialogue.dart';

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  void _showModal(BuildContext context, Widget child) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 16,
          right: 16,
          top: 20,
        ),
        child: SingleChildScrollView(child: child),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PaymentProvider>(context);
    final accounts = provider.accounts;
    final transactions = provider.transactions;

    return Scaffold(
      backgroundColor: AppColors.gray100,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: ShaderMask(
          shaderCallback: (bounds) {
            return const LinearGradient(
              colors: [AppColors.teal600, AppColors.blue500],
            ).createShader(bounds);
          },
          child: const Text(
            'Payment Management',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : provider.error != null
              ? Center(child: Text('Error: ${provider.error}'))
              : LayoutBuilder(
                  builder: (context, constraints) {
                    final isWide = constraints.maxWidth > 800;
                    final isSmall = constraints.maxWidth < 600;

                    return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (accounts.isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Hero(
                                  tag: 'main-account',
                                  child: AccountCard(account: accounts.first, isPrimary: true),
                                ),
                                const SizedBox(height: 16),
                                AccountMetric(
                                  label: "Total Balance",
                                  value: "GHS ${provider.totalBalance.toStringAsFixed(2)}",
                                  highlight: true,
                                ),
                              ],
                            ),
                          const SizedBox(height: 24),
                          if (accounts.length > 1)
                            GridView.count(
                              crossAxisCount: isWide ? 3 : 1,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              mainAxisSpacing: 12,
                              crossAxisSpacing: 14,
                              childAspectRatio: 2.8,
                              children: accounts
                                  .skip(1)
                                  .map((a) => AccountCard(account: a))
                                  .toList(),
                            ),
                          const SizedBox(height: 28),
                          isSmall
                              ? Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      "Transactions",
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.teal600,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Wrap(
                                      spacing: 10,
                                      runSpacing: 10,
                                      children: _buildActionButtons(context),
                                    ),
                                  ],
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      "Transactions",
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        color: AppColors.teal600,
                                      ),
                                    ),
                                    Wrap(
                                      spacing: 10,
                                      children: _buildActionButtons(context),
                                    ),
                                  ],
                                ),
                          const SizedBox(height: 20),
                          PaymentFilterBar(
                            onClear: () => provider.clearFilters(),
                          ),
                          const SizedBox(height: 20),
                          TransactionTable(transactions: transactions),
                        ],
                      ),
                    );
                  },
                ),
    );
  }

  List<Widget> _buildActionButtons(BuildContext context) {
    return [
      _ActionButton(
        icon: Icons.add,
        label: "Deposit",
        color: Colors.green,
        onTap: () => _showModal(context, const AddDepositDialog()),
      ),
      _ActionButton(
        icon: Icons.account_balance,
        label: "Add Account",
        color: AppColors.blue500,
        onTap: () => _showModal(context, const AddAccountDialog()),
      ),
      _ActionButton(
        icon: Icons.monetization_on_outlined,
        label: "Pay Supplier",
        color: AppColors.teal600,
        onTap: () => _showModal(context, const PaySupplierDialog()),
      ),
      _ActionButton(
        icon: Icons.compare_arrows_rounded,
        label: "Transfer",
        color: Colors.orange,
        onTap: () => _showModal(context, const TransferDialog()),
      ),
      _ActionButton(
        icon: Icons.remove,
        label: "Expense",
        color: AppColors.warningRed,
        onTap: () => _showModal(context, const ExpenseDialog()),
      ),
    ];
  }
}

class _ActionButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          // ignore: deprecated_member_use
          color: _hover ? widget.color.withOpacity(0.15) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          // ignore: deprecated_member_use
          border: Border.all(color: widget.color.withOpacity(0.3)),
          boxShadow: _hover
              ? [
                  BoxShadow(
                    // ignore: deprecated_member_use
                    color: widget.color.withOpacity(0.15),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  )
                ]
              : [],
        ),
        child: InkWell(
          onTap: widget.onTap,
          borderRadius: BorderRadius.circular(12),
          child: Row(
            children: [
              Icon(widget.icon, color: widget.color, size: 20),
              const SizedBox(width: 6),
              Text(
                widget.label,
                style: TextStyle(
                  color: widget.color,
                  fontWeight: _hover ? FontWeight.bold : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
