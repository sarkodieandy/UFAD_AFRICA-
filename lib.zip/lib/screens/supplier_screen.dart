import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/supplier.dart';
import 'package:ufad/backend/provider/supplier_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/suplier_filterbar.dart';
import 'package:ufad/widgets/supplier_form.dart';
import 'package:ufad/widgets/supplier_list.dart';

class SupplierScreen extends StatefulWidget {
  const SupplierScreen({super.key});

  @override
  State<SupplierScreen> createState() => _SupplierScreenState();
}

class _SupplierScreenState extends State<SupplierScreen> {
  void _showSupplierForm({Supplier? supplier}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: SupplierForm(
          supplier: supplier,
          onSave: (newSupplier) async {
            final provider = Provider.of<SupplierProvider>(
              context,
              listen: false,
            );
            if (supplier != null && supplier.id != null) {
              await provider.editSupplier(newSupplier);
            } else {
              await provider.addSupplier(newSupplier);
            }
            Navigator.pop(ctx);
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final supplierProvider = Provider.of<SupplierProvider>(context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        title: const Text(
          'Supplier Management',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: AppColors.teal600,
          ),
        ),
        iconTheme: const IconThemeData(color: AppColors.teal600),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: CircleAvatar(
              backgroundColor: AppColors.teal500,
              child: IconButton(
                icon: const Icon(
                  Icons.account_circle,
                  color: AppColors.teal600,
                  size: 26,
                ),
                onPressed: () => Navigator.pushNamed(context, '/profile'),
              ),
            ),
          ),
        ],
      ),
      body: supplierProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : supplierProvider.error != null
              ? Center(child: Text('Error: ${supplierProvider.error}'))
              : LayoutBuilder(
                  builder: (context, constraints) {
                    final isSmallScreen = constraints.maxWidth < 400;
                    return ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Suppliers",
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                fontSize: 19,
                              ),
                            ),
                            ElevatedButton.icon(
                              icon: const Icon(Icons.add, size: 20),
                              label: const Text(
                                "Add",
                                style: TextStyle(fontSize: 13),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.teal400,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: EdgeInsets.symmetric(
                                  horizontal: isSmallScreen ? 8 : 15,
                                  vertical: 8,
                                ),
                                minimumSize: Size(10, isSmallScreen ? 36 : 40),
                              ),
                              onPressed: () => _showSupplierForm(),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SupplierFilterBar(
                          onCategoryChanged: supplierProvider.setCategoryFilter,
                          onTypeChanged: supplierProvider.setTypeFilter,
                          selectedCategory: supplierProvider.categoryFilter,
                          selectedType: supplierProvider.typeFilter,
                        ),
                        const SizedBox(height: 16),
                        SupplierList(
                          suppliers: supplierProvider.suppliers,
                          onEdit: (supplier) => _showSupplierForm(supplier: supplier),
                          onDelete: (supplier) => supplierProvider.deleteSupplier(supplier.id!),
                        ),
                      ],
                    );
                  },
                ),
    );
  }
}
