import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/dashboard_provider.dart';
import 'package:ufad/backend/models/business_profile.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/metricCard_widget.dart';
import 'package:ufad/widgets/profile_card.dart';
import 'package:ufad/widgets/chart_widget.dart';
import 'package:ufad/widgets/custom_drawer.dart';
import 'package:ufad/widgets/search_widget.dart';

// --- SKELETON LOADER WIDGET ---
class _MetricSkeleton extends StatelessWidget {
  const _MetricSkeleton();
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Container(
        height: 68,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: AppColors.gray200.withOpacity(0.3),
        ),
        child: Center(
          child: Container(
            width: 70,
            height: 16,
            color: AppColors.gray200.withOpacity(0.7),
          ),
        ),
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  DateTime? _currentBackPressTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final dashboardProvider = Provider.of<DashboardProvider>(context, listen: false);
      if (dashboardProvider.userId == null) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      } else {
        dashboardProvider.fetchDashboard();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final dashboardProvider = Provider.of<DashboardProvider>(context);

    final businessProfile = dashboardProvider.businessProfile ??
        BusinessProfile(name: 'Business Name', phone: 'No Phone', location: 'No Location');
    final metrics = dashboardProvider.metrics;
    final loading = dashboardProvider.isLoading;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        key: _scaffoldKey,
        drawer: const CustomDrawer(),
        appBar: AppBar(
          title: Text(
            '${businessProfile.name} Dashboard',
            style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
          backgroundColor: AppColors.teal600,
          foregroundColor: Colors.white,
          actions: [
            IconButton(
              icon: const Icon(Icons.account_circle),
              onPressed: () => _showUserMenu(context),
            ),
          ],
        ),
        body: RefreshIndicator(
          onRefresh: dashboardProvider.refresh,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SearchWidget(),
                const SizedBox(height: 16),
                const Text('Key Metrics', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                // ---- METRICS GRID with skeletons ----
                if (loading && metrics.isEmpty)
                  Row(children: [const Expanded(child: _MetricSkeleton()), const Expanded(child: _MetricSkeleton())])
                else if (metrics.isEmpty)
                  Row(
                    children: [
                      Expanded(child: MetricCard(title: "Revenue", value: "0", icon: Icons.data_thresholding, color: AppColors.teal600)),
                      Expanded(child: MetricCard(title: "Orders", value: "0", icon: Icons.shopping_cart, color: AppColors.teal600)),
                    ],
                  )
                else
                  _buildMetricsGrid(metrics),
                const SizedBox(height: 16),
                // ---- FILTERS ----
                _buildFilters(dashboardProvider),
                const SizedBox(height: 16),
                // ---- CHART & PROFILE
                LayoutBuilder(
                  builder: (context, constraints) {
                    if (constraints.maxWidth > 600) {
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: Card(
                              elevation: 2,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              child: const Padding(
                                padding: EdgeInsets.all(18.0),
                                child: ChartWidget(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 20),
                          Expanded(
                            flex: 1,
                            child: ProfileCard(
                              profile: businessProfile,
                              onViewProfile: () {
                                showDialog(
                                  context: context,
                                  builder: (context) => ProfileCard(
                                    profile: businessProfile,
                                    onViewProfile: () {},
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      );
                    } else {
                      return Column(
                        children: [
                          Card(
                            elevation: 2,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            child: const Padding(
                              padding: EdgeInsets.all(18.0),
                              child: ChartWidget(),
                            ),
                          ),
                          const SizedBox(height: 18),
                          ProfileCard(
                            profile: businessProfile,
                            onViewProfile: () {
                              showDialog(
                                context: context,
                                builder: (context) => ProfileCard(
                                  profile: businessProfile,
                                  onViewProfile: () {},
                                ),
                              );
                            },
                          ),
                        ],
                      );
                    }
                  },
                ),
                const SizedBox(height: 18),
                // ---- RECENT TRANSACTIONS ----
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Recent Transactions', style: TextStyle(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        dashboardProvider.transactions.isEmpty
                            ? const Text('No recent transactions')
                            : ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: dashboardProvider.transactions.length > 5
                                    ? 5
                                    : dashboardProvider.transactions.length,
                                itemBuilder: (context, index) {
                                  final t = dashboardProvider.transactions[index];
                                  return ListTile(
                                    leading: const Icon(Icons.monetization_on),
                                    title: Text('${t.type}: GHS ${t.amount.toStringAsFixed(2)}'),
                                    // ignore: unnecessary_type_check
                                    subtitle: Text(t.date is String ? t.date : t.date.toString()),
                                  );
                                },
                              ),
                      ],
                    ),
                  ),
                ),
                // --- LAST UPDATED
                if (dashboardProvider.lastUpdated != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(
                      "Last updated: ${TimeOfDay.fromDateTime(dashboardProvider.lastUpdated!).format(context)}",
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMetricsGrid(Map<String, dynamic> metrics) {
    final List<Widget> metricCards = [];
    metrics.forEach((key, value) {
      metricCards.add(
        MetricCard(
          title: key,
          value: value.toString(),
          icon: Icons.data_thresholding,
          color: AppColors.teal600,
        ),
      );
    });
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 1.5,
      children: metricCards,
    );
  }

  Widget _buildFilters(DashboardProvider dashboardProvider) {
    return Row(
      children: [
        Expanded(
          child: DropdownButtonFormField<String>(
            value: dashboardProvider.periodFilter,
            decoration: InputDecoration(
              labelText: 'Period',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
            items: const [
              DropdownMenuItem(value: 'day', child: Text('Today')),
              DropdownMenuItem(value: 'week', child: Text('This Week')),
              DropdownMenuItem(value: 'month', child: Text('This Month')),
              DropdownMenuItem(value: 'year', child: Text('This Year')),
            ],
            onChanged: (value) {
              if (value != null) {
                dashboardProvider.setPeriodFilter(value);
              }
            },
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: DropdownButtonFormField<String>(
            value: dashboardProvider.sectorFilter,
            decoration: InputDecoration(
              labelText: 'Sector',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
            items: const [
              DropdownMenuItem(value: '', child: Text('All Sectors')),
              DropdownMenuItem(value: '5', child: Text('Clothing')),
              // Add more sector/category values as needed
            ],
            onChanged: (value) {
              dashboardProvider.setSectorFilter(value ?? '');
              int? catId = value != null && value.isNotEmpty ? int.tryParse(value) : null;
              dashboardProvider.setCategoryFilter(catId);
            },
          ),
        ),
      ],
    );
  }

  void _showUserMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Profile'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/profile');
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Settings'),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/settings');
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout'),
            onTap: () async {
              Navigator.pop(context);
              Provider.of<DashboardProvider>(context, listen: false).clearUser();
              Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
            },
          ),
        ],
      ),
    );
  }

  Future<bool> _onWillPop() async {
    final now = DateTime.now();
    if (_currentBackPressTime == null || now.difference(_currentBackPressTime!) > const Duration(seconds: 2)) {
      _currentBackPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Press back again to exit'),
          duration: Duration(seconds: 2),
        ),
      );
      return false;
    }
    return true;
  }
}
