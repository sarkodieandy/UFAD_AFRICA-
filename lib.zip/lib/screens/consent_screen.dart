import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/registration_provider.dart';
import 'package:ufad/backend/util/api_exception.dart';

class ConsentScreen extends StatefulWidget {
  const ConsentScreen({super.key});

  @override
  State<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  bool agreeToTerms = true;
  bool agreeToUpdates = true;

  Future<void> _submitRegistration() async {
    final provider = Provider.of<RegistrationProvider>(context, listen: false);
    if (!agreeToTerms) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('You must agree to Terms and Policy')),
      );
      return;
    }
    final reg = provider.registration;
    if (reg == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Missing registration data.')),
      );
      return;
    }
    try {
      // Set terms and updates before submitting
      provider.setRegistration(
        reg.copyWith(
          termsAgreed: agreeToTerms ? 'yes' : 'no',
          receiveUpdates: agreeToUpdates ? 'yes' : 'no',
        ),
      );
      await provider.submitRegistration(context);

      // On success, navigate to success screen
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/registration-success',
          (_) => false,
        );
      }
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to submit registration: ${e.message}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<RegistrationProvider>(context);
    final isLoading = provider.isLoading;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Consent'),
        backgroundColor: const Color(0xFF1BAEA6),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        children: [
          CheckboxListTile(
            value: agreeToTerms,
            activeColor: const Color(0xFF1BAEA6),
            onChanged: isLoading
                ? null
                : (val) => setState(() => agreeToTerms = val ?? false),
            title: Row(
              children: [
                const Expanded(child: Text('I agree to UFAD’s Terms and Data Use Policy')),
                TextButton(
                  onPressed: isLoading ? null : () => Navigator.pushNamed(context, '/terms'),
                  child: const Text('View', style: TextStyle(fontSize: 13)),
                ),
              ],
            ),
          ).animate().fadeIn(),
          CheckboxListTile(
            value: agreeToUpdates,
            activeColor: const Color(0xFF1BAEA6),
            onChanged: isLoading
                ? null
                : (val) => setState(() => agreeToUpdates = val ?? false),
            title: const Text('I agree to receive updates and support from UFAD'),
          ).animate().fadeIn(delay: 100.ms),
          const SizedBox(height: 30),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: isLoading ? null : _submitRegistration,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1BAEA6),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: isLoading
                  ? const CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    )
                  : const Text(
                      'Submit Registration',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
            ),
          ).animate().fadeIn(delay: 200.ms),
        ],
      ),
    );
  }
}
