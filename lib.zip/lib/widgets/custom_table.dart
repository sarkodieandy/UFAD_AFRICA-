import 'package:flutter/material.dart';
import 'package:ufad/backend/models/customer_model.dart';
import 'package:ufad/backend/util/app_colors.dart';

class CustomerTable extends StatelessWidget {
  final List<Customer> customers;
  final Function(Customer) onDelete;
  final Function(Customer) onEdit;

  const CustomerTable({
    super.key,
    required this.customers,
    required this.onDelete,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    if (customers.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 60),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline, color: AppColors.teal200, size: 58),
            const SizedBox(height: 10),
            Text(
              'No customers found',
              style: TextStyle(
                color: AppColors.gray800,
                fontSize: 17,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 5),
            const Text(
              'Add new customers to get started.',
              style: TextStyle(color: Colors.black54, fontSize: 13),
            ),
          ],
        ),
      );
    }

    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(AppColors.teal50),
          dataRowColor: WidgetStateProperty.resolveWith<Color?>(
            (states) =>
                // ignore: deprecated_member_use
                states.contains(WidgetState.hovered) ? AppColors.teal50.withOpacity(0.14) : null,
          ),
          columnSpacing: 28,
          columns: const [
            // DataColumn(label: Text('#')), // Uncomment if you want index
            DataColumn(label: Text('Name', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Email', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Phone', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Category', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Account Type', style: TextStyle(fontWeight: FontWeight.bold))),
            DataColumn(label: Text('Actions', style: TextStyle(fontWeight: FontWeight.bold))),
          ],
          rows: customers.asMap().entries.map((entry) {
            final customer = entry.value;
            return DataRow(
              // Optionally highlight recently edited/added customer, etc.
              cells: [
                // DataCell(Text((i + 1).toString())), // Uncomment for index
                DataCell(Text(customer.name)),
                DataCell(Text(customer.email)),
                DataCell(Text(customer.phone)),
                DataCell(Text(customer.category.isNotEmpty ? customer.category : "-")),
                DataCell(Text(customer.accountType.isNotEmpty ? customer.accountType : "-")),
                DataCell(
                  Row(
                    children: [
                      Tooltip(
                        message: 'Edit customer',
                        waitDuration: const Duration(milliseconds: 700),
                        child: IconButton(
                          icon: const Icon(Icons.edit, color: AppColors.blue500, size: 20),
                          onPressed: () => onEdit(customer),
                          splashRadius: 18,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Tooltip(
                        message: 'Delete customer',
                        waitDuration: const Duration(milliseconds: 700),
                        child: IconButton(
                          icon: const Icon(Icons.delete, color: AppColors.warningRed, size: 20),
                          onPressed: () => onDelete(customer),
                          splashRadius: 18,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}
