import 'package:flutter/material.dart';

class SupplierFilterBar extends StatelessWidget {
  final ValueChanged<String?> onCategoryChanged;
  final ValueChanged<String?> onTypeChanged;
  final String? selectedCategory;
  final String? selectedType;

  static const categories = [
    '', // empty string represents "All"
    'Clothing',
    'Electronics',
    'Food',
    'Pharmacy',
    'Other',
  ];
  static const types = [
    '',
    'Individual',
    'Business',
    'Retail',
    'Wholesale',
  ];

  const SupplierFilterBar({
    super.key,
    required this.onCategoryChanged,
    required this.onTypeChanged,
    this.selectedCategory,
    this.selectedType,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      child: Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<String>(
              value: selectedCategory ?? '',
              decoration: InputDecoration(
                labelText: 'Category',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              isExpanded: true,
              items: categories.map(
                (cat) => DropdownMenuItem<String>(
                  value: cat,
                  child: Text(cat.isEmpty ? 'All' : cat),
                ),
              ).toList(),
              onChanged: onCategoryChanged,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: DropdownButtonFormField<String>(
              value: selectedType ?? '',
              decoration: InputDecoration(
                labelText: 'Type',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              isExpanded: true,
              items: types.map(
                (type) => DropdownMenuItem<String>(
                  value: type,
                  child: Text(type.isEmpty ? 'All' : type),
                ),
              ).toList(),
              onChanged: onTypeChanged,
            ),
          ),
        ],
      ),
    );
  }
}
