import 'package:flutter/material.dart';

IconData getCategoryIcon(String iconName) {
  switch (iconName) {
    case 'laptop':
      return Icons.laptop_mac;
    case 'car':
      return Icons.directions_car;
    case 'electronics':
      return Icons.devices_other;
    case 'food':
      return Icons.fastfood;
    case 'books':
      return Icons.menu_book;
    case 'clothing':
      return Icons.checkroom;
    case 'beauty':
      return Icons.spa;
    case 'furniture':
      return Icons.chair_alt;
    case 'jewelry':
      return Icons.diamond;
    case 'appliances':
      return Icons.kitchen;
    case 'sports':
      return Icons.sports_soccer;
    case 'toys':
      return Icons.toys;
    default:
      return Icons.category;
  }
}
