import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/pos_model.dart';
import 'package:ufad/backend/provider/pos_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class AddSaleDialog extends StatefulWidget {
  final PosSale? sale;
  final int? index;

  const AddSaleDialog({super.key, this.sale, this.index});

  @override
  State<AddSaleDialog> createState() => _AddSaleDialogState();
}

class _AddSaleDialogState extends State<AddSaleDialog> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _customerController;
  late TextEditingController _totalController;
  late TextEditingController _paidController;
  String _status = 'Unpaid';
  DateTime _dueDate = DateTime.now();
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _customerController = TextEditingController(text: widget.sale?.customer ?? '');
    _totalController = TextEditingController(text: widget.sale?.total.toStringAsFixed(2) ?? '');
    _paidController = TextEditingController(text: widget.sale?.paid.toStringAsFixed(2) ?? '');
    _status = widget.sale?.status ?? 'Unpaid';
    _dueDate = widget.sale?.dueDate ?? DateTime.now();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..forward();
    _scale = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _customerController.dispose();
    _totalController.dispose();
    _paidController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Color getStatusColor(String status) {
    switch (status) {
      case 'Paid':
        return Colors.green.shade400;
      case 'Partially Paid':
        return Colors.orange.shade400;
      case 'Unpaid':
      default:
        return Colors.red.shade400;
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PosProvider>(context, listen: false);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ScaleTransition(
      scale: _scale,
      child: AlertDialog(
        backgroundColor: isDark ? AppColors.gray100 : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
        titlePadding: const EdgeInsets.fromLTRB(22, 18, 22, 10),
        title: Row(
          children: [
            Icon(Icons.point_of_sale, color: AppColors.teal600, size: 25),
            const SizedBox(width: 8),
            Text(
              widget.sale == null ? 'Add Sale' : 'Edit Sale',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 19,
                color: AppColors.teal600,
              ),
            ),
            const Spacer(),
            Chip(
              label: Text(_status,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
              backgroundColor: getStatusColor(_status),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
              visualDensity: VisualDensity.compact,
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: SizedBox(
              width: MediaQuery.of(context).size.width < 400 ? double.infinity : 380,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: _customerController,
                    decoration: InputDecoration(
                      labelText: 'Customer Name',
                      prefixIcon: const Icon(Icons.person_outline),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(11)),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                    ),
                    validator: (v) => v == null || v.isEmpty ? 'Enter customer name' : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _totalController,
                    decoration: InputDecoration(
                      labelText: 'Total (GHS)',
                      prefixText: 'GHS ',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(11)),
                      prefixIcon: const Icon(Icons.attach_money),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                    ),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    validator: (v) =>
                        v == null || double.tryParse(v) == null || double.parse(v) <= 0
                            ? 'Enter valid total'
                            : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _paidController,
                    decoration: InputDecoration(
                      labelText: 'Paid (GHS)',
                      prefixText: 'GHS ',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(11)),
                      prefixIcon: const Icon(Icons.payment),
                      contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                    ),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    validator: (v) =>
                        v == null || double.tryParse(v) == null || double.parse(v) < 0
                            ? 'Enter valid amount'
                            : null,
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    value: _status,
                    decoration: InputDecoration(
                      labelText: 'Status',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(11)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    items: ['Paid', 'Unpaid', 'Partially Paid']
                        .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                        .toList(),
                    onChanged: (v) => setState(() => _status = v ?? 'Unpaid'),
                    validator: (v) => v == null ? 'Select status' : null,
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Icon(Icons.calendar_month, color: AppColors.teal400, size: 20),
                      const SizedBox(width: 8),
                      const Text('Due Date: ', style: TextStyle(fontSize: 14)),
                      TextButton(
                        onPressed: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _dueDate,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2100),
                          );
                          if (picked != null) setState(() => _dueDate = picked);
                        },
                        child: Text(DateFormat('yyyy-MM-dd').format(_dueDate),
                          style: const TextStyle(fontWeight: FontWeight.w500)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(fontSize: 15)),
          ),
          ElevatedButton.icon(
            icon: Icon(widget.sale == null ? Icons.add : Icons.save, size: 18),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.teal400,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              elevation: 1,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            ),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                final total = double.parse(_totalController.text);
                final paid = double.parse(_paidController.text);
                final balance = (total - paid).clamp(0.0, total).toDouble();
                final percent = total == 0 ? 0.0 : (paid / total * 100).clamp(0.0, 100.0);
                final sale = PosSale(
                  id: widget.sale?.id,
                  customer: _customerController.text,
                  total: total,
                  paid: paid,
                  balance: balance,
                  status: _status,
                  dueDate: _dueDate,
                  percent: percent,
                  saleDate: widget.sale?.saleDate ?? DateTime.now(),
                );
                if (widget.sale != null) {
                  provider.updateSale(sale);
                } else {
                  provider.addSale(sale);
                }
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(widget.sale == null ? 'Sale added' : 'Sale updated')),
                );
              }
            },
            label: Text(widget.sale == null ? 'Add' : 'Update', style: const TextStyle(fontSize: 16)),
          ),
        ],
      ),
    );
  }
}
