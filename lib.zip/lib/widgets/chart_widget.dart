import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/dashboard_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class ChartWidget extends StatelessWidget {
  const ChartWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final dashboardProvider = Provider.of<DashboardProvider>(context);

    // Use trend data if present, else fallback to transactions.
    final labels = dashboardProvider.salesLabels;
    final values = dashboardProvider.salesValues;

    final bool hasTrend = labels.isNotEmpty && values.isNotEmpty && labels.length == values.length;

    // Fallback to transaction list
    final txns = dashboardProvider.transactions;
    final fallbackLabels = txns.map((t) {
      try {
        final dt = DateTime.parse(t.date);
        return '${dt.month}/${dt.day}';
      } catch (_) {
        return '';
      }
    }).toList();
    final fallbackValues = txns.map((t) => t.amount).toList();

    final chartLabels = hasTrend ? labels : fallbackLabels;
    final chartValues = hasTrend ? values : fallbackValues;

    if (chartLabels.isEmpty || chartValues.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: Text(
            "No chart data available.",
            style: TextStyle(
              color: AppColors.teal600,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      );
    }

    final spots = List.generate(
      chartValues.length,
      (i) => FlSpot(i.toDouble(), chartValues[i]),
    );

    final maxY = (chartValues.isNotEmpty
            ? chartValues.reduce((a, b) => a > b ? a : b)
            : 1000)
        .toDouble();
    final safeMaxY = (maxY == 0 ? 100.0 : maxY * 1.25).ceilToDouble();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 20),
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeOutCubic,
            builder: (context, value, child) {
              return Opacity(
                opacity: value,
                child: Transform.translate(
                  offset: Offset(-40 * (1 - value), 0),
                  child: child,
                ),
              );
            },
            child: AspectRatio(
              aspectRatio: 1.5,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (value) => FlLine(
                      color: AppColors.gray200,
                      strokeWidth: 1,
                    ),
                  ),
                  titlesData: FlTitlesData(
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 28,
                        getTitlesWidget: (value, meta) {
                          final idx = value.toInt();
                          if (idx < 0 || idx >= chartLabels.length) return const Text('');
                          return Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              chartLabels[idx],
                              style: const TextStyle(fontSize: 11, color: AppColors.gray500),
                            ),
                          );
                        },
                        interval: (chartLabels.length / 6).ceilToDouble().clamp(1, chartLabels.length.toDouble()), // Show at most 6 labels
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 38,
                        getTitlesWidget: (value, meta) => Text(
                          value.toInt().toString(),
                          style: const TextStyle(fontSize: 11, color: AppColors.gray800),
                        ),
                        interval: (safeMaxY / 5).ceilToDouble(),
                      ),
                    ),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(color: AppColors.gray300, width: 1),
                  ),
                  minX: 0,
                  maxX: (chartLabels.length - 1).toDouble(),
                  minY: 0,
                  maxY: safeMaxY,
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: AppColors.teal500,
                      barWidth: 4,
                      dotData: FlDotData(show: false),
                      belowBarData: BarAreaData(
                        show: true,
                        color: AppColors.teal400.withOpacity(0.22),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
