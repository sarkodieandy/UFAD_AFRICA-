import 'package:flutter/material.dart';
import 'package:ufad/backend/util/app_colors.dart';


class AccountMetric extends StatelessWidget {
  final String label;
  final String value;
  final bool highlight;

  const AccountMetric({
    super.key,
    required this.label,
    required this.value,
    required this.highlight,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: highlight ? 3 : 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      color: highlight ? AppColors.teal500 : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                color: AppColors.gray100,
                fontWeight: FontWeight.w600,
                fontSize: highlight ? 16 : 14,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: highlight ? 24 : 22,
                color: highlight ? AppColors.teal600 : AppColors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }
}