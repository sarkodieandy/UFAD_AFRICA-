import 'package:flutter/material.dart';
import 'package:ufad/backend/models/category_model.dart';
import 'package:ufad/widgets/category_icon.dart'; // We'll define getCategoryIcon here

class CategoryTile extends StatelessWidget {
  final Category category;
  const CategoryTile({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        // Handle category tap
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Selected: ${category.name}')),
        );
      },
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          color: Colors.teal.withOpacity(0.09),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundColor: Colors.white,
              radius: 32,
              child: Icon(
                getCategoryIcon(category.icon),
                color: Colors.teal.shade700,
                size: 36,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              category.name,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 15,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
