import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class PaySupplierDialog extends StatefulWidget {
  const PaySupplierDialog({super.key});

  @override
  State<PaySupplierDialog> createState() => _PaySupplierDialogState();
}

class _PaySupplierDialogState extends State<PaySupplierDialog>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late AnimationController _ctrl;
  late Animation<double> _scale;
  String? purchaseId;
  String? accountId;
  double amount = 0;
  String description = '';
  bool _processing = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..forward();
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PaymentProvider>(context, listen: false);
    final purchases = provider.purchases;
    final accounts = provider.accounts;

    final noPurchases = purchases.isEmpty;
    final noAccounts = accounts.isEmpty;

    return ScaleTransition(
      scale: _scale,
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "Pay Supplier",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: "Select Purchase",
                        border: OutlineInputBorder(),
                      ),
                      value: purchaseId,
                      isExpanded: true,
                      items: purchases
                          .map(
                            (p) => DropdownMenuItem(
                              value: p.id.toString(),
                              child: Text('${p.productName} (${p.supplierName})'),
                            ),
                          )
                          .toList(),
                      onChanged: noPurchases
                          ? null
                          : (v) {
                              setState(() {
                                purchaseId = v;
                                final selected = purchases.firstWhere(
                                  (p) => p.id.toString() == v,
                                  orElse: () => purchases.first,
                                );
                                amount = selected.amountDue;
                              });
                            },
                      validator: (v) =>
                          (v == null || v.isEmpty) ? "Select purchase" : null,
                    ),
                    if (noPurchases)
                      const Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Text("No purchases available.",
                            style: TextStyle(fontSize: 12, color: Colors.redAccent)),
                      ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: "Select Account",
                        border: OutlineInputBorder(),
                      ),
                      value: accountId,
                      isExpanded: true,
                      items: accounts
                          .map(
                            (a) => DropdownMenuItem(
                              value: a.id,
                              child: Text('${a.name} (${a.type})'),
                            ),
                          )
                          .toList(),
                      onChanged: noAccounts ? null : (v) => setState(() => accountId = v),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? "Select account" : null,
                    ),
                    if (noAccounts)
                      const Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Text("No accounts available.",
                            style: TextStyle(fontSize: 12, color: Colors.redAccent)),
                      ),
                    const SizedBox(height: 14),
                    TextFormField(
                      readOnly: true,
                      key: ValueKey(amount),
                      initialValue: amount.toStringAsFixed(2),
                      decoration: const InputDecoration(
                        labelText: "Amount (GHS)",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      decoration: const InputDecoration(
                        labelText: "Description (optional)",
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 2,
                      onChanged: (v) => description = v,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: _processing ? null : () => Navigator.pop(context),
                    child: const Text("Cancel"),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.payment_rounded),
                    label: _processing
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Text("Pay Supplier"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.teal400,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onPressed: (noPurchases || noAccounts || _processing)
                        ? null
                        : () async {
                            if (_formKey.currentState?.validate() ?? false) {
                              setState(() => _processing = true);
                              final selected = purchases.firstWhere(
                                (p) => p.id.toString() == purchaseId,
                                orElse: () => purchases.first,
                              );
                              await provider.addTransaction(
                                PaymentTransaction(
                                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                                  type: 'Payment',
                                  account: accountId!,
                                  secondaryAccount: null,
                                  supplier: selected.supplierName,
                                  purchase: selected.productName,
                                  amount: amount,
                                  description: description,
                                  date: DateTime.now(),
                                ),
                              );
                              setState(() => _processing = false);
                              if (mounted) {
                                // ignore: use_build_context_synchronously
                                Navigator.pop(context);
                                // ignore: use_build_context_synchronously
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text("Payment recorded")),
                                );
                              }
                            }
                          },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
