import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/purchase_model.dart';
import 'package:ufad/backend/models/product_model.dart';
import 'package:ufad/backend/models/category_model.dart';
import 'package:ufad/backend/models/supplier.dart';
import 'package:ufad/backend/provider/stock_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class AddPurchaseSheet extends StatefulWidget {
  final Purchase? editPurchase;
  const AddPurchaseSheet({super.key, this.editPurchase});

  @override
  State<AddPurchaseSheet> createState() => _AddPurchaseSheetState();
}

class _AddPurchaseSheetState extends State<AddPurchaseSheet> {
  final _formKey = GlobalKey<FormState>();
  Product? _product;
  Supplier? _supplier;
  Category? _category;
  double? _unitCost;
  double? _sellingPrice;
  int? _quantity;
  String? _paymentStatus;
  DateTime? _date;

  @override
  void initState() {
    super.initState();
    if (widget.editPurchase != null) {
      final p = widget.editPurchase!;
      _product = p.product;
      _supplier = p.supplier;
      _category = p.category;
      _unitCost = p.unitCost;
      _sellingPrice = p.sellingPrice;
      _quantity = p.quantity;
      _paymentStatus = p.paymentStatus;
      _date = p.date;
    } else {
      _paymentStatus = "Paid";
      _date = DateTime.now();
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StockProvider>(context, listen: false);

    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 16,
          right: 16,
          top: 16,
        ),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36, height: 5,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: AppColors.gray300, borderRadius: BorderRadius.circular(5)
                ),
              ),
              Text(
                widget.editPurchase != null ? "Edit Purchase" : "Add Purchase",
                style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.teal600
                ),
              ),
              const SizedBox(height: 16),

              DropdownButtonFormField<Product>(
                isExpanded: true,
                value: _product,
                icon: const Icon(Icons.shopping_bag_outlined),
                decoration: InputDecoration(
                  labelText: "Product",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                items: provider.products
                    .map((p) => DropdownMenuItem<Product>(
                          value: p,
                          child: Text(p.name, style: const TextStyle(fontSize: 14)),
                        ))
                    .toList(),
                onChanged: (val) {
                  setState(() {
                    _product = val;
                    if (val != null) {
                      _unitCost = val.costPrice;
                      _sellingPrice = val.sellingPrice;
                      _category = val.category as Category?;
                    }
                  });
                },
                validator: (v) => v == null ? "Select product" : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<Supplier>(
                isExpanded: true,
                value: _supplier,
                icon: const Icon(Icons.people_outline),
                decoration: InputDecoration(
                  labelText: "Supplier",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                items: provider.suppliers
                    .map((s) => DropdownMenuItem<Supplier>(
                          value: s,
                          child: Text(s.name, style: const TextStyle(fontSize: 14)),
                        ))
                    .toList(),
                onChanged: (val) => setState(() => _supplier = val),
                validator: (v) => v == null ? "Select supplier" : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<Category>(
                isExpanded: true,
                value: _category,
                icon: const Icon(Icons.category),
                decoration: InputDecoration(
                  labelText: "Category",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                items: provider.categories
                    .map((c) => DropdownMenuItem<Category>(
                          value: c,
                          child: Text(c.name, style: const TextStyle(fontSize: 14)),
                        ))
                    .toList(),
                onChanged: (val) => setState(() => _category = val),
                validator: (v) => v == null ? "Select category" : null,
              ),
              const SizedBox(height: 10),

              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      initialValue: _unitCost?.toStringAsFixed(2) ?? '',
                      decoration: InputDecoration(
                        labelText: "Unit Cost",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      ),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      style: const TextStyle(fontSize: 14),
                      onChanged: (v) => _unitCost = double.tryParse(v),
                      validator: (v) => (double.tryParse(v ?? "") == null) ? "Enter unit cost" : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextFormField(
                      initialValue: _sellingPrice?.toStringAsFixed(2) ?? '',
                      decoration: InputDecoration(
                        labelText: "Selling Price",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      ),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      style: const TextStyle(fontSize: 14),
                      onChanged: (v) => _sellingPrice = double.tryParse(v),
                      validator: (v) => (double.tryParse(v ?? "") == null) ? "Enter selling price" : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextFormField(
                initialValue: _quantity?.toString() ?? '',
                decoration: InputDecoration(
                  labelText: "Quantity",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                keyboardType: TextInputType.number,
                style: const TextStyle(fontSize: 14),
                onChanged: (v) => _quantity = int.tryParse(v),
                validator: (v) => (int.tryParse(v ?? "") == null) ? "Enter quantity" : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                isExpanded: true,
                value: _paymentStatus,
                icon: const Icon(Icons.payment),
                decoration: InputDecoration(
                  labelText: "Payment Status",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                items: ["Paid", "Unpaid"]
                    .map((status) => DropdownMenuItem<String>(
                          value: status,
                          child: Text(status, style: const TextStyle(fontSize: 14)),
                        ))
                    .toList(),
                onChanged: (val) => setState(() => _paymentStatus = val),
                validator: (v) => v == null ? "Select payment status" : null,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text("Date:", style: TextStyle(fontSize: 14)),
                  const SizedBox(width: 10),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.calendar_month, size: 17),
                    label: Text(
                      _date != null
                          ? "${_date!.year}-${_date!.month.toString().padLeft(2, '0')}-${_date!.day.toString().padLeft(2, '0')}"
                          : "Pick Date",
                      style: const TextStyle(fontSize: 13),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppColors.teal400),
                    ),
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _date ?? DateTime.now(),
                        firstDate: DateTime(2022),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) setState(() => _date = picked);
                    },
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Cancel", style: TextStyle(fontSize: 14, color: AppColors.teal600)),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton.icon(
                    icon: Icon(widget.editPurchase != null ? Icons.edit : Icons.save),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.teal400,
                      foregroundColor: Colors.white,
                      textStyle: const TextStyle(fontSize: 14),
                    ),
                    onPressed: () {
                      if (_formKey.currentState?.validate() ?? false) {
                        final margin = (_sellingPrice! - _unitCost!) / _unitCost! * 100;
                        final purchase = Purchase(
                          id: widget.editPurchase?.id ?? DateTime.now().millisecondsSinceEpoch,
                          product: _product!,
                          supplier: _supplier!,
                          category: _category!,
                          unitCost: _unitCost!,
                          sellingPrice: _sellingPrice!,
                          profitMargin: margin,
                          quantity: _quantity!,
                          totalCost: _unitCost! * _quantity!,
                          paymentStatus: _paymentStatus!,
                          date: _date!,
                          amountDue: _paymentStatus == 'Unpaid' ? _unitCost! * _quantity! : 0.0,
                        );
                        if (widget.editPurchase != null) {
                          provider.editPurchase(purchase);
                        } else {
                          provider.addPurchase(purchase);
                        }
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              widget.editPurchase != null ? 'Purchase updated!' : 'Purchase added!',
                              style: const TextStyle(fontSize: 13),
                            ),
                          ),
                        );
                      }
                    },
                    label: Text(widget.editPurchase != null ? "Update" : "Add"),
                  ),
                ],
              ),
              const SizedBox(height: 6),
            ],
          ),
        ),
      ),
    );
  }
}
