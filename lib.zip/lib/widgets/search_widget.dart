import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/dashboard_provider.dart';
import 'package:ufad/backend/models/transaction_model.dart';

class SearchWidget extends StatefulWidget {
  const SearchWidget({super.key});

  @override
  State<SearchWidget> createState() => _SearchWidgetState();
}

class _SearchWidgetState extends State<SearchWidget> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _showResults = false;
  List<Transaction> _filteredResults = [];

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _searchTransactions(String query, DashboardProvider provider) {
    if (query.trim().isEmpty) {
      setState(() {
        _showResults = false;
        _filteredResults = [];
      });
      return;
    }
    final lowerQuery = query.toLowerCase();
    final txns = provider.transactions;
    final results = txns.where((t) {
      final dateStr = t.date is DateTime
          ? DateFormat.yMMMd().format(t.date as DateTime)
          : t.date.toString();
      return t.type.toLowerCase().contains(lowerQuery) ||
          t.amount.toString().contains(lowerQuery) ||
          dateStr.toLowerCase().contains(lowerQuery);
    }).toList();

    setState(() {
      _filteredResults = results;
      _showResults = true;
    });
  }

  void _hideResults() {
    setState(() {
      _showResults = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final dashboardProvider = Provider.of<DashboardProvider>(context);

    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: _hideResults,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _searchController,
            focusNode: _focusNode,
            decoration: InputDecoration(
              hintText: 'Search transactions...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
            ),
            onChanged: (value) => _searchTransactions(value, dashboardProvider),
            onTap: () {
              if (_searchController.text.isNotEmpty) {
                setState(() => _showResults = true);
              }
            },
          ),
          if (_showResults)
            Container(
              margin: const EdgeInsets.only(top: 8),
              constraints: const BoxConstraints(maxHeight: 270),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    // ignore: deprecated_member_use
                    color: Colors.black.withOpacity(0.07),
                    blurRadius: 9,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: _filteredResults.isEmpty
                    ? const Text('No transactions found')
                    : ListView.builder(
                        shrinkWrap: true,
                        itemCount: _filteredResults.length,
                        itemBuilder: (context, index) {
                          final transaction = _filteredResults[index];
                          final dateStr = transaction.date is DateTime
                              ? DateFormat.yMMMd().format(transaction.date as DateTime)
                              : transaction.date.toString();
                          return ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                                '${transaction.type}: GHS ${transaction.amount.toStringAsFixed(2)}'),
                            subtitle: Text(dateStr),
                            onTap: () {
                              // Optionally handle tapping on a result
                              _focusNode.unfocus();
                              _hideResults();
                            },
                          );
                        },
                      ),
              ),
            ),
        ],
      ),
    );
  }
}
