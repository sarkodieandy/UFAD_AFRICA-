import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:ufad/backend/util/app_colors.dart';

class FilterBar extends StatefulWidget {
  final Function({
    String? dateRange,
    DateTime? startDate,
    DateTime? endDate,
    String? debtor,
    bool? debtorsOnly,
  })? onFilter;

  const FilterBar({super.key, this.onFilter});

  @override
  State<FilterBar> createState() => _FilterBarState();
}

class _FilterBarState extends State<FilterBar> with SingleTickerProviderStateMixin {
  String? dateRange;
  DateTime? startDate;
  DateTime? endDate;
  String? debtor;
  bool debtorsOnly = false;

  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  late TextEditingController _debtorController;
  late TextEditingController _startDateController;
  late TextEditingController _endDateController;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeInOut);

    _debtorController = TextEditingController();
    _startDateController = TextEditingController();
    _endDateController = TextEditingController();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _debtorController.dispose();
    _startDateController.dispose();
    _endDateController.dispose();
    super.dispose();
  }

  void _pickDate(BuildContext context, bool isStart) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: isStart ? (startDate ?? now) : (endDate ?? now),
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 5),
      helpText: isStart ? 'Select Start Date' : 'Select End Date',
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: ColorScheme.light(
            primary: AppColors.teal600,
            onPrimary: Colors.white,
            surface: Colors.white,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          startDate = picked;
          _startDateController.text = DateFormat.yMd().format(picked);
        } else {
          endDate = picked;
          _endDateController.text = DateFormat.yMd().format(picked);
        }
        dateRange = null; // Clear dateRange when picking custom dates
      });
      _triggerFilter();
    }
  }

  void _triggerFilter() {
    widget.onFilter?.call(
      dateRange: dateRange,
      startDate: startDate,
      endDate: endDate,
      debtor: debtor,
      debtorsOnly: debtorsOnly,
    );
  }

  void _clearFilters() {
    setState(() {
      dateRange = null;
      startDate = null;
      endDate = null;
      debtor = null;
      debtorsOnly = false;
      _debtorController.clear();
      _startDateController.clear();
      _endDateController.clear();
    });
    _triggerFilter();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 540;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return FadeTransition(
      opacity: _fadeAnim,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.12),
          end: Offset.zero,
        ).animate(_fadeAnim),
        child: Card(
          margin: EdgeInsets.zero,
          elevation: isDark ? 4 : 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
          // ignore: deprecated_member_use
          shadowColor: isDark ? Colors.black.withOpacity(0.16) : null,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
            child: Wrap(
              spacing: isMobile ? 8 : 16,
              runSpacing: 12,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                SizedBox(
                  width: isMobile ? 140 : 156,
                  child: DropdownButtonFormField<String>(
                    value: dateRange,
                    decoration: InputDecoration(
                      labelText: 'Date Range',
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      // ignore: deprecated_member_use
                      fillColor: AppColors.teal600.withOpacity(0.07),
                      filled: true,
                    ),
                    items: [
                      const DropdownMenuItem(
                        value: null,
                        child: Text('Custom Range', style: TextStyle(color: AppColors.gray600)),
                      ),
                      ...['Yesterday', 'Today', 'This Month', 'Last Month', 'Quarterly', 'Yearly']
                          .map((c) => DropdownMenuItem(value: c, child: Text(c))),
                    ],
                    onChanged: (v) => setState(() {
                      dateRange = v;
                      if (v != null) {
                        startDate = null;
                        endDate = null;
                        _startDateController.clear();
                        _endDateController.clear();
                      }
                      _triggerFilter();
                    }),
                  ),
                ),
                SizedBox(
                  width: isMobile ? 110 : 130,
                  child: TextFormField(
                    readOnly: true,
                    controller: _startDateController,
                    decoration: InputDecoration(
                      labelText: 'Start Date',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      suffixIcon: Icon(Icons.calendar_today, size: 18, color: AppColors.teal400),
                      // ignore: deprecated_member_use
                      fillColor: AppColors.teal600.withOpacity(0.07),
                      filled: true,
                    ),
                    onTap: () => _pickDate(context, true),
                  ),
                ),
                SizedBox(
                  width: isMobile ? 110 : 130,
                  child: TextFormField(
                    readOnly: true,
                    controller: _endDateController,
                    decoration: InputDecoration(
                      labelText: 'End Date',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      suffixIcon: Icon(Icons.calendar_today, size: 18, color: AppColors.teal400),
                      // ignore: deprecated_member_use
                      fillColor: AppColors.teal600.withOpacity(0.07),
                      filled: true,
                    ),
                    onTap: () => _pickDate(context, false),
                  ),
                ),
                SizedBox(
                  width: isMobile ? 120 : 160,
                  child: TextFormField(
                    controller: _debtorController,
                    decoration: InputDecoration(
                      labelText: 'Search Debtor',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      prefixIcon: Icon(Icons.search, size: 19, color: AppColors.teal400),
                      // ignore: deprecated_member_use
                      fillColor: AppColors.teal600.withOpacity(0.07),
                      filled: true,
                    ),
                    onChanged: (v) {
                      debtor = v;
                      _triggerFilter();
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2, right: 8),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('Debtors Only', style: TextStyle(fontSize: 13)),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        transitionBuilder: (child, anim) =>
                            ScaleTransition(scale: anim, child: child),
                        child: Switch(
                          key: ValueKey(debtorsOnly),
                          value: debtorsOnly,
                          onChanged: (v) => setState(() {
                            debtorsOnly = v;
                            _triggerFilter();
                          }),
                          activeColor: AppColors.teal600,
                        ),
                      ),
                    ],
                  ),
                ),
                AnimatedScale(
                  scale: 1.0,
                  duration: const Duration(milliseconds: 230),
                  child: Tooltip(
                    message: "Clear all filters",
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.close, size: 19),
                      label: const Text('Clear'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.gray200,
                        foregroundColor: AppColors.black,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: _clearFilters,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
