import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/pos_model.dart';
import 'package:ufad/backend/provider/pos_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class PosSaleTable extends StatelessWidget {
  const PosSaleTable({super.key, required List<PosSale> sales});

  @override
  Widget build(BuildContext context) {
    // Use the filtered sales, not all sales!
    final filteredSales = context.watch<PosProvider>().filteredSales;

    if (filteredSales.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(32.0),
        child: Center(child: Text('No sales found.')),
      );
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 450),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          key: ValueKey(filteredSales.length),
          columns: const [
            DataColumn(label: Text('Customer')),
            DataColumn(label: Text('Total (GHS)')),
            DataColumn(label: Text('Paid (GHS)')),
            DataColumn(label: Text('Balance (GHS)')),
            DataColumn(label: Text('Status')),
            DataColumn(label: Text('Due Date')),
            DataColumn(label: Text('Progress')),
          ],
          rows: [
            for (final sale in filteredSales)
              DataRow(
                key: ValueKey(sale.id ?? sale.customer),
                cells: [
                  DataCell(Text(sale.customer)),
                  DataCell(Text(sale.total.toStringAsFixed(2))),
                  DataCell(Text(sale.paid.toStringAsFixed(2))),
                  DataCell(Text(sale.balance.toStringAsFixed(2))),
                  DataCell(Text(sale.status)),
                  DataCell(
                    Text(
                      '${sale.dueDate.year}-${sale.dueDate.month.toString().padLeft(2, '0')}-${sale.dueDate.day.toString().padLeft(2, '0')}',
                    ),
                  ),
                  DataCell(
                    SizedBox(
                      width: 120,
                      child: Row(
                        children: [
                          Expanded(
                            child: LinearProgressIndicator(
                              value: (sale.percent / 100).clamp(0.0, 1.0),
                              minHeight: 6,
                              backgroundColor: AppColors.gray200,
                              color: sale.percent == 100 ? AppColors.teal600 : Colors.orange,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text('${sale.percent.toStringAsFixed(1)}%'),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
