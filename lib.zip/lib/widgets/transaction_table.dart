import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';

class TransactionTable extends StatelessWidget {
  final List<PaymentTransaction> transactions;

  const TransactionTable({super.key, required this.transactions});

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('yyyy-MM-dd HH:mm');
    final amountFormat = NumberFormat.currency(symbol: 'GHS ', decimalDigits: 2);

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(Colors.teal.shade50),
          columns: const [
            DataColumn(label: Text('Type')),
            DataColumn(label: Text('Account')),
            DataColumn(label: Text('Secondary')),
            DataColumn(label: Text('Supplier')),
            DataColumn(label: Text('Purchase')),
            DataColumn(label: Text('Amount')),
            DataColumn(label: Text('Description')),
            DataColumn(label: Text('Date')),
          ],
          rows: transactions.map((tx) => DataRow(
            cells: [
              DataCell(_TypeBadge(type: tx.type)),
              DataCell(Text(tx.account)),
              DataCell(Text(tx.secondaryAccount ?? '—')),
              DataCell(Text(tx.supplier ?? '—')),
              DataCell(Text(tx.purchase ?? '—')),
              DataCell(Text(amountFormat.format(tx.amount))),
              DataCell(Text(tx.description)),
              DataCell(Text(dateFormat.format(tx.date))),
            ],
          )).toList(),
        ),
      ),
    );
  }
}

// Type badge for visual cue
class _TypeBadge extends StatelessWidget {
  final String type;
  const _TypeBadge({required this.type});

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (type.toLowerCase()) {
      case 'deposit': color = Colors.green; break;
      case 'expense': color = Colors.red; break;
      case 'transfer': color = Colors.orange; break;
      default: color = Colors.blueGrey;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        type,
        style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 13),
      ),
    );
  }
}
