import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class ExpenseDialog extends StatefulWidget {
  const ExpenseDialog({super.key});

  @override
  State<ExpenseDialog> createState() => _ExpenseDialogState();
}

class _ExpenseDialogState extends State<ExpenseDialog> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late AnimationController _ctrl;
  late Animation<double> _scale;
  String? accountId;
  double amount = 0;
  String description = '';
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..forward();
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _submit(PaymentProvider provider) async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    _formKey.currentState?.save();

    setState(() => _submitting = true);

    try {
      await provider.addTransaction(
        PaymentTransaction(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          type: 'Expense',
          account: accountId!,
          amount: amount,
          description: description,
          date: DateTime.now(),
        ),
      );
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Expense recorded")),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to record expense: $e")),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PaymentProvider>(context, listen: false);
    final accounts = provider.accounts;

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(), // dismiss keyboard when tapping outside
      child: ScaleTransition(
        scale: _scale,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Row(
            children: [
              Icon(Icons.remove, color: AppColors.warningRed, size: 25),
              SizedBox(width: 10),
              Text("Record Expense", style: TextStyle(fontWeight: FontWeight.w700)),
            ],
          ),
          content: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 6),
              child: Form(
                key: _formKey,
                child: SizedBox(
                  width: 330,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DropdownButtonFormField<String>(
                        decoration: InputDecoration(
                          labelText: "Select Account",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          filled: true,
                          fillColor: AppColors.gray100,
                        ),
                        value: accountId,
                        isExpanded: true,
                        items: accounts
                            .map((a) => DropdownMenuItem(
                                  value: a.id,
                                  child: Text('${a.name} (${a.type})'),
                                ))
                            .toList(),
                        onChanged: (v) => setState(() => accountId = v),
                        validator: (v) =>
                            accounts.isEmpty ? "No accounts available" : (v == null || v.isEmpty ? "Select account" : null),
                        onSaved: (v) => accountId = v,
                      ),
                      const SizedBox(height: 15),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Amount (GHS)",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          filled: true,
                          fillColor: AppColors.gray100,
                        ),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        onSaved: (v) => amount = double.tryParse(v ?? '') ?? 0,
                        validator: (v) =>
                            (v == null || v.isEmpty || double.tryParse(v) == null || double.parse(v) <= 0)
                                ? "Enter valid amount"
                                : null,
                      ),
                      const SizedBox(height: 15),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Description (optional)",
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          filled: true,
                          fillColor: AppColors.gray100,
                        ),
                        maxLines: 3,
                        onSaved: (v) => description = v ?? '',
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          actionsPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          actions: [
            TextButton(
              onPressed: _submitting ? null : () => Navigator.pop(context),
              child: const Text("Cancel", style: TextStyle(fontSize: 15)),
            ),
            ElevatedButton.icon(
              icon: _submitting
                  ? const SizedBox(
                      width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.remove),
              label: const Text("Record Expense"),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.warningRed,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
              ),
              onPressed: _submitting || accounts.isEmpty
                  ? null
                  : () => _submit(provider),
            ),
          ],
        ),
      ),
    );
  }
}
