import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/stock_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class StockFilterBar extends StatelessWidget {
  const StockFilterBar({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StockProvider>(context);

    return SizedBox(
      height: 50,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            // CATEGORY DROPDOWN
            SizedBox(
              width: 120,
              child: DropdownButtonFormField<int?>(
                decoration: InputDecoration(
                  labelText: "Category",
                  filled: true,
                  // ignore: deprecated_member_use
                  fillColor: AppColors.teal600.withOpacity(0.07),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                  labelStyle: const TextStyle(fontSize: 13),
                ),
                value: provider.categoryFilter,
                items: [
                  const DropdownMenuItem<int?>(
                    value: null,
                    child: Text("All", style: TextStyle(fontSize: 13)),
                  ),
                  ...provider.categories.map((c) => DropdownMenuItem<int?>(
                        value: c.id,
                        child: Text(c.name, style: const TextStyle(fontSize: 13)),
                      )),
                ],
                onChanged: provider.setCategoryFilter,
                isDense: true,
                isExpanded: true,
              ),
            ),
            const SizedBox(width: 10),
            // STATUS DROPDOWN
            SizedBox(
              width: 110,
              child: DropdownButtonFormField<String?>(
                decoration: InputDecoration(
                  labelText: "Status",
                  filled: true,
                  // ignore: deprecated_member_use
                  fillColor: AppColors.teal600.withOpacity(0.07),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                  labelStyle: const TextStyle(fontSize: 13),
                ),
                value: provider.statusFilter,
                items: const [
                  DropdownMenuItem<String?>(
                    value: null,
                    child: Text("All", style: TextStyle(fontSize: 13)),
                  ),
                  DropdownMenuItem<String?>(
                    value: "Paid",
                    child: Text("Paid", style: TextStyle(fontSize: 13)),
                  ),
                  DropdownMenuItem<String?>(
                    value: "Unpaid",
                    child: Text("Unpaid", style: TextStyle(fontSize: 13)),
                  ),
                ],
                onChanged: provider.setStatusFilter,
                isDense: true,
                isExpanded: true,
              ),
            ),
            const SizedBox(width: 10),
            // SUPPLIER DROPDOWN
            SizedBox(
              width: 120,
              child: DropdownButtonFormField<int?>(
                decoration: InputDecoration(
                  labelText: "Supplier",
                  filled: true,
                  // ignore: deprecated_member_use
                  fillColor: AppColors.teal600.withOpacity(0.07),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                  labelStyle: const TextStyle(fontSize: 13),
                ),
                value: provider.supplierFilter,
                items: [
                  const DropdownMenuItem<int?>(
                    value: null,
                    child: Text("All", style: TextStyle(fontSize: 13)),
                  ),
                  ...provider.suppliers.map((s) => DropdownMenuItem<int?>(
                        value: s.id,
                        child: Text(s.name, style: const TextStyle(fontSize: 13)),
                      )),
                ],
                onChanged: provider.setSupplierFilter,
                isDense: true,
                isExpanded: true,
              ),
            ),
            const SizedBox(width: 10),
            // APPLY FILTER BUTTON
            IconButton(
              icon: const Icon(Icons.filter_alt, color: AppColors.teal600, size: 22),
              onPressed: () => provider.fetchStockData(),
              tooltip: "Apply",
            ),
            // CLEAR FILTER BUTTON
            IconButton(
              icon: const Icon(Icons.refresh, color: AppColors.gray600, size: 21),
              onPressed: () => provider.clearFilters(),
              tooltip: "Clear",
            ),
          ],
        ),
      ),
    );
  }
}
