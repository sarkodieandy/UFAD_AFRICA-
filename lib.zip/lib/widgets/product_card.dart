import 'package:flutter/material.dart';
import 'package:ufad/backend/models/product_model.dart';

IconData getCategoryIcon(String icon) {
  switch (icon) {
    case 'electronics':
      return Icons.electrical_services;
    case 'food':
      return Icons.fastfood;
    case 'books':
      return Icons.menu_book;
    case 'clothing':
      return Icons.checkroom;
    case 'beauty':
      return Icons.face_retouching_natural;
    case 'furniture':
      return Icons.chair_alt;
    case 'jewelry':
      return Icons.diamond;
    case 'appliances':
      return Icons.kitchen;
    case 'sports':
      return Icons.sports_basketball;
    case 'toys':
      return Icons.toys;
    default:
      return Icons.category;
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const ProductCard({
    super.key,
    required this.product,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final iconData = getCategoryIcon(product.category.icon);

    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 420),
      tween: Tween(begin: 0, end: 1),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Opacity(
        opacity: value,
        child: Transform.translate(
          offset: Offset(0, (1 - value) * 20),
          child: child,
        ),
      ),
      child: Card(
        elevation: 4,
        margin: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onEdit,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 10),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 22,
                  backgroundColor: Colors.teal.shade50,
                  child: Icon(iconData, color: Colors.teal, size: 21),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product.name,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 15.5,
                          color: Colors.black87,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        product.category.name,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.teal.shade700,
                          fontWeight: FontWeight.w400,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'GHS ${product.sellingPrice.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w500,
                          color: Colors.teal,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 3),
                IconButton(
                  icon: const Icon(Icons.edit, size: 20, color: Colors.blueAccent),
                  onPressed: onEdit,
                  tooltip: "Edit",
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, size: 20, color: Colors.redAccent),
                  onPressed: onDelete,
                  tooltip: "Delete",
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
