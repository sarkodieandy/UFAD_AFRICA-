import 'package:flutter/material.dart';
import 'package:ufad/backend/models/activity_model.dart';
import 'package:ufad/widgets/activity_widget.dart';

class ActivityList extends StatelessWidget {
  final List<Activity> activities;

  const ActivityList({super.key, required this.activities});

  @override
  Widget build(BuildContext context) {
    if (activities.isEmpty) {
      return const Center(child: Text('No recent activities'));
    }

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: activities.length,
      itemBuilder: (context, index) {
        return ActivityWidget(activity: activities[index]);
      },
    );
  }
}
