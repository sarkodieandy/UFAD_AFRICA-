import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/pos_provider.dart'; // Confirm this is correct
import 'package:ufad/backend/util/app_colors.dart';

class PayDebtDialog extends StatefulWidget {
  final String customer;

  const PayDebtDialog({super.key, required this.customer});

  @override
  State<PayDebtDialog> createState() => _PayDebtDialogState();
}

class _PayDebtDialogState extends State<PayDebtDialog> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _amountController;
  late AnimationController _controller;
  late Animation<double> _scale;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..forward();
    _scale = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _amountController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _handlePay(BuildContext context) async {
    if (_submitting) return;
    if (_formKey.currentState!.validate()) {
      setState(() => _submitting = true);

      final provider = Provider.of<PosProvider>(context, listen: false);
      try {
        await provider.payDebt( // If payDebt is not async, remove 'await' and set _submitting = false right after
          customer: widget.customer,
          amount: double.parse(_amountController.text),
        );
        if (mounted) {
          // ignore: use_build_context_synchronously
          Navigator.of(context).pop();
          Future.microtask(() {
            // ignore: use_build_context_synchronously
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Payment recorded')),
            );
          });
        }
      } catch (e) {
        setState(() => _submitting = false);
        // ignore: use_build_context_synchronously
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scale,
      child: AlertDialog(
        title: Row(
          children: [
            Icon(Icons.payment, color: AppColors.teal600, size: 23),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                'Pay Debt for ${widget.customer}',
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 400),
          child: Form(
            key: _formKey,
            child: TextFormField(
              controller: _amountController,
              decoration: const InputDecoration(
                labelText: 'Amount (GHS)',
                border: OutlineInputBorder(),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (v) =>
                  v == null || v.isEmpty || double.tryParse(v) == null || double.parse(v) <= 0
                      ? 'Enter valid amount'
                      : null,
              enabled: !_submitting,
              autofocus: true,
              onFieldSubmitted: (_) => _handlePay(context),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: _submitting ? null : () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.teal400,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: _submitting ? null : () => _handlePay(context),
            child: _submitting
                ? const SizedBox(
                    height: 18, width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Text('Pay'),
          ),
        ],
      ),
    );
  }
}
