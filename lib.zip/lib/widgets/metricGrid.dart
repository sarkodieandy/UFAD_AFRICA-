import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/pos_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class MetricsGrid extends StatelessWidget {
  const MetricsGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final posProvider = Provider.of<PosProvider>(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final metrics = [
      {
        'title': 'Sales',
        'value': 'GHS ${posProvider.totalSales.toStringAsFixed(2)}',
        'icon': Icons.bar_chart,
        'gradient': LinearGradient(colors: [AppColors.teal600, AppColors.teal400]),
      },
      {
        'title': 'Paid',
        'value': 'GHS ${posProvider.totalPaid.toStringAsFixed(2)}',
        'icon': Icons.payments,
        'gradient': LinearGradient(colors: [AppColors.green50, Colors.green.shade200]),
      },
      {
        'title': 'Debtors',
        'value': '${posProvider.totalDebtors}',
        'icon': Icons.group,
        'gradient': LinearGradient(colors: [Colors.orange.shade100, Colors.orange.shade300]),
      },
      {
        'title': 'Debt Owed',
        'value': 'GHS ${posProvider.totalBalance.toStringAsFixed(2)}',
        'icon': Icons.money_off,
        'gradient': LinearGradient(colors: [AppColors.warningRed, Colors.redAccent.shade100]),
      },
      {
        'title': 'Debt Balance',
        'value': 'GHS ${posProvider.totalBalance.toStringAsFixed(2)}',
        'icon': Icons.account_balance_wallet,
        'gradient': LinearGradient(colors: [Colors.amber.shade100, Colors.amber.shade300]),
      },
    ];

    int crossAxisCount = 2;
    final width = MediaQuery.of(context).size.width;
    if (width > 900) {
      crossAxisCount = 4;
    } else if (width > 600) {
      crossAxisCount = 3;
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: metrics.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 2.1,
      ),
      itemBuilder: (context, i) {
        final metric = metrics[i];

        return TweenAnimationBuilder<double>(
          duration: Duration(milliseconds: 420 + i * 60),
          curve: Curves.easeOutBack,
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, value, child) {
            return Opacity(
              opacity: value,
              child: Transform.translate(
                offset: Offset(0, 16 * (1 - value)),
                child: child,
              ),
            );
          },
          child: _MetricCard(
            title: metric['title'] as String,
            value: metric['value'] as String,
            icon: metric['icon'] as IconData,
            gradient: metric['gradient'] as LinearGradient,
            isDark: isDark,
          ),
        );
      },
    );
  }
}

class _MetricCard extends StatefulWidget {
  final String title;
  final String value;
  final IconData icon;
  final LinearGradient gradient;
  final bool isDark;

  const _MetricCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.gradient,
    required this.isDark,
  });

  @override
  State<_MetricCard> createState() => __MetricCardState();
}

class __MetricCardState extends State<_MetricCard> with SingleTickerProviderStateMixin {
  double _scale = 1.0;

  void _onTapDown(TapDownDetails d) => setState(() => _scale = 0.97);
  void _onTapUp([_]) => setState(() => _scale = 1.0);

  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    final baseColor = widget.isDark ? Colors.white.withOpacity(0.11) : Colors.white.withOpacity(0.80);

    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapUp,
      child: AnimatedScale(
        scale: _scale,
        duration: const Duration(milliseconds: 110),
        child: Container(
          decoration: BoxDecoration(
            gradient: widget.gradient,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                // ignore: deprecated_member_use
                color: Colors.black.withOpacity(widget.isDark ? 0.15 : 0.11),
                blurRadius: 14,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Container(
            margin: const EdgeInsets.all(2.3),
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 15),
            decoration: BoxDecoration(
              color: baseColor,
              borderRadius: BorderRadius.circular(19),
              backgroundBlendMode: BlendMode.screen,
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 22,
                  // ignore: deprecated_member_use
                  backgroundColor: Colors.white.withOpacity(widget.isDark ? 0.12 : 0.7),
                  child: Icon(widget.icon, color: widget.isDark ? AppColors.teal300 : AppColors.teal600, size: 22),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.title,
                        style: TextStyle(
                          fontSize: 12.7,
                          // ignore: deprecated_member_use
                          color: widget.isDark ? Colors.white.withOpacity(0.78) : AppColors.gray700,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.08,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        widget.value,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: widget.isDark ? Colors.white : AppColors.teal600,
                          letterSpacing: 0.1,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
