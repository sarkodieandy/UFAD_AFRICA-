import 'package:flutter/material.dart';
import 'package:ufad/backend/models/supplier.dart';

class SupplierList extends StatelessWidget {
  final List<Supplier> suppliers;
  final void Function(Supplier supplier) onEdit;
  final void Function(Supplier supplier) onDelete;

  const SupplierList({
    super.key,
    required this.suppliers,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    if (suppliers.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: Text(
            'No suppliers found.',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ),
      );
    }
    return ListView.separated(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: suppliers.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final supplier = suppliers[i];
        return Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          elevation: 2,
          child: ListTile(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            leading: CircleAvatar(
              backgroundColor: Colors.teal.withOpacity(0.14),
              child: Text(
                supplier.name.isNotEmpty ? supplier.name[0].toUpperCase() : "?",
                style: const TextStyle(color: Colors.teal, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(
              supplier.name,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            subtitle: Text(
              '${supplier.type} • ${supplier.category}',
              style: const TextStyle(color: Colors.black54, fontSize: 13),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.teal),
                  tooltip: 'Edit Supplier',
                  onPressed: () => onEdit(supplier),
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.redAccent),
                  tooltip: 'Delete Supplier',
                  onPressed: () => onDelete(supplier),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
