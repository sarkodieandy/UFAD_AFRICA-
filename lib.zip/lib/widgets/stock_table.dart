import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:ufad/backend/provider/stock_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import 'package:ufad/widgets/category_icon.dart';
import 'add_purchase_sheet.dart';

class StockTable extends StatelessWidget {
  const StockTable({super.key});

  @override
  Widget build(BuildContext context) {
    final stockProvider = context.watch<StockProvider>();
    final purchases = stockProvider.purchases;
    final isLoading = stockProvider.isLoading;

    if (isLoading) {
      return const Padding(
        padding: EdgeInsets.all(36.0),
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (purchases.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(32.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.inventory_2_outlined, color: AppColors.gray300, size: 48),
              SizedBox(height: 16),
              Text(
                "No purchases yet",
                style: TextStyle(fontSize: 15, color: AppColors.gray500),
              ),
              SizedBox(height: 10),
              ElevatedButton.icon(
                icon: Icon(Icons.add),
                label: Text("Add Purchase"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.teal400,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (ctx) => const AddPurchaseSheet(),
                  );
                },
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      // ignore: deprecated_member_use
      color: Colors.white.withOpacity(0.98),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: RefreshIndicator(
        onRefresh: () async => context.read<StockProvider>().fetchStockData(), // <--- FIXED
        child: AnimationLimiter(
          child: ListView.separated(
            shrinkWrap: true,
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: purchases.length,
            separatorBuilder: (_, _) => Divider(height: 1, color: AppColors.gray200),
            itemBuilder: (context, idx) {
              final p = purchases[idx];
              return AnimationConfiguration.staggeredList(
                position: idx,
                duration: const Duration(milliseconds: 400),
                child: SlideAnimation(
                  verticalOffset: 14.0,
                  child: FadeInAnimation(
                    child: ListTile(
                      leading: CircleAvatar(
                        radius: 24,
                        backgroundColor: AppColors.teal50,
                        child: Icon(getCategoryIcon(p.category.icon), color: AppColors.teal600, size: 25),
                      ),
                      title: Text(
                        p.product.name,
                        style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: AppColors.black87),
                      ),
                      subtitle: Text(
                        "${p.category.name} • ${p.supplier.name}\nGHS ${p.unitCost.toStringAsFixed(2)} — ${p.paymentStatus}",
                        style: const TextStyle(fontSize: 12.5, color: AppColors.black54),
                        maxLines: 2,
                      ),
                      trailing: PopupMenuButton(
                        elevation: 6,
                        color: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        itemBuilder: (ctx) => [
                          const PopupMenuItem(
                            value: 'edit',
                            child: Row(
                              children: [
                                Icon(Icons.edit, size: 18, color: AppColors.teal600),
                                SizedBox(width: 8),
                                Text("Edit", style: TextStyle(fontSize: 13)),
                              ],
                            ),
                          ),
                          const PopupMenuItem(
                            value: 'delete',
                            child: Row(
                              children: [
                                Icon(Icons.delete, size: 18, color: AppColors.warningRed),
                                SizedBox(width: 8),
                                Text("Delete", style: TextStyle(fontSize: 13)),
                              ],
                            ),
                          ),
                        ],
                        onSelected: (val) async {
                          if (val == 'edit') {
                            showModalBottomSheet(
                              context: context,
                              isScrollControlled: true,
                              backgroundColor: Colors.transparent,
                              builder: (ctx) => AddPurchaseSheet(editPurchase: p),
                            );
                          } else if (val == 'delete') {
                            final confirmed = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                                title: const Text('Delete Purchase?', style: TextStyle(fontSize: 16, color: AppColors.warningRed)),
                                content: Text(
                                    'Are you sure you want to delete "${p.product.name}"?',
                                    style: const TextStyle(fontSize: 13.5)),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(ctx, false),
                                    child: const Text("Cancel", style: TextStyle(fontSize: 13.5)),
                                  ),
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.warningRed),
                                    onPressed: () => Navigator.pop(ctx, true),
                                    child: const Text("Delete", style: TextStyle(fontSize: 13.5, color: Colors.white)),
                                  ),
                                ],
                              ),
                            );
                            if (confirmed == true) {
                              // ignore: use_build_context_synchronously
                              context.read<StockProvider>().deletePurchase(p.id);
                              // ignore: use_build_context_synchronously
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Purchase deleted', style: TextStyle(fontSize: 13))),
                              );
                            }
                          }
                        },
                      ),
                      isThreeLine: true,
                      dense: true,
                      contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
