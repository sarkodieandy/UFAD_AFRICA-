import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class TransferDialog extends StatefulWidget {
  const TransferDialog({super.key});

  @override
  State<TransferDialog> createState() => _TransferDialogState();
}

class _TransferDialogState extends State<TransferDialog> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late AnimationController _ctrl;
  late Animation<double> _scale;
  String? fromAccountId;
  String? toAccountId;
  double amount = 0;
  String description = '';
  bool _processing = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..forward();
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PaymentProvider>(context, listen: false);
    final accounts = provider.accounts;

    return ScaleTransition(
      scale: _scale,
      child: AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.compare_arrows_rounded, color: Colors.orange, size: 23),
            SizedBox(width: 8),
            Text("Transfer Funds"),
          ],
        ),
        content: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: SizedBox(
              width: 330,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(labelText: "From Account"),
                    value: fromAccountId,
                    isExpanded: true,
                    items: accounts
                        .map((a) => DropdownMenuItem(
                              value: a.id,
                              child: Text('${a.name} (${a.type})'),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => fromAccountId = v),
                    validator: (v) => v == null || v.isEmpty ? "Select account" : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(labelText: "To Account"),
                    value: toAccountId,
                    isExpanded: true,
                    items: accounts
                        .map((a) => DropdownMenuItem(
                              value: a.id,
                              child: Text('${a.name} (${a.type})'),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => toAccountId = v),
                    validator: (v) => v == null || v.isEmpty
                        ? "Select account"
                        : v == fromAccountId
                            ? "Cannot transfer to same account"
                            : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    decoration: const InputDecoration(labelText: "Amount (GHS)"),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (v) => setState(() => amount = double.tryParse(v) ?? 0),
                    validator: (v) =>
                        (v == null || v.isEmpty || double.tryParse(v) == null || double.parse(v) <= 0)
                            ? "Enter valid amount"
                            : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    decoration: const InputDecoration(labelText: "Description (optional)"),
                    maxLines: 3,
                    onChanged: (v) => description = v,
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            child: const Text("Cancel"),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton.icon(
            icon: _processing
                ? const SizedBox(
                    width: 17,
                    height: 17,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.compare_arrows_rounded),
            label: const Text("Transfer"),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.blue500,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
            ),
            onPressed: _processing
                ? null
                : () async {
                    if (_formKey.currentState?.validate() ?? false) {
                      setState(() => _processing = true);

                      // Optional: Prevent transfer if not enough balance
                      final fromAcc = accounts.firstWhere((a) => a.id == fromAccountId);
                      if (fromAcc.balance < amount) {
                        setState(() => _processing = false);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: const Text("Insufficient funds"),
                            backgroundColor: Colors.red[400],
                          ),
                        );
                        return;
                      }

                      provider.addTransaction(
                        PaymentTransaction(
                          id: DateTime.now().millisecondsSinceEpoch.toString(),
                          type: 'Transfer',
                          account: fromAccountId!,
                          secondaryAccount: toAccountId,
                          amount: amount,
                          description: description,
                          date: DateTime.now(),
                        ),
                      );
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Transfer recorded")),
                      );
                    }
                    setState(() => _processing = false);
                  },
          ),
        ],
      ),
    );
  }
}
