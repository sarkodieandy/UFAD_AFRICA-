// ignore: file_names
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ufad/backend/models/account_model.dart';
import 'package:ufad/backend/util/app_colors.dart';

class AccountCard extends StatelessWidget {
  final Account account;
  final bool isPrimary;

  const AccountCard({
    super.key,
    required this.account,
    this.isPrimary = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 280),
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isPrimary
              ? [AppColors.teal600, AppColors.teal400]
              : [AppColors.blue500, AppColors.blue500],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            // ignore: deprecated_member_use
            color: (isPrimary ? AppColors.teal600 : AppColors.blue500).withOpacity(0.13),
            blurRadius: 22,
            spreadRadius: 3,
            offset: const Offset(2, 10),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            left: 24,
            top: 0,
            child: Container(
              width: 72,
              height: 140,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                gradient: LinearGradient(
                  // ignore: deprecated_member_use
                  colors: [Colors.white.withOpacity(0.23), Colors.transparent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 46,
                height: 32,
                decoration: BoxDecoration(
                  color: AppColors.amber200,
                  borderRadius: BorderRadius.circular(6),
                  boxShadow: [
                    BoxShadow(
                      // ignore: deprecated_member_use
                      color: AppColors.amber200.withOpacity(0.3),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  if (isPrimary)
                    const Padding(
                      padding: EdgeInsets.only(right: 8.0),
                      child: Icon(Icons.star, color: Colors.white, size: 22),
                    ),
                  Text(
                    isPrimary ? "Primary Account" : "Account",
                    style: GoogleFonts.inter(
                      // ignore: deprecated_member_use
                      color: Colors.white.withOpacity(0.92),
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
              Text(
                account.name,
                style: GoogleFonts.inter(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                  letterSpacing: 0.1,
                ),
              ),
              Text(
                account.type.replaceAll('_', ' ').toUpperCase(),
                style: GoogleFonts.robotoMono(
                  color: Colors.white70,
                  fontSize: 13.5,
                ),
              ),
              const SizedBox(height: 22),
              Text(
                "GHS ${account.balance.toStringAsFixed(2)}",
                style: GoogleFonts.inter(
                  color: Colors.white,
                  fontSize: 27,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.0,
                  shadows: [
                    Shadow(
                      // ignore: deprecated_member_use
                      color: Colors.black.withOpacity(0.15),
                      offset: const Offset(0, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.bottomRight,
                child: Icon(
                  Icons.credit_card_rounded,
                  // ignore: deprecated_member_use
                  color: Colors.white.withOpacity(0.83),
                  size: 38,
                  shadows: [
                    Shadow(
                      // ignore: deprecated_member_use
                      color: Colors.black.withOpacity(0.13),
                      blurRadius: 10,
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
