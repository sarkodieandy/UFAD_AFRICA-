import 'package:flutter/material.dart';
import 'package:ufad/backend/models/activity_model.dart';
import 'package:ufad/backend/util/app_colors.dart';

class ActivityWidget extends StatelessWidget {
  final Activity activity;

  const ActivityWidget({super.key, required this.activity});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          // Username
          Expanded(
            flex: 2,
            child: Text(
              activity.username,
              style: const TextStyle(fontSize: 13, color: AppColors.gray600),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
          // Action
          Expanded(
            flex: 3,
            child: Text(
              activity.action,
              style: const TextStyle(fontSize: 13, color: AppColors.black),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ),
          // Date
          Expanded(
            flex: 2,
            child: Text(
              activity.formattedDate,
              style: const TextStyle(fontSize: 13, color: AppColors.gray500),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }
}
