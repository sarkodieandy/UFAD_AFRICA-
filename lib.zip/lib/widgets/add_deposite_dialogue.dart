import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/models/payment_Transaction.dart';
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class AddDepositDialog extends StatefulWidget {
  const AddDepositDialog({super.key});

  @override
  State<AddDepositDialog> createState() => _AddDepositDialogState();
}

class _AddDepositDialogState extends State<AddDepositDialog> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late AnimationController _ctrl;
  late Animation<double> _scale;
  String? accountId;
  double amount = 0;
  String description = '';

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    )..forward();
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<PaymentProvider>(context, listen: false);
    final accounts = provider.accounts;

    final hasAccounts = accounts.isNotEmpty;

    return ScaleTransition(
      scale: _scale,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 14, left: 8, right: 8, top: 16),
        child: Material(
          color: Colors.transparent,
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Add Deposit",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppColors.teal600,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 18),
                if (!hasAccounts)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: Text(
                      "No accounts available. Please add an account first.",
                      style: TextStyle(color: Colors.red.shade400),
                      textAlign: TextAlign.center,
                    ),
                  ),
                if (hasAccounts) ...[
                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: "Select Account",
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      prefixIcon: Icon(Icons.account_balance_wallet_rounded, color: AppColors.teal400),
                    ),
                    value: accountId,
                    isExpanded: true,
                    items: accounts
                        .map(
                          (a) => DropdownMenuItem(
                            value: a.id,
                            child: Text(
                              '${a.name} (${a.type.replaceAll('_', ' ').toUpperCase()})',
                              style: TextStyle(fontWeight: FontWeight.w600),
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (v) => setState(() => accountId = v),
                    validator: (v) => v == null || v.isEmpty ? "Choose account" : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: "Amount (GHS)",
                      prefixIcon: Icon(Icons.attach_money_outlined, color: AppColors.teal400),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    onChanged: (v) => setState(() => amount = double.tryParse(v) ?? 0),
                    validator: (v) =>
                        (v == null || v.isEmpty || double.tryParse(v) == null || double.parse(v) <= 0)
                            ? "Enter valid amount"
                            : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    decoration: InputDecoration(
                      labelText: "Description (optional)",
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      prefixIcon: Icon(Icons.notes, color: AppColors.teal400),
                    ),
                    maxLines: 2,
                    onChanged: (v) => description = v,
                  ),
                ],
                const SizedBox(height: 22),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      child: Text("Cancel", style: TextStyle(color: AppColors.teal600)),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.save_alt_rounded),
                      label: const Text("Add Deposit"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.teal400,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        textStyle: const TextStyle(fontWeight: FontWeight.w600),
                        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 13),
                      ),
                      onPressed: !hasAccounts
                          ? null
                          : () {
                              if (_formKey.currentState?.validate() ?? false) {
                                provider.addTransaction(
                                  PaymentTransaction(
                                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                                    type: 'Deposit',
                                    account: accountId!,
                                    amount: amount,
                                    description: description,
                                    date: DateTime.now(),
                                  ),
                                );
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text("Deposit added")),
                                );
                              }
                            },
                    ),
                  ],
                ),
                const SizedBox(height: 6),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
