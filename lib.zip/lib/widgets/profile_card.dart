import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:ufad/backend/models/business_profile.dart';

class ProfileCard extends StatelessWidget {
  final BusinessProfile profile;
  final VoidCallback onViewProfile;

  const ProfileCard({
    super.key,
    required this.profile,
    required this.onViewProfile,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    Widget avatar;
    if (profile.profileImageUrl != null && profile.profileImageUrl!.isNotEmpty) {
      avatar = Hero(
        tag: 'profile_avatar_${profile.profileImageUrl}',
        child: CircleAvatar(
          radius: 40,
          backgroundImage: NetworkImage(profile.profileImageUrl!),
          backgroundColor: Colors.teal.shade100,
        ),
      );
    } else if (profile.profileImageBase64 != null && profile.profileImageBase64!.isNotEmpty) {
      avatar = Hero(
        tag: 'profile_avatar_${profile.name}',
        child: CircleAvatar(
          radius: 40,
          backgroundImage: MemoryImage(base64Decode(profile.profileImageBase64!)),
          backgroundColor: Colors.teal.shade100,
        ),
      );
    } else {
      avatar = Hero(
        tag: 'profile_avatar_empty',
        child: CircleAvatar(
          radius: 40,
          backgroundColor: Colors.teal.shade100,
          child: Icon(Icons.account_circle, size: 50, color: Colors.teal.shade700),
        ),
      );
    }

    final borderRadius = BorderRadius.circular(22);

    return Card(
      elevation: 7,
      // ignore: deprecated_member_use
      shadowColor: Colors.teal.withOpacity(0.13),
      margin: const EdgeInsets.all(14),
      shape: RoundedRectangleBorder(borderRadius: borderRadius),
      child: Material(
        color: Colors.transparent, // Keep card color
        borderRadius: borderRadius,
        child: InkWell(
          borderRadius: borderRadius,
          onTap: onViewProfile,
          // ignore: deprecated_member_use
          splashColor: Colors.teal.withOpacity(0.10),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                avatar,
                const SizedBox(height: 16),
                Text(
                  profile.name,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.teal[800],
                    fontSize: 18,
                    letterSpacing: 0.06,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 7),
                if (profile.phone.isNotEmpty == true)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.phone, size: 14, color: Colors.teal[300]),
                      const SizedBox(width: 4),
                      Text(
                        profile.phone,
                        style: TextStyle(fontSize: 13.8, color: Colors.grey[700]),
                      ),
                    ],
                  ),
                if (profile.phone.isNotEmpty == true) const SizedBox(height: 3),
                if (profile.location.isNotEmpty == true)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.location_on, size: 14, color: Colors.teal[300]),
                      const SizedBox(width: 4),
                      Text(
                        profile.location,
                        style: TextStyle(fontSize: 13.8, color: Colors.grey[700]),
                      ),
                    ],
                  ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: onViewProfile,
                    icon: const Icon(Icons.person, size: 19),
                    label: const Text("View Profile"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal[400],
                      foregroundColor: Colors.white,
                      elevation: 1.5,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      textStyle: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
