import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/customer_provider.dart';

class CustomerFilterBar extends StatefulWidget {
  const CustomerFilterBar({super.key});

  @override
  State<CustomerFilterBar> createState() => _CustomerFilterBarState();
}

class _CustomerFilterBarState extends State<CustomerFilterBar> {
  String _category = '';
  String _accountType = '';

  @override
  Widget build(BuildContext context) {
    final customerProvider = Provider.of<CustomerProvider>(
      context,
      listen: false,
    );
    final screenWidth = MediaQuery.of(context).size.width;
    double dropdownWidth = screenWidth > 500 ? 180 : (screenWidth / 2) - 36;
    dropdownWidth = dropdownWidth.clamp(120, 200);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          SizedBox(
            width: dropdownWidth,
            child: DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Category",
                isDense: true,
                border: OutlineInputBorder(),
              ),
              value: _category,
              items: const [
                DropdownMenuItem(value: '', child: Text("All Categories")),
                DropdownMenuItem(value: "Clothing", child: Text("Clothing")),
                DropdownMenuItem(
                  value: "Electronics",
                  child: Text("Electronics"),
                ),
                DropdownMenuItem(
                  value: "Food & Beverages",
                  child: Text("Food & Beverages"),
                ),
                DropdownMenuItem(value: "Groceries", child: Text("Groceries")),
                DropdownMenuItem(value: "Pharmacy", child: Text("Pharmacy")),
                DropdownMenuItem(value: "Beauty", child: Text("Beauty")),
                DropdownMenuItem(value: "Jewelry", child: Text("Jewelry")),
                DropdownMenuItem(value: "Furniture", child: Text("Furniture")),
                DropdownMenuItem(
                  value: "Home Appliances",
                  child: Text("Home Appliances"),
                ),
                DropdownMenuItem(value: "Books", child: Text("Books")),
                DropdownMenuItem(value: "Toys", child: Text("Toys")),
                DropdownMenuItem(
                  value: "Sports",
                  child: Text("Sports Equipment"),
                ),
                DropdownMenuItem(
                  value: "Stationery",
                  child: Text("Stationery"),
                ),
                DropdownMenuItem(
                  value: "Automotive",
                  child: Text("Automotive"),
                ),
                DropdownMenuItem(
                  value: "IT Services",
                  child: Text("IT Services"),
                ),
                DropdownMenuItem(
                  value: "Professional Services",
                  child: Text("Professional Services"),
                ),
                DropdownMenuItem(value: "Retail", child: Text("Retail")),
                DropdownMenuItem(value: "Wholesale", child: Text("Wholesale")),
                DropdownMenuItem(value: "Other", child: Text("Other")),
              ],

              onChanged: (v) {
                setState(() => _category = v ?? '');
                customerProvider.setFilters(
                  category: (_category.isEmpty ? null : _category),
                  accountType: (_accountType.isEmpty ? null : _accountType),
                );
              },
            ),
          ),
          SizedBox(
            width: dropdownWidth,
            child: DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: "Account Type",
                isDense: true,
                border: OutlineInputBorder(),
              ),
              value: _accountType,
              items: const [
                DropdownMenuItem(value: '', child: Text("All Types")),
                DropdownMenuItem(
                  value: "individual",
                  child: Text("Individual"),
                ),
                DropdownMenuItem(value: "business", child: Text("Business")),
              ],
              onChanged: (v) {
                setState(() => _accountType = v ?? '');
                customerProvider.setFilters(
                  category: (_category.isEmpty ? null : _category),
                  accountType: (_accountType.isEmpty ? null : _accountType),
                );
              },
            ),
          ),
          SizedBox(
            height: 48,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.close, size: 16),
              label: const Text("Clear", style: TextStyle(fontSize: 13)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey.shade200,
                foregroundColor: Colors.teal,
                elevation: 0,
                padding: const EdgeInsets.symmetric(
                  horizontal: 13,
                  vertical: 10,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                setState(() {
                  _category = '';
                  _accountType = '';
                });
                customerProvider.clearFilters();
              },
            ),
          ),
        ],
      ),
    );
  }
}
