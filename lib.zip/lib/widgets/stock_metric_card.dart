import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/util/app_colors.dart';
import '../backend/provider/stock_provider.dart';

class StockMetricCard extends StatelessWidget {
  final String label;
  final int index;

  const StockMetricCard({
    super.key,
    required this.label,
    required this.index,
  });

  IconData _getIcon(String label) {
    switch (label) {
      case 'Total Paid':
        return Icons.check_circle_rounded;
      case 'Total Unpaid':
        return Icons.pending_actions_rounded;
      case 'Balance to be Paid':
        return Icons.payments_rounded;
      case 'Current Stock Value':
        return Icons.inventory_2_rounded;
      default:
        return Icons.stacked_bar_chart_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<StockProvider>(context);
    String value;
    switch (label) {
      case 'Total Paid':
        value = 'GHS ${provider.totalPaid.toStringAsFixed(2)}';
        break;
      case 'Total Unpaid':
        value = 'GHS ${provider.totalUnpaid.toStringAsFixed(2)}';
        break;
      case 'Balance to be Paid':
        value = 'GHS ${provider.totalUnpaid.toStringAsFixed(2)}';
        break;
      case 'Current Stock Value':
        value = 'GHS ${provider.currentStockValue.toStringAsFixed(2)}';
        break;
      default:
        value = 'GHS 0.00';
    }

    return TweenAnimationBuilder<double>(
      duration: Duration(milliseconds: 350 + 60 * index),
      curve: Curves.easeOutBack,
      tween: Tween(begin: 0.0, end: 1.0),
      builder: (context, valueAnim, child) => Opacity(
        opacity: valueAnim,
        child: Transform.translate(
          offset: Offset((1 - valueAnim) * 40, 0),
          child: child,
        ),
      ),
      child: SizedBox(
        width: 144,
        height: 84,
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          elevation: 7,
          // ignore: deprecated_member_use
          shadowColor: AppColors.teal600.withOpacity(0.18),
          margin: const EdgeInsets.only(right: 15, bottom: 10, top: 2),
          clipBehavior: Clip.antiAlias,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  // ignore: deprecated_member_use
                  AppColors.teal500.withOpacity(0.93),
                  // ignore: deprecated_member_use
                  AppColors.teal600.withOpacity(0.98),
                  // ignore: deprecated_member_use
                  AppColors.teal400.withOpacity(0.96),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  // ignore: deprecated_member_use
                  color: AppColors.teal600.withOpacity(0.15),
                  offset: Offset(0, 5),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 19,
                      // ignore: deprecated_member_use
                      backgroundColor: Colors.white.withOpacity(0.19),
                      child: Icon(
                        _getIcon(label),
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            label,
                            style: const TextStyle(
                              fontSize: 12.7,
                              color: Colors.white70,
                              height: 1.1,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.04,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            value,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 17.3,
                              color: Colors.white,
                              height: 1.18,
                              letterSpacing: 0.13,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
