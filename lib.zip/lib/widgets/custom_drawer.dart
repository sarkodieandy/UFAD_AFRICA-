import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/user_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);
    final user = userProvider.user;

    final routes = [
      {'icon': Icons.dashboard, 'label': 'Dashboard', 'route': '/dashboard'},
      {'icon': Icons.people, 'label': 'Customers', 'route': '/customers'},
      {'icon': Icons.shopping_bag, 'label': 'Products', 'route': '/products'},
      {'icon': Icons.point_of_sale, 'label': 'POS', 'route': '/pos'},
      {'icon': Icons.payment, 'label': 'Payments', 'route': '/payments'},
      {'icon': Icons.warehouse, 'label': 'Stocks', 'route': '/stocks'},
      {'icon': Icons.local_shipping, 'label': 'Suppliers', 'route': '/suppliers'},
      {'icon': Icons.account_balance_wallet, 'label': 'Finances', 'route': '/finances'},
      {'icon': Icons.account_balance, 'label': 'Loan', 'route': '/loan'},
    ];

    String? currentRoute = ModalRoute.of(context)?.settings.name;

    return Drawer(
      backgroundColor: Colors.white.withOpacity(0.97),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(top: 48, left: 24, right: 24, bottom: 18),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [AppColors.teal600, AppColors.teal400]),
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
              boxShadow: [
                BoxShadow(
                  color: AppColors.teal600.withOpacity(0.15),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                )
              ],
            ),
            width: double.infinity,
            child: Row(
              children: [
                CircleAvatar(
                  radius: 32,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, color: AppColors.teal600, size: 38),
                  // If you add avatar URLs: backgroundImage: user?.avatarUrl != null ? NetworkImage(user!.avatarUrl) : null,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        user?.username ?? 'Guest',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 18,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      if ((userProvider.businessName).isNotEmpty)
                        Text(
                          userProvider.businessName,
                          style: const TextStyle(color: Colors.white70, fontSize: 13),
                          overflow: TextOverflow.ellipsis,
                        ),
                      if ((userProvider.phone).isNotEmpty)
                        Text(
                          userProvider.phone,
                          style: const TextStyle(color: Colors.white60, fontSize: 12),
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ...routes.map((nav) => ListTile(
                      leading: Icon(nav['icon'] as IconData, color: AppColors.teal600),
                      title: Text(
                        nav['label'] as String,
                        style: const TextStyle(fontSize: 14),
                      ),
                      selected: currentRoute == nav['route'],
                      selectedTileColor: AppColors.teal600.withOpacity(0.06),
                      onTap: () {
                        Navigator.pop(context);
                        if (currentRoute != nav['route']) {
                          Navigator.pushReplacementNamed(context, nav['route'] as String);
                        }
                      },
                    )),
                const Divider(height: 28),
                ListTile(
                  leading: const Icon(Icons.settings, color: AppColors.teal600),
                  title: const Text('Settings', style: TextStyle(fontSize: 14)),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.pushNamed(context, '/settings');
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.logout, color: AppColors.teal600),
                  title: const Text('Logout', style: TextStyle(fontSize: 14)),
                  onTap: () async {
                    Navigator.pop(context);
                    await userProvider.logout();
                    userProvider.clear();
                    // ignore: use_build_context_synchronously
                    Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
                  },
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
