import 'package:flutter/material.dart';
import 'package:ufad/backend/models/supplier.dart';

class SupplierForm extends StatefulWidget {
  final Supplier? supplier;
  final void Function(Supplier) onSave;

  const SupplierForm({super.key, this.supplier, required this.onSave});

  @override
  State<SupplierForm> createState() => _SupplierFormState();
}

class _SupplierFormState extends State<SupplierForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController nameController;
  late TextEditingController businessController;
  late TextEditingController phoneController;
  late TextEditingController mobileController;
  late TextEditingController locationController;

  String? type;
  String? category;

  // You can customize your supplier types and categories here
  final List<String> supplierTypes = [
    "Individual", "Company", "Wholesale", "Retail"
  ];
  final List<String> categories = [
    "Electronics", "Food", "Clothing", "Stationery", "Pharmacy", "Other"
  ];

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.supplier?.name ?? '');
    businessController = TextEditingController(text: widget.supplier?.business ?? '');
    phoneController = TextEditingController(text: widget.supplier?.phone ?? '');
    mobileController = TextEditingController(text: widget.supplier?.mobile ?? '');
    locationController = TextEditingController(text: widget.supplier?.location ?? '');
    type = widget.supplier?.type;
    category = widget.supplier?.category;
  }

  @override
  void dispose() {
    nameController.dispose();
    businessController.dispose();
    phoneController.dispose();
    mobileController.dispose();
    locationController.dispose();
    super.dispose();
  }

  void _save() {
    if (_formKey.currentState?.validate() ?? false) {
      final supplier = Supplier(
        id: widget.supplier?.id,
        name: nameController.text.trim(),
        type: type ?? '',
        category: category ?? '',
        business: businessController.text.trim(),
        phone: phoneController.text.trim(),
        mobile: mobileController.text.trim(),
        location: locationController.text.trim(),
      );
      widget.onSave(supplier);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(18),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Supplier Details',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Supplier Name', border: OutlineInputBorder()),
                validator: (val) => val == null || val.trim().isEmpty ? 'Enter supplier name' : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: "Type", border: OutlineInputBorder()),
                isExpanded: true,
                items: supplierTypes
                    .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                    .toList(),
                onChanged: (v) => setState(() => type = v),
                validator: (v) => v == null || v.isEmpty ? "Select supplier type" : null,
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: "Category", border: OutlineInputBorder()),
                isExpanded: true,
                items: categories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => setState(() => category = v),
                validator: (v) => v == null || v.isEmpty ? "Select category" : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: businessController,
                decoration: const InputDecoration(labelText: 'Business Name', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Phone', border: OutlineInputBorder()),
                validator: (val) => val == null || val.trim().isEmpty ? 'Enter phone number' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: mobileController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Mobile (optional)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: locationController,
                decoration: const InputDecoration(labelText: 'Location', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: Icon(widget.supplier == null ? Icons.add : Icons.save),
                  label: Text(widget.supplier == null ? "Add Supplier" : "Update Supplier"),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: _save,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
