import 'package:flutter/material.dart';
import 'package:ufad/backend/models/product_category.dart';
import '../backend/models/product_model.dart';


class ProductForm extends StatefulWidget {
  final Product? initial;
  final ValueChanged<Product> onSubmit;

  const ProductForm({super.key, this.initial, required this.onSubmit});

  @override
  State<ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<ProductForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _descriptionController;
  late TextEditingController _costPriceController;
  late TextEditingController _sellingPriceController;
  ProductCategory? _category;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.initial?.name ?? '');
    _descriptionController = TextEditingController(text: widget.initial?.description ?? '');
    _costPriceController = TextEditingController(
        text: widget.initial != null ? widget.initial!.costPrice.toStringAsFixed(2) : '');
    _sellingPriceController = TextEditingController(
        text: widget.initial != null ? widget.initial!.sellingPrice.toStringAsFixed(2) : '');
    _category = widget.initial?.category;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _costPriceController.dispose();
    _sellingPriceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = [
      ProductCategory(id: 1, name: 'Electronics', icon: 'electronics'),
      ProductCategory(id: 2, name: 'Food & Beverages', icon: 'food'),
      ProductCategory(id: 3, name: 'Books', icon: 'books'),
      ProductCategory(id: 4, name: 'Clothing', icon: 'clothing'),
      ProductCategory(id: 5, name: 'Beauty Products', icon: 'beauty'),
      ProductCategory(id: 6, name: 'Furniture', icon: 'furniture'),
      ProductCategory(id: 7, name: 'Jewelry', icon: 'jewelry'),
      ProductCategory(id: 8, name: 'Home Appliances', icon: 'appliances'),
      ProductCategory(id: 9, name: 'Sports Equipment', icon: 'sports'),
      ProductCategory(id: 10, name: 'Toys & Games', icon: 'toys'),
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              widget.initial == null ? 'Add Product' : 'Edit Product',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Name',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              validator: (val) => val == null || val.isEmpty ? 'Enter name' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(
                labelText: 'Description',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<ProductCategory>(
              value: _category,
              decoration: InputDecoration(
                labelText: 'Category',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              items: categories
                  .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                  .toList(),
              onChanged: (val) => setState(() => _category = val),
              validator: (val) => val == null ? 'Select category' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _costPriceController,
              decoration: InputDecoration(
                labelText: 'Cost Price (GHS)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (val) => val == null || double.tryParse(val) == null
                  ? 'Enter valid cost price'
                  : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _sellingPriceController,
              decoration: InputDecoration(
                labelText: 'Selling Price (GHS)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (val) => val == null || double.tryParse(val) == null
                  ? 'Enter valid selling price'
                  : null,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel', style: TextStyle(color: Colors.teal)),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      widget.onSubmit(Product(
                        id: widget.initial?.id ?? DateTime.now().millisecondsSinceEpoch,
                        name: _nameController.text,
                        description: _descriptionController.text,
                        costPrice: double.parse(_costPriceController.text),
                        sellingPrice: double.parse(_sellingPriceController.text),
                        category: _category!,
                      ));
                      Navigator.pop(context);
                    }
                  },
                  child: Text(widget.initial == null ? 'Add' : 'Update'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
