import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ufad/backend/provider/category_provider.dart';
import 'package:ufad/backend/provider/customer_provider.dart';
import 'package:ufad/backend/provider/dashboard_provider.dart';
import 'package:ufad/backend/provider/payment_provider.dart';
import 'package:ufad/backend/provider/pos_provider.dart';
import 'package:ufad/backend/provider/product_provider.dart';
import 'package:ufad/backend/provider/registration_provider.dart';
import 'package:ufad/backend/provider/stock_provider.dart';
import 'package:ufad/backend/provider/supplier_provider.dart';
import 'package:ufad/backend/provider/theme_provider.dart';
import 'package:ufad/backend/provider/user_provider.dart';
import 'package:ufad/backend/util/app_colors.dart';

import 'package:ufad/screens/business_activity.dart';
import 'package:ufad/screens/business_registration_success.dart';
import 'package:ufad/screens/ownerInfo_screen.dart';
import 'package:ufad/screens/payments_screen.dart';
import 'package:ufad/screens/place_holder_screen.dart';
import 'package:ufad/startup_&_onboarding/splash_screen.dart';
import 'package:ufad/startup_&_onboarding/startup_screen.dart';
import 'screens/business_info_screen.dart';
import 'screens/support_needs_screen.dart';
import 'screens/consent_screen.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/customer_screen.dart';
import 'screens/product_screen.dart';
import 'screens/pos_screen.dart';
import 'screens/stock_screen.dart';
import 'screens/supplier_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => RegistrationProvider()),
        ChangeNotifierProvider(create: (_) => DashboardProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => CustomerProvider()),
        ChangeNotifierProvider(create: (_) => ProductProvider()),
        ChangeNotifierProvider(create: (_) => PosProvider()),
        ChangeNotifierProvider(create: (_) => PaymentProvider()),
        ChangeNotifierProvider(create: (_) => StockProvider()),
        ChangeNotifierProvider(create: (_) => SupplierProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => CategoryProvider()),
      ],
      child: Consumer<ThemeProvider>(
        builder: (context, themeProvider, _) => MaterialApp(
          title: 'UFAD App',
          theme: ThemeData(
            useMaterial3: true, // Modern UI
            primarySwatch: Colors.teal,
            scaffoldBackgroundColor: AppColors.gray50,
            appBarTheme: const AppBarTheme(
              backgroundColor: AppColors.teal600,
              foregroundColor: Colors.white,
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.teal400,
                foregroundColor: Colors.white,
              ),
            ),
            textTheme: const TextTheme(
              titleMedium: TextStyle(
                color: AppColors.black,
                fontWeight: FontWeight.w600,
              ),
            ),
            inputDecorationTheme: InputDecorationTheme(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              fillColor: AppColors.gray100,
              filled: true,
            ),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            primarySwatch: Colors.teal,
            scaffoldBackgroundColor: AppColors.gray600,
            appBarTheme: const AppBarTheme(
              backgroundColor: AppColors.teal600,
              foregroundColor: Colors.white,
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.teal400,
                foregroundColor: Colors.white,
              ),
            ),
            textTheme: const TextTheme(
              titleMedium: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
            inputDecorationTheme: InputDecorationTheme(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              fillColor: AppColors.gray500,
              filled: true,
            ),
          ),
          themeMode: themeProvider.themeMode,
          initialRoute: '/splash',
          routes: {
            '/login': (context) => const LoginScreen(),
            '/termsan': (context) => const LoginScreen(),
            '/owner-info': (context) => const OwnerInfoScreen(),
            '/startup': (context) => const StartupScreen(),
            '/splash': (context) => const SplashScreen(),
            '/business-info': (context) => const BusinessInfoScreen(),
            '/business-activity': (context) => const BusinessActivityScreen(),
            '/support-needs': (context) => const SupportNeedsScreen(),
            '/consent': (context) => const ConsentScreen(),
            '/registration-success': (context) => const BusinessRegistrationSuccessScreen(),
            '/dashboard': (context) => const DashboardScreen(),
            '/customers': (context) => const CustomerScreen(),
            '/products': (context) => const ProductScreen(),
            '/pos': (context) => const PosScreen(),
            '/payments': (context) => const PaymentScreen(),
            '/stocks': (context) => const StockScreen(),
            '/suppliers': (context) => const SupplierScreen(),
            '/finances': (context) => const PlaceholderScreen(title: 'Finances'),
            '/loan': (context) => const PlaceholderScreen(title: 'Loan'),
            '/profile': (context) => const PlaceholderScreen(title: 'Profile'),
            '/settings': (context) => const PlaceholderScreen(title: 'Settings'),
            '/forgot-password': (context) => const PlaceholderScreen(title: 'Forgot Password'),
            '/terms': (context) => const PlaceholderScreen(title: 'Terms & Conditions'),
          },
          onUnknownRoute: (settings) => MaterialPageRoute(
            builder: (_) => const PlaceholderScreen(title: 'Page Not Found'),
          ),
        ),
      ),
    );
  }
}
