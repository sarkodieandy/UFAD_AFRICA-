// lib/models/business_profile.dart
class BusinessProfile {
  final String name;
  final String phone;
  final String location;

  BusinessProfile(this.name, this.phone, this.location);
}