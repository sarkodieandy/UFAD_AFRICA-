// $file — insert actual code hereimport 'package:flutter/material.dart';

import 'dart:ui';

class AppColors {
  static const Color green = Color(0xFF009966);
  static const Color white = Color(0xFFFFFFFF);
}
