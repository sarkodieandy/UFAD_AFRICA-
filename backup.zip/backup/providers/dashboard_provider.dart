import 'package:flutter/foundation.dart';
import '../models/dashboard_model.dart';
import '../services/api_service.dart';
import '../core/constants/exception.dart';

class DashboardProvider with ChangeNotifier {
  final _api = ApiService();

  bool loading = false;
  String? error;
  DashboardModel? dashboard;

  List<TopDebtor> get topDebtors => dashboard?.topDebtors ?? [];
  List<SalesTrend> get salesTrend => dashboard?.salesTrend ?? [];

  Map<String, dynamic> get metrics => {
    'total_sales': dashboard?.totalSales ?? 0.0,
    'total_expenses': dashboard?.totalExpenses ?? 0.0,
    'total_profit': dashboard?.totalProfit ?? 0.0,
    'unpaid_sales': dashboard?.unpaidSales ?? 0.0,
    'credit_score': dashboard?.creditScore ?? 0,
    'credit_tier': dashboard?.creditTier ?? '',
    'loan_qualification': dashboard?.loanQualification ?? '',
    'business_name': dashboard?.businessName ?? '',
    'business_phone': dashboard?.businessPhone ?? '',
    'business_location': dashboard?.businessLocation ?? '',
  };

  Future<void> fetchDashboard([int? userId]) async {
    if (loading) return;

    loading = true;
    error = null;
    notifyListeners();

    try {
      final id = userId ?? await _api.getUserId();
      if (id == null || id == 0) {
        throw ApiException.badRequest('Invalid or missing user ID');
      }

      final result = await _api.fetchDashboard(id);
      final status = result['status'] as int?;
      final data = result['data'];

      if (status == 404) {
        dashboard = DashboardModel.empty(); // Provide fallback default
        error = 'No dashboard data available yet.';
        return;
      }

      if (status != 200 || data == null) {
        throw ApiException.badRequest(
          result['message'] ?? 'Invalid dashboard response.',
        );
      }

      dashboard = DashboardModel.fromJson(data);

      dashboard = DashboardModel.fromJson(data);
    } on ApiException catch (e) {
      debugPrint('❌ ApiException: ${e.message}');
      dashboard = DashboardModel.empty();
      error = null;
    } catch (e) {
      debugPrint('❌ Unexpected dashboard error: $e');
      dashboard = DashboardModel.empty();
      error = null;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  void resetDashboard() {
    dashboard = null;
    error = null;
    loading = false;
    notifyListeners();
  }
}
